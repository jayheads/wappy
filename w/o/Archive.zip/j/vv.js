

vup=function(a){a=a||keys(oO('c'))
    var f=function(a){return $v(a)};
    return map(a,f)}


mD=function(p,V){//var m={dist:$8,index:-1},
    p=$v(p), ar=[], V=V||vup(), d=$8
    _e(V, function(v,k){
        v=$v(v)              // $l(p(v))
        if(p(v) < d){
            ar.unshift(_D({dist:p(v),
                dx: p.x-v.x,
                dy: p.x-v.y,
                dz: p.x-v.z},v))
            d=p(v)}})
    $l(ar[0].C )
    return ar}
shortNametoRgbStr=function(a){
    var c=css(tag()),a=a||'a';
    c('c',a); return   c('c')  }
isRgbStr=function(a){return c$(a,'rgb(')}
rgbStrToVecOb=function(a){
    a=a.replace(/[^\d,]/g,'').split(',')
    return {x:pI(a[0]),
        y:pI(a[1]),
        z:pI(a[2])}}

            // 'rgb(0,1,1)'-> obj
rgbStrToColor=function(a){
    var o=rgbStrToVecOb(a)
    o=mD(o)[0]; return o }

rgbStrToName=function(a){
    var o=rgbStrToVecOb(a)
    o=mD(o)[0];  return  o.C   }

strToVec=function(a){ //@!
    var s=a||'c'
    if(!isRgbStr(s)){s=shortNametoRgbStr(s)}
    if(isRgbStr(s)){s=rgbStrToVecOb(s)}
    s.c=a;
    s.C=oO('c',a)
    return s}// if(!( a.c && a.C))


$v=function $v(x,y,z){
    if(U(x)){return $v(0)}
    if(x.name=='v'){return x}
    var o=function v(a,b,c){return dst(v,$v(a,b,c))}
    if(F(x)){ return x(y.x, y.y, y.z)}
    if(O(x)){ return $v($v,x)}
    if(S(x)){ return _D(o, strToVec(x))}
    //s if(S(x)){x=rgb(x)}
    if(A(x)){return U(y) ? $a($v,x): _m(arguments, $v)}
    o.x=x||0;
    o.y=y||0;
    o.z=z||0;
    o.c=C
    return o}


