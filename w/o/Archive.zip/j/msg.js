



msg=function(){

    var d=_dv()

    ss(d, {

        w:500,
        h:200,
        C:'o',
        fz:20,
        P:'a',
        T:300,
        L:300,
        p:20,
        m:20

    })

    txt(d,'username, bucko? (dont say bucko)')
    d.append($('<br>'))
    d.append($('<br>'))
    var t=$('<input>'), b=$('<button>')
    txt(b,'ok')

    d.append(t)
    d.append(b)
    ss(b,{m:10})
    // ss(b,{P:'r',B:50})
    return tT(d)}





