
drawCenter=function(i){

    fit=function f(c, i,px,py){
        var x=X(c),c=C(c)

        px=px||0;py=py||0;

        im(i,function(i){
            $m( 'x', x, 'd',[i, px,py,aaW(x),aaH(c)]   )})
        //  $m('x',x,'d',  [i,px,py,aaW(c),aaH(c)])
        // else{Im(a,function(i){f(i,X,Y)})}
        return c}//$m('x',X(c),'d', [i,0,0])



    nothing=function(i,z){
        x.d(i,0,0,z,z,0,0,z,z)}

    D=function f(i,x,y){

        if(im(i)){
            x.dI(i,
                x-i.w/2,
                y-i.h/2)
            return x}

        else{
            im(i,function(i){
                f(i,x,y)})
            return x}}



    if(im(i)){
        o.d(i,(o.w()/2)-(i.w/2),
            (c$.h()/2)-(i.h/2));
        return o}
    else{im(i,
        function(i){
            o.d(i)});
        return o}}








dw=function f(c,i,x,y,w,h){
    var g=G(arguments)
    if(O(x)){
        return dI(c, i, x.x||0, x.y||0,
            x.w||wh(c).w , x.h||wh(c).h)}
    g[2]=g[2]||0
    return _a(dI,g)}


fit=function(c,i,x,h){
    dw(c,i,
        {x:x||0,h:h||0})}


