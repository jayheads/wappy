

//math
PI=3.14
pi=function(a){

    if(a<0){a=(1/-a)}


    return a*PI   }


     cos=$M.cos
sin=$M.sin
p2=pi(2)

degToRad=function(deg){return deg * pi(1/180)   }

radToDeg=function(rad){return rad * ( 180/pi(1)  ) }




inv=function(v){return vec((-v.x),(-v.y))}
add=function(a,b){return vec(a.x+ b.x, a.y+ b.y)}
subtract=function(a,b){return vec(a.x-b.x, a.y-b.y)}

abs=function f(a,b){
    if(N(b)){return f(a-b)}
    return $M.abs(a)}
sq=function f(a,b){if(O(a)){return f(a[0],a[1],a[2])}
    var n=0; _e(arguments, function(a){n+=(a*a)})
    return n}
sqr=function f(a,b){if(N(b)){return f( $a(sq,arguments) )} return $M.sqrt(a)}
ave=function ave(a){var ag=arguments,z=_z(ag),n=0;
    if(A(a)){return $a(ave, a)}
    _e(ag,function(a){n+=a}); return n/z}

dst =function f(a, b){
    var xyz=function(a,b){return sqr(a.x-b.x, a.y-b.y, a.z-b.z)}
    if(U(b)){return f(this, a)}
    if(A(a) && U(b)){return f(a[0],a[1])}
    a=$v(a); b=$v(b);
    return xyz(a,b)}

