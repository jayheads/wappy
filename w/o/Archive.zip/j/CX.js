

setTextPops=xT=xt=function(a,b,c){return {fs:a, fo:b, tb:c}}

xText=function(a,b,c){
    var f=function f(a,b){
        if(S(a) && U(b)){
            f.tt=a}}
    f.x= cx(a||'<', b||10,c)
    f.f=function(a,b){
        f.x.p('fo',
            $f(a))}
    f.t=function(a,b,c){
        if(c){f(c)
            return f.t(a,b)}
        f.x.m('ft',
            f.tt,a,b)}
    return f}

font=function(a){
    if(U(a)){return x.font};
    x.font=a;
    return o}//o.font("100px Georgia");


warpCanAroundIm=function(a){im(a,function(i){ox(can(i.w,i.h))('d',i,0,0)})}


canFitScr=function(){var wh=iWh()
    siz(can, wh.w, wh.h)
    fR(x,0,0,can.w,can.h)
    sty({'*':{m:0,p:0},  //css reset
        'html,body':{h:'100%',w:'100%'},
        canvas:{d:'b'}})
    $w.resize(resizeCanvas)
    function resizeCanvas(){var i=iWh()
        can.z(i.w, i.h)
        fR(can,0,0,x.w(),x.h())}

    resizeCanvas()}
scaleImageKeepCentered=function(c,i,s){
    var o=xx(c),
        w=c.w,
        h=c.h
    o('d',i,w*s/-2+w/2,h*s/-2+w/2+h/2,w*s,h*s)}

rgba=function(a,b){
    var rgbStr=function f(r,g,b,a){
            if(O(r)){
                return f(r.r||0,r.g||0,r.b||0,r.a||1)}
            return 'rgba('+tA(arguments).join()+')'},
        getColor=function(a){
            return ss(ss($('<div>'),
                {c:a}),'c').replace(/[^\d,]/g,'').split(',')}
    a=getColor(a)
    return rgbStr({r:pI(a[0]),
        g:pI(a[1]),b:pI(a[2]),a:b||1})}

gCo=function(c){return _p(xP(c),'gc')}


aCS= function(g,n,s){
    g.addColorStop(n,s);
    return g}


acs= function(g,n,s){
    g.addColorStop(n, oO('c',s))
    return g}


lG=function lG(c,d,e,f,g){var x=xx(c);return x('lg',d,e,f,g).res}
rG=function rG(c,d,e,f,g,h,i){
    // var g= _r( fl(arguments))
    //if(A(g[0])){g=cc( g[0], _r(g))}
    // if(_z(g)==3){g=[g[0],g[1],g[2],g[2]+100]}
    // if(_z(g)==4){ g=[ g[0],g[1], g[2], g[0], g[1] ,g[3] ]  }
    // return $a(o,cc('rg',g))}
    var x=xx(c)
    return x('rg',d,e,f,g,h,i).res}
gr=function(c,g,s,w,h){
    var x=xx(c.x||c),
        fn= _z(g)==4? lG:rG;
    g= _a(fn, _c(x.x,g) )


    if(O(s)){
        _e(s, function(v,k){var o= S(v)? {k:k,v:v}:{k:v, v:k}
            z=o
            aCS(g, o.k ,$r('c',o.v))
        })}

    x( {fs:g},
        'fr',
        40,40,
        w||x.w(),
        h||x.h())

    return g}
gra=function(c){
    var a=0 ; b=1000

    K(.02,function(){
        a+=1
        b-=2
        gr(c,[200,200, a,290,270,b],  {y:.1,r:.3,V:1})

    })}
cPt=createPattern=function(c,im,b){ return xM(c)('p', im, oO('pt', b||'r'))}

grad=function(a,b,c,d,e,f){
    var g=G(arguments),gr
    if(!N(a)){
        return x('p',a,
            pt[b] ||null)}
    if(f){
        g=x('rg',g)}
    else if(d){
        gr=x('rg',G)
        return aCS(gr,
            a,b)}
    if(!N(a)){
        return cPt(x,a,
            PT[b] ||null)}  //  if(!N(a)){return oO('[pt](a, PT[b]||null)};
    if(f){
        g=cRGr(x,
            a,b,c,d,e,f)}
    else if(d){
        g=cLGr(x,
            a,b,c,d)}
    return g[cs](a,b)}


transform=function(x,a,c,e,b,d,f){
    x=xx(x)
    var g=G(arguments) ,
        fn= g.n? 'tf':'t';


    if(a=='dbl'){
        return x(fn,2,0,0,2,0,0)
    }

    return x(fn,a,c,e,b,d,f)
}
//give scale cos(rads), skew:sin(rads)

norm=function(x){return x('sc', x.w()/10, x.h()/10)}

gA=globalAlapha=function(x,n){return xx(x)({ga:n||.5})}

rT=function(x,r){
    x('rt', pi(-6) * r||1)
    x('fr', 0,0, 1, 1)
    x({fs:$r('c')})}

nice=function(x,o,f){
        //temp canvas state
        // (wraps save/restore around ops)
            var g=G(arguments)
            x('S')(o)
            if(F(f)){f(xx(x))}
            else{ _a(x,   _r(arguments,2))
                if(g.P){('R')}
                return x} }










TF=[
    ['a:xsc', 'c:xsk', 'e:xtr'],
    ['b:ysk',
        'd:ysc',
        'f:ytr'],
    [0,0,1]
]    //cant change bottom row vals




$(function(){

   c=$c('y')



    x=xx(c)
    x.w(1000)
    x.h(700)

    g= x('lg',0,0,900,600).res





    acs(g, 0, 'r' )
    acs(g, 0.05, 'b' )

    acs(g, 0.05, 'b')
    acs(g, 0.1, 'r')


    acs(g,0.1,'r')
    acs(g,0.15,'b')


    acs(g,0.15,'b')
    acs(g,0.2,'r')


    acs(g,0.5,'y')

    acs(g,1,'b')











    x.p('fs',g)



    r=function(){
        x('fr',0,0,900,600)
    }

   r()
})