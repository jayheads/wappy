clo=function(a,b){

    var c=$(a).clone()

    if(O(b)){ss(c,b)} return c}

el=function em(o){
    var g=G(arguments),
        e=$t(o.t||'d')
    if(N(b)){return em(t, {C:'p', c:0}, b, d)}
    if(S(b)){return em(t, {C:b}, d, e)}
    if(b){ss(t, b)}
    if(d){siz(t, d, e)}
    if(g.N){tT(t)}
    return t}
el.p=pg=function(a){return $('<p>'+a+'</p>')}
el._=br=function(a){
    a=a||1
    var g=G(arguments)
    if(g.n){tT(_s(a))}
    else{tB(_s(a))} }
el.s=sp=function(a){var g=G(arguments)
    var s=$('<span>').text(a||'')
    ss(s)
    if(g.N){tT(s)}
    return s}
el.l=ls=function(){// lst('fsad','fasd','asfd')
    var g=G(arguments), l=$('<ul>')
    _e(g, function(a){var e=$('<li>')
        qq(e).ht(a)
        qq(l).ae(e)
        return tT(l)})}
el.i=inp=function(t,C,c,v){var g=G(arguments), e=em('i')
    typ(e, t||'t')
    ss(e, {C:C||'gr',c:c||'w'})
    if(v){val(e, v)}
    if(g.p){tT(e)}
    if(g.N){tB(e)}
    return e}
_ip=function(t){t=t||'t'
    var e=$('<input>') // e.attr('type','button')
    return e}
ip=function(t,C,c,v){
    var g=G(arguments),
        e=em('i')
    typ(e, t||'t')
    ss(e,{ C:C||'gr', c:c||'w'})
    if(v){ val(e, v)}
    if(g.p){tT(e)}
    if(g.N){tB(e)}
    return e}

el.k=chk=function(t,k){
    if(k===0){k=false}
    if(k===1){k=true}
    return pp(t, 'c', k)}
el.r=rang=function(){return inp('g')}

el.C=ctr=function(a,b){
    dap=function(b1,b2){
        if(D(b1)){b1=A(b1)?b1:[b1]} else {b1=[]}
        if(D(b2)){b2=A(b2)?b2:[b2]} else {b2=[]}
        var d=div(), b1=_a(but,b1), b2=_a(but,b2)
        d.m('ap',b1)
        d.m('ap',b2)
        return d}

    return dap(['start',a],['stop',b])}


//e.rb=rBox=function(w){var g=G(arguments), i=inp, e;e=g.n? i('r','-'):  g.p? i('r','+'):       i('r')
//return zz(e, (N(w) ? w: 3) / 4)}



el.cb=cBox=function(w){
    var g=G(arguments)  ,e
    if(g.n){e= inp('c','-')}
    else if(g.p ) {
        e=inp('c','+')}
    else{
        e=inp('c')}
    if(!N(w)){w=3}
    return siz(e,w/4)}
el.ti=te=textInput=function(w){
    var g=G(arguments),
        e= g.n?  inp('t','-')
            :  g.p?  inp('t','+')
            :inp('t')
    if(!N(w)){w=3}
    return zz(setColors(e,
        '!','y'), w/4


    )}//a= ["b", "f","h","i","p", "R","s" ]
el.fu=fUp=fileUpload=function(w){
    var e=ne(arguments)? inp('f','-')
        :pu(arguments)? inp('f','+'):
        inp('f')
    if(!N(w)){w=3}
    return siz(co(e,'!','y'), w/4)}
el.f=frm=fom=form=function(){var f=em('f')
    co(f,'r','b')
    css(f,'nh',50)
    //f.height(20)
    //siz(f,20,20)pT(f,inp('s'))
    Bo(f)
    f.prepend(rb())
    f.append(inp('s'))
    return f}
txtAr=function f(a,b){  //return {a:ag,t:t,d:d}
    var ag=tA(arguments),
        t=em('t')
    var d=$a(wh,ag)
    t.attr('cols', 10*d.w)
    t.attr('rows', pI(10*d.h/4))
    css(t, {C:'n'})
    if(ne(ag)){return t}
    t= $l( aT(t)  )
    $l(css(t,'w'))
    $l(css(t,'h'))
    return  t}
el.ta=textAreaInpu=function f(){//return {a:ag,t:t,d:d}
    var t = em('i'),
        d = _a(wh,  G(arguments))
    cols(t, 10* d.w)
    rows(t, 10* pI(d.h/4))
    return setC(t, 'y', 'O')}
el.b=but=function(a, b){
    var n=inp('b','c','B',a),fn  //ss(n,$rC()) // clk(n, function(e){  rgbStrToName(ss( _t(e),  'C'))})

    fZ(n,25)

    if(F(b)){ qq(n).$(b) }

    if(S(b)){

        fn=function(){eval(b)}

        qq(n).$(fn)
    }



    // clk(n,  function(e){  b(_g(e),clX(e),clY(e)) })}
    //  b(e)
    return tT(n)}  //be2=function(a){return $l(tag('b', " class='btn btn-lg ' "+" type ='submit' ").html(a)     )}
tog=function(a,b){

    var d=ctr()


}

