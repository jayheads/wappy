yE=yanoSuperEventObject=function(e){
    var f=function(){}
    f.A=e.altKey
    f.b=e.bubbles
    f.C=e.ctrlKey
    f.c=e.cancelable
    f.d=e.data
    f.dp=e.isDefaultPrevented
    f.e=e.originalEvent
    f.g=e.target
    f.gr=e.relatedTarget
    f.gc=e.currentTarget
    f.gd=e.delegateTarget
    f.M=e.metaKey
    f.p= e.eventPhase
    f.S=e.shiftKey
    f.t=e.type
    f.T=e.timeStamp
    f.x=e.pageX
    f.xc=e.clientX
    f.xo=e.offsetX
    f.xs=e.screenX
    f.y=e.pageY
    f.yc=e.clientY
    f.yo=e.offsetY
    f.ys=e.screenY
    return f}



ee=function(q, kO, v){


    q=qq(q)




}




ev=function(){}
ev.m=function(){}
ev.h=function(){}

oM=function(a,b){}

oM.C=function(a){
    $(a).dblclick(function(){
    ss($(this),
        'C',
        $r('c'))})}


$k=function k(ob, fn){
    var ,f
    if(F(ob)||S(ob)){return k(qH, ob)}
    f= S(fn)? function(){eval(fn)} : fn
    ob.click(function(e){var z=yE(e)
        //f = _b(f, this)
        f(yE(e), e.x, e.y)})
    return ob}





/////

 mxy=function(e){
    return {
        cx: e.clientX,
        cy: e.clientY,
        px: e.pageX,
        py: e.pageY,
        ox: e.offsetX,
        oy: e.offsetY}}
$(function(){
    if(0){d=dv()
    d1= h1(ldv(100));d2=h1(ldv(250));d3=h1(ldv(400))
    d1('cy: 1, cx: 2');bd(d)
    d.q.mousemove(function(e){m=mxy(e)
            d1(mc(m.cx, m.cy));d2(mp(m.px, m.py));d3(mo(m.ox, m.oy))})}
    d=dv();bd(d)})

bd=function(a){ss(a,{dw:20, dc:'r', dw:100, ds:"solid"})}
mc=function(x,y){return 'cx:'+x+', cy:'+y}
mp=function(x,y){return 'px:'+x+', py:'+y}
mo=function(x,y){return 'ox:'+x+', oy:'+y}



colorPick=function(){
    d.q.mousemove(function(e){
        var c=$r('c')
        ss(d,'C',c)
        d2(c)})}



drg=function(a){var q=qq(a);a=q.q
    a.mouseenter(function(e){
        px=e.pageX; py=e.pageY
        x=q.L();y=q.T()
        a.mousemove(function(e){
            q.L( x+e.pageX-px )
            q.T( y+e.pageY-py )})})}


// d=dv({w:600, h:600, T:100, L:100, C:'m'})
//d1=_dv()
//ss(d,{P:'a', w:600,h:600,T:100, L:100,C:'m'})
//d2=_dv()
//ss(d,{P:'a', w:600,h:600,T:100, L:100,C:'m'})
//d3=_dv()
//ss(d,{P:'a', w:600,h:600,T:100, L:100,C:'m'})
//d.mousedown(function(){qq(this).L(qq(this).L()+100)})
//d.mouseleave(function(){qq(this).L(qq(this).L()-100)})
//d.mousemove(function(){qq(this).L(qq(this).L()+1)})
//d.mouseover(function(){qq(this).w(qq(this).w()*.7)})
//d.mouseover(function(){qq(this).h(qq(this).h()*.7)})})
//
//
