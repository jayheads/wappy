$f=function(a){return function(){eval(a)}}
$a=function(a,b){b=b||"this";return a+".apply("+b+",arguments)"}
$w=window;


i_=_.isNull;iN_=_.isNaN
iD=function(a){return !_.isUndefined(a)};
iU=function(a){return _.isUndefined(a)};
i$=function(a){return !_.isNull(a)};
iB=function(a){return _.isBoolean(a)};
iN=function(a){return _.isNumber(a)};
iNp=function(a){return _.isNumber(a)&&Math.abs(a)==a&&a!=0};
iNn=function(a){return _.isNumber(a)&&Math.abs(a)!=a};
i0=function(a){return a==0};
i8=function(){return !_.isFinite(a)}
iS=function(a){return _.isString(a)};
iA=function(a){return _.isArray(a)};
iSA=function(a){return iS(a)||iA(a)};
iSL=function(a){return iS(a)||iL(a)};
iO=function(a){return _.isObject(a)&&!iF(a)&&!iA(a)};
iL=function(a){return(iO(a)||iA(a))};
iF=function(a){return _.isFunction(a)};
iSy=function(a){return a=='('||a==')'||a=='['||a==']'};
iE=_.isEmpty;
iH=_.isElement;
iG=_.isArguments;
iD=_.isDate;
iR=_.isRegExp;
iI=function(a){return _s(a)=="[object HTMLImageElement]"}
iC=function a){return _s(a)=="[object HTMLCanvasElement]"}
iB=function (a){return _s(a)=="[Bitmap (name=null)]"}
iL=function(a){return(iO(a)||iA(a))}

what=function(a){var o={
    d:iD(a)||'',u:iU(a)||'',_:i_(a)||'',$:i$(a)||'',b:iB(a)||'',n:iN(a)||'',np:iNp(a)||'',nn:iNn(a)||'',
    '0':i0(a)||'','8':i8(a)||'', n_:iN_(a)||'',s:iS(a)||'',a:iA(a)||'',sa:iSA(a)||'',o:iO(a)||'',
    l:iL(a)||'',f:iF(a)||'',e:iE(a)||'',h:iH(a)||'',g:iG(a)||'',d:iD(a)||'',r:iR(a)||''}
    return o}


i_=function(a,y,n){
    if(a){eval(y)}
    if(n){i_(!a,n)}return a}
a_=function(a,b,c){i_(iA(a),b,c);return a}
f_=function(a,b,c){i_(iF(a),b,c);return a}
s_=function(a,b,c){i_(iS(a),b,c);return a}
n_=function(a,b,c){i_(iN(a),b,c);return a}
o_=function(a,b,c){i_(iO(a),b,c);return a}
w_=function(a,b,c){i_(iW(a),b,c);return a}
//
_A=Array;
_F=Function;
_R=RegExp;


_.b=_.bind;
_.c=_.contains;
_.d=_.defaults;
_.e=_.each;
_.f=_.first;
_.g=_.groupBy;
_.h=_.has;
_.i=_.indexOf;
_.j=_.reject;
_.l=_.last;
_.m=_.map;
_.o=_.omit;
_.p=_.partial;
_.r=_.reduce;
_.s=_.some;
_.t=_.times;
_.u=_.union;
_.v=_.every;
_.w=_.where;
_.x=_.extend;
_.z=_.size;
_._=_.random;
_ts=function(a){return a.toString()}
_js=function(a){return JSON.stringify(a)}
_jn=function(a,b){return b.join(a)}
_pr=function(a){return JSON.parse(a)}
_rp=function(a,b,c){return c.replace(a,b)}
_tr=function(a){return _r(/\s\s*$/,'',_r(/^\s\s*/,'',a))  }
_sit=function(a,b,c){return c.split(a,b)}
_mt=function(a,b){return b.match(a)}
_rv=function(a){return a.reverse()}
_ush=function(a,b,c){return c.unshift(c,_.rest(arguments))}
_P=function(a,b,c){return a.pop()}
_ps=function(a,b,c){return c.push.apply(c,_.rest(arguments))}
_sh=function(a,b,c){return a.shift()}
_sl=function(a,b,c){return c.slice(a,b)}
tO=function(a){return _.toObject(a)}
tA=_a=function(a){return _.toArray(a)}
tS=function (a){return(iO(a))?_j(a):_s(a)}
//







lg=function (a){console.log(tS(a));return a}
$cat=function(){return(_.r(arguments,function(a,b){return a+tS(b)},''))}
$log=function(a){$c.l(tS(a));return a}
$l=function(){return $log(eval($a('$cat')))}
$l=function (a){function $a(a){return a + ".apply(this,arguments)"};
    return lg(eval($a('cat')))}// just returns a string//test$a(){eval($a('console.log'))}
$V=function (a,b,c,d){if(iO(a)){return a};if(d){return $V((a-c)/2,(b-d)/2)};
    if(iA(a)){return{x:a[0],y:a[1]}}
    else{return {x:a||0,y:b||a||0}}}//returns coords needed for centering
$V=function(a,b,c,d){a=a||0;if(d){return $V((a-c)/2,(b-d)/2)};
    if(iA(a)){return $V(a[0],a[1])};if(iN(a)){return $V({x:a, y:b})}
    var x=a.x||0, y=$df(a.y,x);return {x:x,y:y}}
$do=function(a,b){if(iF(b)){b(a)};if(iS(b)){$w[b]=a};return a}
$df=function(a,b){return(!iW(a))?a:b}
ifDoElse=ide=function i(v,y,n){if(v){eval(y)};i(!v,n);return v}
sr =function(a,b){if(!b){return a};if(iS(b)){$w[b]=a};if(iF(b)){b(a)};return a}
regexEscape=function (a){return _r(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g,"\\$&",a)}





ind=function ind(a,b){
    if(!b){return a.length};
    var i=b.indexOf(a);
    if(!(i==-1)){return i};return}



_has=function(a,b){
    if(iN($i(a,b))){a=_m(_e(a,'g'),b);
        return(a)?_l(a):false}}

has=function (a,b){if(iN(ind(a,b))){
    var h=b.match(RegExp(reg(a),'g'));
    if(h){return h.length}}}


__contains=function(a,b,c){
    a=_x(b,a);if(a!=-1){return a}}



startsWith=function(a,b){if(b){return(ind(a,b)==0)}//$fir=function(a,b){return(b)?ind(a,b)==0:a[0]}//__first=function(a,b){return(b)?b.indexOf(a)==0:a[0]}
_last=function(a){return=a[a.length-1]}// $lst=function(a,b){return(b)?ind(a,b)==_l(b)-1:a[_l(a)-1]}
_lastIs=function(a,b){return ind(a,b)==(b.length)-1}


_eq=function(a,b){
    return $cat('$w.',a,'=',b)}
_$gl=function(a,b){
    return eval(eq(a,b))}
_e=function(a,b){if(!b){
    return _r(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g,"\\$&",a)};
    return _R(_e(a),b)}
_removeBeforeFirstIndexOf=function(a,b){return _sl(ind(a,b),_l(b),b)}
_sliceAfterIndex=function(a,b){
    return b.slice(
        b.indexOf(a),
        b.length))}
$pre=function(a,b){return (fir(a,b))?b:a+b}//2
ext=function(a,b){
    if(!b){if(has('.',a)){return a.slice(ind('.',a),  ind(a))};
    return};return(ext(a))?a:a+pre('.',b)}
$ext=function(a,b){//1:ext,2:newExt(ifDoesntHave)
    if(!b){return(_has('.',a))?_sl(ind('.',a),
        ind(a),a):0};
    return(ext(a))?a:a+pre('.',b)}
$ext2=function $ext(a,b){
    if(!b){
        return(_has('.',a))?_sl(  ind('.',a),ind(a),a   ):0};
    return($ext(a))?a:a+$pre('.',b)}
png=function (a){return ext(a,'png')}
iU=function (a){if(!a){return};return fir('data:',a)}
tD=function (a){if(a.toDataURL){return a.toDataURL()};
    if(a.u){return a.u()};return a}
src=function(a){if(iS(a)){return pre('/',png(a))};return a}


    tU=function (a){if(a.src){return a.src};if(a.image){return a.image.src};
    a=tD(a);if(iU(a)){return a};return src(a)}  //s/c/C/i/b->s sync

////////////////////////////////////////////////////






cp=function(a){   //can mix with contains for 2nd pam
    if(iO(a)){return _.clone(a)}
    if(iA(a)){return _.rest(a,0)}
    if(iF(a)){return _.compose(a)}
    return a};//y.y=function(a){return this(copy(a))}





sl=function(a,b){_.c=_.contains;var not,slu,ls,sli,str='abcdefghijklmnopqrstuvwxyz',arr=[1,2,3,4,5,6,7,8,9,10];b=b||(arr);
    not=function(a){if(iA(a)){if(a[0]=='!'){return _.rest(a)}};if(_.first(a)=='!'){return a.slice(1,a.length)}}
    slu=function(a,b){var a=a.split(''),n,c,i=false;i=not(a);a=i||a;c=a.shift();n=a.join('');n=Number(n)||1;if(c=='l'){if(!i){r=_.last(b,n)}else{r=_.initial(b,n)}}else{if(!i){r=_.first(b,n)}else{r=_.rest(b,n)}};return iS(b)? r.join(''):r}
    ls=function(a,b,c){var s1=c.slice(0,a),s2=c.slice(b,c.length);return s1.concat(s2)}
    sli=function(a,b){var o,n1,n2,i;i=not(a);a=i||a;_.each(['(',')','[',']','|'], function(p){var t=a.split(p);if(t.length>1){o=p;n1=t[0];n2=t[1]}});
        if(o=='['){n2++};if(o==')'){n2*=(-1)};if(o==']'){n2=(n2*-1)+1};if(i){return ls(n1,n2,b)};return b.slice(n1,n2)}
    if(_.c(a,'f')||_.c(a,'l')){return slu(a,b)}else {return sli(a,b)}}






// YANO TIME!!
y=function y(){var A= _.toArray(arguments);var a={}; a.y=cp(A.shift());a._=function(){var t=this,A=arguments,a=y(t.y);
    return a[_.first(A)].apply(a,_.rest(A)).y}
a.a=function(a,b){var t=this;if(iN(t.y)&&!a){t.y=Math.abs(t.y)};if(iN(t.y)&&iF(a)){t.y=_.after(t.y,a)};
    if(iS(t.y)&&iN(a)){t.y=t.y.charAt(a)};if(iL(t.y)&&!a){t.y=_.toArray(t.y)};
    if(iL(t.y)&&iF(a)){t.y=_.every(t.y,a,b)};if(iF(t.y)&&iN(a)){t.y=_.after(a,t.y)};
    if(iF(t.y)&&!iN(a)){t.y=Function.apply.apply(t.y,arguments)};return t}
a.b=function(a,b,c){var t=this;if(iO(t.y)&&iS(a)){t.y=_.bind.apply(t,arguments)}
    if(iO(t.y)&&iF(a)){t.y=_.bind(t,a,b)};if(iF(t.y)&&iN(a)){t.y=_.debounce(t.y,a,b,c)};
    if(iF(t.y)&&iO(a)){t.y=_.bind(t.y,a,b)};return t}
a.c=function(a,b){var t=this;if(!a){return cp(t.y)}
    if(iA(t.y)&&iA(a)){t.y=t.y.concat.apply(t.y,arguments)};if(iL(t.y)&&iS(a)){t.y=_.invoke.apply(t.y,arguments)};
    if(iL(t.y)&&iF(a)){t.y=_.countBy(t.y,a,b)};if(iF(t.y)){t.y=_.compose.apply(t.y,arguments)};return t}
a.d=function(a,b,c){var t=this;if(iN(t.y)){t.y= Math.floor(t.y)};if(iA(t.y)){t.y= _.difference.apply(t.y,arguments)};
        if(iF(t.y)&&!a){_.defer(t.y,a,b)};if(iF(t.y)&&a){_.delay(t.y,a,b,c)};return t}
a.e=function(a,b,c){var t=this;if(iL(t.y)&&iF(a)){t.y=_.each(t.y,a,b)};if(iF(t.y)&&iL(a)){t.y=_.each(a,t.y,b)};return t}
a.f=function(a,b){var t=this;
        if(iSA(t.y)&&!a){t.y=_.first(t.y)};if(iSA(t.y)&&iS(a)){t.y=_.first(t.y==a)};
        if(iSA(t.y)&&iNp(a)){t.y= _.first(t.y,a); if(iS(a));t.y=t.y.join('')};if(iSA(t.y)&&iNn(a)){t.y= _.initial(t.y,Math.abs(a))};
        if(iL(t.y)&&iF(a)){t.y= _.filter(t.y,a,b)};if(iL(t.y)&&iO(a)){t.y= _.where(t.y,a)};return t}
a.F=function(a,b){var t=this;if(iA(t.y)&&!a){t.y=_.flatten(t.y)};return t}
a.g=function(a,b){var t=this,g=function(t){return {c:_.compact(t),fl:_.flatten(t),f:_.first(t),l:_.last(t),i:_.initial(t),r:_.rest(t)}}
        if(iF(t)){t.y=_.groupBy(t,a,b)};if(!a){t.y=g(t.y)};return t}
a.h=function(a,b,c){var t=this;if(iL(t)){t.y=_.contains(t,b)};return t}
a.i=function(a,b,c){var t=this;//if(iU(a)){t.y=issy(t.y)}
        if(iS(t.y)&&iN(a)&&iU(b)){if(iNn(a)){a=t._('z')+a}t.y=t.y.charAt(a)}
        if(iA(t.y)&&iN(a)&&iU(b)){if(iNn(a)){a=t._('z')+a}t.y=t.y[a]}
        if(iA(t.y)&&iS(a)&&iU(b)){t.y=_.i(t.y,a)}
        if(iS(t.y)&&iS(a)&&iU(b)){t.y=t.y.i(a)}
        if(iSA(t.y)&&iN(a)&&iS(b)&&!c){t.y=(_.i(t.y,b)==a)}
        if(iSA(t.y)&&iN(a)&&iS(b)&&iN(c)){t.y=(_.i(t.y,b,c)==a)}
        if(iSA(t.y)&&iS(a)&&iN(b)&&iU(c)){if(b==0){t.y=_.lastIndexOf(t.y,a)}else if(iNn(b)){t.y=_.lastIndexOf(t.y,a,b*-1)}else{t.y=_.indexOf(t.y,a,b)}}
        if(iSy(a)){var z=y(b,'z'),i=t._('i',b,c),Z=(z+i).toString();if(a=='['){t.sl('f'+ Z)};if(a==')'){t.sl('!f'+ Z)};if(a=='('){t.sl('f'+i)};if(a==']'){t.sl('!f'+i)}}
        if(iL(t.y)&&iF(a)){t.y=_.indexBy(t.y,a,b)};return t}
a.j=function(a){var t=this;if(iS(t.y)&&iA(a)){t.y=a.join(t.y)}
        if(iA(t.y)&&iS(a)){t.y=t.y.join(a)};return t}
a.J=function(a){var t=this;if(iL(t.y)&&(!a||iF(a)||iA(a))){t.y=JSON.stringify(a)}
            if(iS(t.y)&&(!a||iF(a))){t.y=JSON.parse(a)};return t}
a.I=function(a,b,c){var t=this;if(iA(t.y)){t.y= _.intersection.apply(t.y,arguments)};return t};
a.l=function(a,b,c){var t=this;
    if(iSA(t.y)&&!a){t.y=_.last(t.y)};
    if(iSA(t.y)&&iS(a)){t.y=_.last(t.y==a)};
    if(iA(t.y)&&iPN(a)){t.y=_.last(t.y,a)};
    if(iA(t.y)&&iNN(a)){t.y=_.rest(t.y,Math.abs(a))}
    return t}
a.L=function(a,b,c){var t=this;
        if(iSA(t.y)&&!a){t.y=t.y.length}
        if(iS(t.y)&&!a){t.y=t.y.toLowerCase()}
        if(iL(t.y)){t.y=_.lastIndexOf(t.y,a,b,c)}
        return t};
a.m=function(a,b){var t=this;
        if(iS(t.y)&&iO(a)){t.y= t.y.match(a)}
        if(iL(t.y)&&!a){t.y= [_.min(t.y), _.max(t.y)]}
        if(iL(t.y)&&iF(a)){t.y=_.map(t.y,a,b)}
        if(iF(t.y)&&iL(a)){t.y=_.map.apply(t.y,arguments)}
        return t}
a.M=function(a,b){var t=this;if(iF(t.y)&&iL(a)){t.y=_.memoize.apply(t.y,arguments)};return t}
a.o=function(a,b,c){var t=this;if(iF(t.y)){t.y=_.once(t.y)};if(iA(t.y)){t.y=_.object.apply(t.y,arguments)};return t}
a.p=function(a,b,c){var t=this;if(iL(t.y)&&iS(a)&&(!b)){t.y=_.pluck(t.y,a)};
            if(iA(t.y)&&!a){t.y.pop()};if(iA(t.y)&&a){t.y.push.apply(t.y,arguments)}
            if(iF(t.y)){t.y=_.partial.apply(t.y,arguments)};return t}
a.q=function(a,b){var t=this;if(iA(t.y)&&!a||iB(a)){t.y= _.unique(t.y,a,b)};return t}
a.r=function(a,b){var t=this;if(!a){t.y= t.y.reverse()};if(iF(a)){t.y= _.reduce(t.y,a,b)};if(iN(a)){t.y= _.rest(a,b)}
            if(iN(t.y)){t.y= Math.round(t.y)};if(iS(t.y)&&b){t.y= t.y.replace(a,b)};return t}
a.R=function(a){if(!a){var t=this;return _.shuffle(t.y)};if(iN(a)){t.y= _.sample(t.y,a)};return t}
a._s=function(a,b,c){var t=this; if(iA(t.y)){t.y=t.y.sort(a)};return t}
a.s=function(a,b,c){var t=this;
            if(iA(t.y)&&!a){t.y= t.y.shift()}
            if(iS(t.y)){t.y.split(a)}
            if(iA(t.y)&&iF(a)){t.y= _.sortby(t.y,a,b)};
            if(iA(t.y)&&iN(a)){t.y= t.y.slice(a,b)};return t}
a.sl=function(a,b){var t=this; t.y=sl(a, t.y);  return t}
a.S=function(a,b){var t=this;if(!a){t.y= t.y.toString()};if(iS(t.y)&&a){t.y.search(a)};if(iA(t.y)&&iN(a)&&iN(b)){t.y= t.y.splice(a,b)};
            if(iL(t.y)&&a&&(!b||iF(b))){t.y= t.y.sortedIndex(a,b)};return t}// if(!a)){t.y= _.shuffle(t.y)};if(iN(a)){t.y= _.sample(t.y,a)}
a.t=function(a,b){var t=this;if(iS(t.y)&&!a){t.y= t.y.trim()};if(iA(t.y)&&!a){t.y=_.compact(t.y)};
            if(iF(t.y)){t.y= _.throttle(t.y,a,b)};return t}
a.u=function(a,b,c){var t=this;if(iN(t.y)){t.y=Math.ceiling(t.y)};if(iA(t.y)){t.y= t.y.unshift.apply(t.y,tA(arguments))}
            if(iS(t.y)&&iN(a)){t.y= t.y.charCodeAt(a)};if(iS(t.y)&&!a){t.y= t.y.toUpperCase()};return t}
a.U=function(a,b,c){var t=this;return _.union.apply(t.y,arguments);return t}
a.w=function(a,b,c){var t=this;return t}
a.x=function(a,b){if(iA(t.y)){t.y=_.without.apply(t.y,arguments)};if(iL(t.y)&&iF(a)){t.y= _.reject(t.y,a,b)};return t}
a.z=function(a,b,c){var t=this;if(iSL(t.y)&&!a){t.y=_.size(t.y)};if(iA(t.y)&&iA(a)){t.y=_.zip.apply(t.y,arguments)};return t};if(!iE(A)){return a._.apply(a,A)}
    return a}

