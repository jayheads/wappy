qCore=function(e){

    var o={}

    o.q=tQ(e)

    o.s=function(a,b){return ss(o.q,a,b)}

    o.w=function(w,b){
        if(U(w)){return o.q.width()}
        if(w==='+'){return o.w( o.w()+b ) }
        if(w==='*'){return o.w( o.w()*b) }
        if(w==='%'){return o.w( o.w()*b *.01 ) }
        return o.q.width(  (w<10)?w*100:w  )}
    o.h=function(h,b){
        if(U(h)){return o.q.height()}
        if(h==='+'){return o.h( o.h()+b ) }
        if(h==='*'){return o.h( o.h()*b) }
        if(h==='%'){return o.h( o.h()*b *.01 ) }
        return o.q.height(  (h<10)?h*100:h)}

    o.z=function(z,b){
        if(U(z)){return {
            w:o.q.width(), h:o.q.height()
        } }

        if(z==='+'){ o.w( o.w()+b );o.h( o.h()+b )      }
        if(z==='*'){ o.w( o.w()*b );o.h( o.h()*b )   }
        if(z==='%'){ o.w( o.w()*b * .01 );
                     o.h( o.h()*b *.01 )  }
            o.h(z); o.w(z)
        return o}
    o.x=function(x){if(!x){return o.q.offset().left}
        return parseInt( x - o.x() )}
    o.y=function(y){if(!y){return o.q.offset().top}
        return parseInt( y - o.y() )}

    o.o=function(a,b,c){
        o.q.bind(oO('e',a),b,c);
        return o
    }

    o.$=function(a){
        o.o('click',
            function(e){
                var x=e.clientX,
                    y=e.clientY;
                var t= e.target;t.e=e;
                a(qq(t), x - o.x(), y - o.y(), x, y)});
        return o}
    o.$$=function(a){
        o.o('dblclick',
            function(e){
                var x=e.clientX,y=e.clientY;   var t= e.target;t.e=e;
                a(qq(t),x - o.x(),  y - o.y(), x, y )});



        return o}

 return Object.create(o)}



qq=function(e){

     var f=_D(function f(b){if(U(b)){return f.q.children()}
             if(b.q){b=b.q}
             if(Z(b)){f.q.empty(); return f()}
             if(F(b)){return b(f.q)}
             if(b==='c'){f(0); return $c('<',12)}
             if(b==='z'){ return f.q.children().size()}
             if(S(b)){f.q = f.q[oq(b)].apply(f.q,_m( _r(arguments), tQ));
                 return f }
             return f('ap', b)} ,


         qCore(e|| $("body") ))
        f.t=function(a){f.q.text(a);return f}
        f.H=function(a){return f.q.hasClass(a)}
        f.a=function(a){f.q.addClass(a);return f}
    return f}



var tQ=function(a){
    return (P(a))? ss(a): (E(a)||Q(a))? $(a): a.q
}



   ip=function(){
        return qq( ss('i')  )

   }






   orange=function(){

     var q= qq( {C:'o', w:50, h:50,p:20,m:20} );
       q.a( 'o');
       q.$(function(e){ e('r') })
       return q

   }



blue=function(){

    return qq( {C:'b', w:50, h:50} ).a( 'b').$(function(e){ e('r') })

}



pink=function(){
   return box()  }

pink2=function(){
    return qq({C:'p',w:700,h:700}).a('p').$(function(e){
   e(orange()) ;e(blue())
})}


imgBox= function f(a){

 var b=qq(a||{C:'p',w:700,h:700});

     b.a('p');


     //b.$$(function(e){ e(qq(  {C:'y', w: e.w()/2, h:e.h()/2}) )})
    return b

}



$(function(){
       o=orange()

        // r.c.a('r')


    p=pink()
   // p.c.a('p')

  b=blue()
   // g.c.a('g')

    $b=qq()

   // $b(o )
     $b( p )
  //  $b( b )

   // $b(p.q)
  //  $b(g.q)
   // q=qq('div')

  // j=qj(ss())

       //pq=qj(p.q)

   // pq.q.append(ss())

     //  pq.o('{}',function(){  $l('sroll'); pq.w(pq.w()+100) })

   // pq.o('$',function(){ pq.h(pq.h()+100) })



})


  ig=function(a){

    var i = new Image()
      i.src=src(a||'me')
           p(i)
  }

   opt=function(a){return "<option>"+a+"</option>"}

   sel=function(a){
       var b=''
       each(_r(arguments),function(v){

           b+=opt(v)
       })
       return $("<select name="+a+">"+b+"</select>")

   }


