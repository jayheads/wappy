mixin onPics(f)
script.
    onPics(#f)
h1 Your pics!
    each p in pics
    .picSelection
img.picSelect(width=100,height=100,src="#{p.relPath}")
script.
    $(function(){ccl('picSelect',function(e){TRANS(add(B(i)));tk(); })
    $('.picSelection').hide();
    k.emit('newPlayer',uid)
})
})






left=c.canvas.offsetLeft; // cutty?
top=c.canvas.offsetTop
c.canvas.onclick=function(e){var x= e.clientX,y=e.clientY; vertex(c,x,y)}


function mB(q,i){return B(q.g(i,true))}
function gB(e){
    var b=B(e.result);
    b.v=e;
    b.i=e.image;
    b.e=e.result;
    b.H=b.e.height;
    b.W=b.e.width;
    b.t=b.e.outerHTML;
    b.s=b.e.src;
    b.it=e.item;
    b.X=b.i.ext;
    b.p=b.i.src;
    b.q=e.target;
    b.r=e.rawResult;
    b.b=b.r.byteLength;
    return l(b)}
function oQ(f,m){$(function(){Q(m||mf,f)})}
//function rdyBl(f){return new Function("l('mR');"+f+";}")};function bk(p){var q=Q();q.k("b=B(e.result)");q.f(p)}


function oCl(a,f){a.onclick=function(e){var x=e.clientX,y=e.clientY;
    f(e,x-a.offsetLeft,y-a.offsetTop,x,y)}}//works//



function rad(d){return d*(Math.PI/180)}

pxDit =function(d,s){s="l[k]="+s;$m(d.data,s)}
pxChangeData =function(d,s){var f=new Function("v","k","l","l[k]="+s);_.each(d.data,function(v,k,l){f(v,k,l);})};
pxChangeData2=function(d,s){s="l[k]="+s;$m(d.data,s)}
pxCD=function(d,s){var f=new Function("v","k","l","l[k]="+s);_.each(d.data,function(v,k,l){f(v,k,l) })}
fade = function(image){// sets every fourth value to 50.. after the manipulation, reset the data and put the imagedata back to the canvas
    var imageData = image.data; var length = imageData.length;
    for(var i=7; i < length; i+=4){imageData[i] = 80;}; image.data = imageData; return image;}
pixelz =function(){c.drawImage(r,0,0,300,300,0,0,300,300);di=c.getImageData(0,0,300,300);d = di.data
    for (var i=0;i<imgData.data.length;i+=4){d[i]=255-d[i];imgData.data[i+1]=255-imgData.data[i+1];imgData.data[i+2]=255-imgData.data[i+2];imgData.data[i+3]=255;}
    ctx.putImageData(imgData,0,0);c.putImageData(di, 200,200);
    for (var i=0;i<imgData.data.length;i+=4)
    {imgData.data[i]=255-imgData.data[i];imgData.data[i+1]=255-imgData.data[i+1];
        imgData.data[i+2]=255-imgData.data[i+2];imgData.data[i+3]=255;}}

 d.bord=function (i,c,p){return [0,0,w,h,      .5* p, .5*p,  c.c.w-p,   c.c.h-p]}
dI =function(c,i){return function(sx,sy,sw,sh,dx,dy,dw,dh){c.dI(i,sx,sy,sw,sh,dx,dy,dw,dh)}}
BUTTONS ={moveUp:function(){c.T(0,-50);D()},moveDown:function(){c.T(0,50);D()},moveLeft:function(){c.T(-50,0);D()},moveRight:function(){c.T(50,0);D()},
function scaleDraw(i,c){c.save(); c.S(c.w/w, c.h/h);c.dI(i,0,0);c.restore()}//dI=gD(c);da=dI.data;
function smaller(){c.S(.9,.9);c.D(i,100,100,w,h)},
function bigger(c,i){c.S(1.3,1.3);c.dI(i,0,0,w,h)}
function flipY(c,i){c.T(w-1,h-1);c.R(Math.PI);c.dI(i,0,0,w,h)}//flipY:c.R(Math.PI/32)
function sclCntDwI(c,i,s){var w=c.w()*s, h=c.h()*s;c.dI(i,(c.w()-w)*.5,(c.h()-h)*.5,w,h)}
function tag(n){return document.getElementsByTagName(n)}
function iSw(a,b){a.parentNode.replaceChild(a,b)}
function iSwF2(){var i=tag(img);iSw(i[0],i[1])}


draw = function(i,c){//source
    return function(sw,sh){// sourceArea
        return function(sx,sy){//sourceSelection
            return function(dw, dh){ //stamp
                return function (dx, dy){ //Stamp
                    c.dI(i,sx,sy,sw,sh,dx,dy,dw,dh)}}}}}

DRAW =function(i,c,dx,dy){return function(Sx,Sy,Sw,Sh,Dw,Dh){
        c.dI(i,Sx,Sy,Sw,Sh,dx,dy,Dw,Dh)}}// draw = DRAW(i, c, dx, dy) //d =  function(){draw(sx,sy,sw,sh,dw,dh)}


stamp =function(i,c){return draw(i,c.x)(i.width,i.height)(0,0)(i.width,i.height)}

STA =function(i,c,n){
    return function(x,y){draw(i,c.x)(n*100,n*100)(0,0)(n*100,n*100)(x,y)}}

//s1 = stamp(chicks,c);s2 = stamp(chicks,cc);  // sta = "s1(0,0)"; st = f(sta)

cutter = function(i){
    return function(sx,sy){
        return function(sw,sh){
            return function(ctx,dx,dy,dw,dh){
                c.x.drawImage(i,sx,sy,sw,sh,dx,dy,dw,dh)}}}}
CUT = function(i){
    return function(sx,sy){
        return function(sw,sh){
            return function(c){
                return function(dw,dh){
                    return function(dx,dy) {
                        c.x.drawImage(i,sx,sy,sw,sh,dx,dy,dw,dh)}}}}}}
LEFT = function(S){return CUT(S)(0,0)(S.width/2,S.height)}
drawMy= function(a){cutter(a)(0,0)(a.w,a.h)}

function graphicsReady(){

    stage = new createjs.Stage(cj.c);l('stage:');
    ch = new createjs.Bitmap(qu.getResult('chicks'));  ch.x = 0; ch.y = 100;
    stage.addChild(ch);createjs.Ticker.setFPS(30);createjs.Ticker.ON("tick", stage);
    width =function(b){return b.getBounds().width*b.scaleX}
    height =function(b){return b.getBounds().height*b.scaleY}

    xCenter =function(b){return halfWidth(b)+b.x}
    yCenter =function(b){return halfHeight(b)+b.y}
    centerAt =function(b,x,y){b.x=x-halfWidth(b);b.y=y-halfHeight(b)}

    function cntA(b,x,y){
        b.x=x-hWidth(b);
        b.y=y-hHeight(b)}


    function trans(e){
        stg.addChild(center(Bm(Q.getResult('img')),stg));TRANSFORM(b)}// cute little trans !!!


   CJS(mf,gxReady);function gxsReady(){FPS(30);TICK();TR(b)}

    function TINY(m,s){s.a(m);m.scaleX=m.scaleY=.2;TR(m)}}
function Pop(i,c){B(i,function(b,c){c.aC(b);TR(b)},s)}
b=Bm(Q.getResult('i'));

TR=function(i){$(function(){makeSTAGE();Q=Q();Q.aL("fileload",function(e){TR(ADD(CNT(B(e))))});Q.f(i)})}
