var Cv=function(c){
    var x=c.getContext('2d'),
        o={obj:c},  w="width",h="height" ,sv="save",rs="restore",
        rt="rotate",  sc="scale",  tl="translate",
        sk="skew",clR="clearRect", pt="createPattern",rg="createRadialGradient",
        lg="createLinearGradient",cs="addColorStop",
        bp="beginPath",cp="closePath", du="toDataURL",
        cl="clip",re="rect",mt="moveTo", fl="fill",fr="fillRect",
        ft="fillText", so="stroke",sr="strokeRect",  st="strokeText",
        lt="lineTo",at="arcTo",  gid="getImageData", pid="putImageData",
        fo="font", pp="isPointInPath",di="drawImage "}
    //c.S=sS(S$(C),c);
    //  c.C=sEl(C);
    //  c.X=sX(C.getContext('2d'),c);
//h.$=sQ($(h));//c.H = _.b(c.C.H, c.C); c.pop=c.X_=_.b(c.X.pop,c.X);// o.q=Fransi($(h));o.ctx=x;
// a brilliant function that you pass a canvas  to;
// it returns a fn that lets u make calls on the ctx
// by using the abbreviated obj keys
/// below:  x, CANVAS
xx=function(c){ var x= Xx(c),

    XXX={a:"arc",at:"arcTo",z:"bezierCurveTo",
        b:"beginPath",c:"closePath",cr:"clearRect",
        j:"clip",d:"drawImage",f:"fill",fr:"fillRect",ft:"fillText",
        g:"createLinearGradient",gi:"getImageData",i:"createImageData",
        ip:"isPointInPath",is:"isPointInStroke",v:"save",
        l:"lineTo",m:"moveTo",mt:"measureText",pi:"putImageData",
        p:"createPattern",q:"quadraticCurveTo",rg:"createRadialGradient",
        rc:"rect",r:"restore",S:"scale", T:"translate" , R:"rotate",
        s:"stroke",sr:"strokeRect",st:"strokeText",
        t:"transform",tf:"setTransform"}
    return function(m){
        return x[XXX[m]].apply(x, rest(arguments))}}





sexy=function(c){
    var x=Xx(c), q=$(c), cx = xx(x), o=function(){};
o.du=function(){return c.toDataURL()};o.img= o.jj=o.du();
o.save= o.s= o.i=function(){x.save();return o};
o.restore=o.r= o.I=function(){x.restore();return o};
o.copy=o.j=function(){o.I=O.jj=o.du();return o};
o.paste=function(){o.X();o.d(o.jj)}
o.replace=function(){o.X();o.d(o.jj)}
o.pasteFit=o.p= o.J=function(){o.fit(o.img,0,0)}
o.w=function(w){if(!w){return c.width} var u=o.du(); c.width=w; if(!z){o.fit(u)} return o}
o.h=function(h){if(!h){return c.height} var u=o.du(); c.height=h; if(!z){o.fit(u)} return o}
o.wh=function(w,h){var u;
    if(!w){return $V(o.w(),o.h())};
    u=o.du();
    o.w(w);
    o.h(h||w);
    o.fit(u);
    return o};
c.x=function(x){if(!x){return q.offset().left}; return parseInt(x-o.x())}
c.y=function(y){if(!y){return q.offset().top}; return parseInt(y-o.y())}
o.H=o.html=o.e=function(){return o.outerHTML}
o.css=o.l=function(){q.css.apply(q,arguments);return o}
o.clR=function(){x.clear();return o}
o.clear=o.X=function(){x.clearRect(0,0,o.w(),o.h());return o};
o.color=function f(a,b,c,d){
    if(U(a)){f.c.ap()};
    if(S(a)){var s;
        o.s();
        if(U(b)){s=a}
        else{s="rgba("+ [a,b,c,d].join(",") +")"}
        o.pop('f', s);
        o.f(0,0,o.w(),o.h());
        o.r()}
    return f}
o.bgCol=o.k=function(a){return o.l('backgroundColor',a)};
border=function(s,c,y){if(U(S)){s=10};
    var ws=function(a){return ' '+a+' '};
    o.l('border',$l(ws(s+"px")+ws(y||"solid")+ws(c||"blue")));
    return o}
o.ap=function(){$("body").append(q);return o}
o.pp= o.bod=function(){$("body").prepend(q);return o}
o.puzzle=function(a,b){return o[pp](a,b)}
CTX={a:'globalAlpha', b:'shadowBlur',
    r:'shadowColor', x:'shadowOffsetX',
    y:'shadowOffsetY' ,
    c:'lineCap',  m:'miterLimit',j:'lineJoin',
    w:'lineWidth' ,
    f:'fillStyle', s:'strokeStyle',
    t:'font',g:'textAlign',e:'textBaseline',
    o:'globalCompositeOperation'}
o.pop=function(a,b){
    if(!b){return o[CTX[a]]}
    o[CTX[a]]=b;
    return o}
o.mystery=function(a,b,c,d){
    if(U(a)){o.x(0,0,o.w(),o.h())return o}
    if(N(a)){o.x(a,b||a,c||200,d||c)}}
o.U=function(){s.u;return o}
o.gradient=function(a,b,c,d,e,f){var  G=arguments,
    pt={x:"repeat-x",y:"repeat-y",z:"no-repeat"};

    if(!N(a)){return cx('p',a,pt[b]||null)};
    if(f){g=cx('rg', G)}
    else if(d){
        g=cx('rg',G)
        return g.addColorStop(a, b)}
}
gco={d:'destination-over',da:'destination-atop',
    do:'destination-out',
    di:'destination-in',
    s:'source-over',a:'source-atop',o:'source-out', i:'source-in',
    l:'lighter', x:'xor',c:'copy'}
o.gc=function(a){x.globalCompositeOperation=gco[a]}
o.gco=function(a){return o.pop('o',gco[a])}
o.shad=function(a,b){
    if(S(a)){
        return o.pop('r',a).pop('b',b||0)}
        return o.pop('x',a).pop('y',b||a)}
o.font=function(a){var ;
    if(U(a)){return x.font}
    x.font=a;return o};
o.font("100px Georgia");
o.pat= o.grad=o.g=function(a,b,c,d,e,f){var g;
    if(!N(a)){return o[pt](a, PT[b]||null)};
    if(f){g=x[rg](a,b,c,d,e,f)}
    else if(d){g=x[lg](a,b,c,d)};
    return g[cs](a,b)}
o.pBl=function(n){o.tBl(function(b){svAs(b,n+".png")});return o}
o.bp=function(n){this.toBlob(function(b){saveAs(b,n+".png")});return o}
o.tBlob=o.bl=function(){c.toBlob(function(b){sv(b)});return o}
o.fitRect= o.r=function(n1,n2,n3,n4){ 
        if(!n2){s=n1} else {s="rgba("+n1+","+n2+","+n3+","+n4+")"};
        o.c.save();
        o.c.fillStyle=s;
        o.c.fillRect(0,0,o.w(),o.h());
        o.c.restore()};
o.$=function(a){
        q.click(function(e){
            var x=e.clientX,y=e.clientY;
            a(x-c.x(),y-c.y(),x,y)});
        return o}   
o.$$=function(a){
    q.dblclick(function(e){
        var x=e.clientX, y=e.clientY;
        a(x-c.x(),y-c.y(),x,y)})
    return o}


}





brush = function(){
        o.dI=function(){x.drawImage.apply(x,arguments)}
        o.d =function(i,x,y){
            x=x||0;y=y||0;
            if(Im(i)){o.dI(i,x,y);
                return o}
            else{Im(i,function(i){o.dI(i,x,y)});
                return o}}
        o.D=function rc(i,x,y){var ;
            if(Im(i)){
                o.dI(i,x- i.w/2,y-i.h/2);
                return o}
            else{Im(i,function(i){rc(i,x,y)});
                return o}}
        o.dz=function(i,z){this.d(i,0,0,z,z,0,0,z,z)}
        o.fit=function rc(a,x,y){x=x||0;y=y||0;
            if(Im(a)){o.d(a,x,y,o.w(),o.h())}
            else{Im(a,function(i){rc(i,x,y)})}
            return o}
        o.puzzleDraw=function f(i,x,y){
            var G=(arguments),g= rest(G);
            g[1]=x||0; g[2]=y||0;
            Im(i,function(i){ cx( 'd', [i].concat(g) )  })
            return o}
        o.drawCenter=function(i){
            if(Im(i)){o.d(i,(o.w()/2)-(i.w/2),
                (c$.h()/2)-(i.h/2)); return o}
            else{Im(i, function(i){o.d(i)});
                return o}}
        o.centerDraw= o.cD=function(i){
            if(Im(i)){
                o.d(i,(o.w()/2)-(i.w/2),
                    (o.h()/2)-(i.h/2));
                return o}
            else{Im(i,function(i){o.d(i)});
                return o}}
        $(function(){


            a=can('green');
            c = sC(a)



            Im('me', function(i){
                //o.di( i,0,0, o.w(),o.h() )
                o.fit(i)
            })
            //o.fit('me')

        })
        o.g=function(w,h){return x.getImageData(w||o.w(),h||o.h())}
        o.G2=function(x,y,w,h){return cx('gi',x||0,y||0,w||o.w(),h||o.h())}
        o.p=function(d,x,y){return x.putImageData(d,x||0,y||0)};
        o.P2=function(d,x,y){return cx('pi',d,x||0,y||0)}
        o.gp=function(c,d){return o.p(o.g(c),d)};
        o.cp=function(y,d){return o.p(cD(y.g(),d))}
        o.Tr=x.translate;
        o.R=x.rotate;
        o.S=x.scale;
        o.af=function(a,b,c,d){      //transformations
            if(a=='t'){x[tl](a,b,c,d)};
            if(a=='r'){x[rt](a,b,c,d)};
            if(a=='s'){x[sc](a,b,c,d)};
            if(a=='k'){x[sk](a,b,c,d)};
            return o}
    }




vector=function(){

    o.fill=function(a,b,c,d){var G=arguments;
        if(U(a)){return cx('c')}
        if(!U(d)){return cx('fr',G)}
        if(!U(c)){return cx('ft',G)}
        if(!U(b)){o.pop('s', b)};
        return o.pop('f',a)}
    o.fill2=function(a,b,c,d){  //fill
        if(U(a)){return o[fl]()}
        if(if(!U(d)){return o[fr](a,b,c,d)}
        if(if(!U(c)){return o[ft](a,b,c)}
        if(!U(b)){o.pop('s',b)};
        return o.pop('f',a)}
    o.path=o.p=function(a,b,c,d){var ;
        if(U(a)){cx('b');return o}
        if(a==='0'){return cx('c')}
        if(a==='!'){return cx('cl')}
        if(d){return cx('rc',G)}
        return cx('m', G)}
    o.path2=function(a,b,c,d){   //path
        if(U(a)){x[bp]();return o}
        if(a==='0'){return o[cp]()}
        if(a==='!'){return o[cl]()}
        if(d){return o[re](a,b,c,d)}
        return o[mt](a,b)}
    o.stroke=o.s=function(a,b,c,d){
        var  l1={r:'round',f:'butt',s:'square'},
            l2={r:'round',b:'bevel',m:'miter'}, G=arguments;

        if(U(a)){cx('s');return o}
        if(S(a)){if(b){return o.pop('c',l1[a]).pop('j',l1[1][b])};
            return o.pop('s',a)}

        else{if(N(d)){cx('sr',G)}

        else if(N(c)){cx('st',G)}
        else if(N(b)){o.t(a,b)}
        else{o.pop('w',a)}
            return o}}
    o.stroke2=function(a,b,c,d){
        if(U(a)){x[so]();
            return o}
        if(S(a)){if(b){return o.pop('c',
            LN[0][a]).pop('j', LN[1][b])};
            return o.pop('s',a)}
        else{if(N(d)){return o[sr](a,b,c,d)}
        else if(N(c)){return o[st](a,b,c)}
        else if(N(b)){o.t(a,b)}
        else {o.pop('w',a)}
            return o}}
    o.circle=function(x,y,r){
        o.arc(x,y,r,0,PI2,false);o.fill().stroke();return o};
    o.circleMini=function(x,y,r){
        x.a(x,y,r,0,PI2,false);
        x.f().k(); return o};
    o.arc=function(){
        x.arc();
        return o}
    o.t=o.to=lineOrArcTofunction(a,b,c){
        var g="arguments";

        if(N(b)){x[lt](a,b)};
        if(N(c)){x[at].apply(x,g)}
    }
    o.rrHQuest=function(){
        on(function(g){g.f('blue').dc(_.r(800),_.r(300),_.r(100))})
    }
}


