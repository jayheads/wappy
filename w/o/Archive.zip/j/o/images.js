


images=function(){
    tU=function(a){var u="toDataURL";
        if(a===undefined){return}
        if(iB(a)){a=a.image.src}
        if(iI(a)){a=a.src}
        if(a[u]){a=a[u]()}
        else if(iF(a.u)){a=a.u()};
        if(iS(a)&&!iDu(a)){
            a=p$(png(a),'/')};
        function png(a){return e$(a,'png')}
        return a}
    tI=function(a){if(a){return(iB(a))?f(a.image):a} }
    sI=function(i){i=i||new Image();

        i.a=function(a){var t=this;
            t.addEventListener('load',a);
            return t}

        i._s=function(a){this.src=tU(a);return this}
        i.d=function(a){return $do(this,b)};
        i.s=function(a){var t=this;
            if(!a){return t.src}
            else{return t._s(a)}};
        i.r=function(f){return this.a(function(i){f(i.target)})};
        i.r(function(i){i.w=i.width;i.h=i.height});
        return i}
    sI2=function(i){
        i=sEl(i||new Image());
        i.a=function(a){var t=this;
            t.addEventListener('load',a);
            return t}
        i.s=function(a){var t=this;
            if(a===undefined){return t.src}
            else{t.src=tU(a)};
            return t};
        i.r=function(F){
            return this.a(
                function(i){var g=i.target;
                    F(g,sEl(g))})};
        i.r(function(i){
            i.w=i.width;i.h=i.height});
        return i}
    I=function(a,b){if(!(a=tI(a))){return sI()};
        if(!b){if(iI(a)){return sI(a)};
            if(iF(a)){return sI().r(a)};
            if(iS(a)){return sI().s(a)}}
        else{if(iI(a)){return $do(sI(a),b)};
            if(iS(b)){return I().r(function(i){$W[b]=i}).s(a)};
            if(iF(b)){return I().r(b).s(a)}}}
    I2=function(a,b){//if(a!=tI(a)){;
        if(b===undefined){return sI()}
        if(b===undefined){
            if(iF(a)){return sI().r(a)};
            if(iS(a)){return sI().s(a)}
            $l('!');return}

        if(iS(b)){
            return I().r(function(i){
                $W[b]=i
            }).s(a)};

        if(iF(b)){
            return I().r(b).s(a)
        }}
}



images=function(){


    tU=function(a){
        var u="toDataURL";
        if(U(a)){return}
        if(B(a)){a=a.image.src}
        if(I(a)){a=a.src}
        if(a.u){a=a.u()}
        else if(F(a.u)){a=a.u()};
        if(S(a)&&!D(a)){
            a=p$(png(a),'/')};
        function png(a){
            return e$(a,'png')}
        return a}
    tI=function(a){if(a){
        return(B(a))?f(a.image):a} }


    sI=function(i){i=i||new Image();
        i.a=function(a){var t=this;
            t.addEventListener( 'load' , a);
            return t}
        i._s=function(a){this.src=tU(a);
            return this}
        i.d=function(a){return $do(this, b)};
        i.s=function(a){var t=this;
            if(!a){return t.src}
            else{return t._s(a)}};
        i.r=function(f){return this.a(function(i){
            f(i.target)})};
        i.r(function(i){i.w=i.width;
            i.h=i.height});
        return i}

    sI2=function(i){
        i=sEl(i||new Image());
        i.a=function(a){var t=this;
            t.addEventListener('load',a);
            return t}
        i.s=function(a){var t=this;
            if(a===undefined){return t.src}
            else{t.src=tU(a)};
            return t};
        i.r=function(F){
            return this.a(
                function(i){var g=i.target;
                    F(g,sEl(g))})};
        i.r(function(i){
            i.w=i.width;i.h=i.height});
        return i}
    I=function(a,b){if(!(a=tI(a))){return sI()};
        if(!b){if(iI(a)){return sI(a)};
            if(F(a)){return sI().r(a)};
            if(S(a)){return sI().s(a)}}
        else{if(iI(a)){return $do(sI(a),b)};
            if(S(b)){return I().r(function(i){$W[b]=i}).s(a)};
            if(F(b)){return I().r(b).s(a)}}}
    I2=function(a,b){//if(a!=tI(a)){;
        if(b===undefined){return sI()}
        if(b===undefined){
            if(F(a)){return sI().r(a)};
            if(S(a)){return sI().s(a)}
            $l('!');return}

        if(S(b)){
            return I().r(function(i){
                $W[b]=i
            }).s(a)};

        if(F(b)){
            return I().r(b).s(a)
        }}
}





tU=function(a){var o=arg(arguments);if(U(a)){return}
    if(F(a)){a=a()}
    if(F(a.toDataURL)){a = a.toDataURL()}
    if(F(a.u)){a=a.u()}
    if(I(a)){a=a.src}
    if(S(a)){a=prefix(png(a),'/')}
    return a}

var iU=function(){


}

//tI=function(a){if(a){return(B(a))? f(a.image):a} }


ag= "var o=args(arguments);";

sIm=function(im){

    im=im||new Image();

    var i=function(){eval(ag);

        if(tU())){im.src=    }

        return im}


    i.a=function(a){im.addEventListener('load', a); return i}

    i.s=function(a){im.src = tU(a); return i}

    i.u=function(a){if(!a){return im.src} else {return i.s(a)}};

    i.r=function(f){return i.a(function(i){f(i.target)})};

    i.w=function(a){if(!a){return im.width} else{im.width=a; return i}};

    i.h=function(a){if(!a){return im.height} else{im.height=a; return i}};

    i.r(function(i){i.w = im.width; i.h = im.height});

    return i}





Im=function(a,b){var o=arg(arguments)

    if(o("I")){return sIm(tU(a))}

    if(o("i")){ return sIm(a) }

    if(o("f")){return sIm(a).r(a)}
    if(o("s")){return sIm(a).s(a)}
    if(o("iU")){return $do(sI(a),b)}
    if(o("Us")){return I().r(function(i){$W[b]=i}).s(a)}
    if(o("Uf")){return I().r(b).s(a)}}



images=function(){
    tU=function(a){var u="toDataURL";
        if(a===undefined){return}
        if(iB(a)){a=a.image.src}
        if(iI(a)){a=a.src}
        if(a[u]){a=a[u]()}
        else if(F(a.u)){a=a.u()};
        if(S(a)&&!iDu(a)){
            a=p$(png(a),'/')};
        function png(a){return e$(a,'png')}
        return a}
    tI=function(a){if(a){return(iB(a))?f(a.image):a} }
    sI=function(i){i=i||new Image();

        i.a=function(a){var t=this;
            t.addEventListener('load',a);
            return t}

        i._s=function(a){this.src=tU(a);return this}
        i.d=function(a){return $do(this,b)};
        i.s=function(a){var t=this;
            if(!a){return t.src}
            else{return t._s(a)}};
        i.r=function(f){return this.a(function(i){f(i.target)})};
        i.r(function(i){i.w=i.width;i.h=i.height});
        return i}
    sI2=function(i){
        i=sEl(i||new Image());
        i.a=function(a){var t=this;
            t.addEventListener('load',a);
            return t}
        i.s=function(a){var t=this;
            if(a===undefined){return t.src}
            else{t.src=tU(a)};
            return t};
        i.r=function(F){
            return this.a(
                function(i){var g=i.target;
                    F(g,sEl(g))})};
        i.r(function(i){
            i.w=i.width;i.h=i.height});
        return i}
    I=function(a,b){if(!(a=tI(a))){return sI()};
        if(!b){if(iI(a)){return sI(a)};
            if(F(a)){return sI().r(a)};
            if(S(a)){return sI().s(a)}}
        else{if(iI(a)){return $do(sI(a),b)};
            if(S(b)){return I().r(function(i){$W[b]=i}).s(a)};
            if(F(b)){return I().r(b).s(a)}}}
    I2=function(a,b){//if(a!=tI(a)){;
        if(b===undefined){return sI()}
        if(b===undefined){
            if(F(a)){return sI().r(a)};
            if(S(a)){return sI().s(a)}
            $l('!');return}

        if(S(b)){
            return I().r(function(i){
                $W[b]=i
            }).s(a)};

        if(F(b)){
            return I().r(b).s(a)
        }}
}


images=function(){
    tU=function(a){var u="toDataURL";
        if(a===undefined){return}
        if(iB(a)){a=a.image.src}
        if(iI(a)){a=a.src}
        if(a[u]){a=a[u]()}
        else if(F(a.u)){a=a.u()};
        if(S(a)&&!iDu(a)){
            a=p$(png(a),'/')};
        function png(a){return e$(a,'png')}
        return a}
    tI=function(a){if(a){return(iB(a))?f(a.image):a} }
    sI=function(i){i=i||new Image();

        i.a=function(a){var t=this;
            t.addEventListener('load',a);
            return t}

        i._s=function(a){this.src=tU(a);return this}
        i.d=function(a){return $do(this,b)};
        i.s=function(a){var t=this;
            if(!a){return t.src}
            else{return t._s(a)}};
        i.r=function(f){return this.a(function(i){f(i.target)})};
        i.r(function(i){i.w=i.width;i.h=i.height});
        return i}
    sI2=function(i){
        i=sEl(i||new Image());
        i.a=function(a){var t=this;
            t.addEventListener('load',a);
            return t}
        i.s=function(a){var t=this;
            if(a===undefined){return t.src}
            else{t.src=tU(a)};
            return t};
        i.r=function(F){
            return this.a(
                function(i){var g=i.target;
                    F(g,sEl(g))})};
        i.r(function(i){
            i.w=i.width;i.h=i.height});
        return i}
    I=function(a,b){if(!(a=tI(a))){return sI()};
        if(!b){if(iI(a)){return sI(a)};
            if(F(a)){return sI().r(a)};
            if(S(a)){return sI().s(a)}}
        else{if(iI(a)){return $do(sI(a),b)};
            if(S(b)){return I().r(function(i){$W[b]=i}).s(a)};
            if(F(b)){return I().r(b).s(a)}}}
    I2=function(a,b){//if(a!=tI(a)){;
        if(b===undefined){return sI()}
        if(b===undefined){
            if(F(a)){return sI().r(a)};
            if(S(a)){return sI().s(a)}
            $l('!');return}

        if(S(b)){
            return I().r(function(i){
                $W[b]=i
            }).s(a)};

        if(F(b)){
            return I().r(b).s(a)
        }}
}
im=function(a, b){var o=arg(arguments);

    var i=new Image()

    if(o('s')){   }







}



images=function(){


        tU=function(a){ var o=arg(arguments)
            var u="toDataURL";
            if(U(a)){return}
            //if(B(a)){a=a.image.src}
            if(I(a)){a=a.src}
            if(F(a.u)){a = a.u()};
            o('sD',function(){a=p$(png(a),'/')}
            function png(a){return e$(a, 'png')}
            return a}

   e$=function(a,b){if(!b){
            return c$(a,'.')?ali$(a, '.'):false};
            if(!e$(a)){a += p$(b,'.')};return a}



        tI=function(a){if(a){
            return(B(a))?f(a.image):a} }


        sIm=function(im){

            im = im||new Image();

            var i={}

            i.a=function(a){im.addEventListener( 'load' , a);return i}
            i.s=function(a){im.src = tU(a);return i}
            i.u=function(a){if(!a){return im.src} else {return i.s(a)}};
            i.r=function(f){return i.a(function(i){f(i.target)})};
            i.w=function(a){if(!a){return im.width} else{im.width=a; return i}};
            i.h=function(a){if(!a){return im.height} else{im.height=a; return i}};

            i.r(function(i){i.w=im.width;i.h=im.height});



            return i}





ssI=function(i){
    i=i||new Image()
    i.a=function(a){var t=this;
        t.addEventListener('load',a);
        return t}
    i.s=function(a){var t=this;
        if(U(a)){return t.src}
        t.src = tU(a);return t}
    i.r=function(F){
        return this.a(
            function(i){var g=i.target;
                F(g,sEl(g))})};
    i.r(function(i){
        i.w=i.width;i.h=i.height});
    return i}


        Im=function(a,b){if(!(a=tI(a))){return sI()};
            if(!b){if(I(a)){return sI(a)};
                if(F(a)){return sI().r(a)};
                if(S(a)){return sI().s(a)}}
            else{if(I(a)){return $do(sI(a),b)};
                if(S(b)){return I().r(function(i){$W[b]=i}).s(a)};
                if(F(b)){return I().r(b).s(a)}}}


        I2=function(a,b){//if(a!=tI(a)){;
            if(U(a)){return sI()}
            if(U(b)){
                if(F(a)){return sI().r(a)};
                if(S(a)){return sI().s(a)}
                 }

            if(S(b)){
                return I().r(function(i){
                    $w[b]=i
                }).s(a)};

            if(F(b)){
                return I().r(b).s(a)
            }}
    }






tU=function(a){var u="toDataURL";
    if(a===undefined){return}
    if(iB(a)){a=a.image.src}
    if(iI(a)){a=a.src}
    if(a[u]){a=a[u]()}
    else if(F(a.u)){a=a.u()};
    if(S(a)&&!iDu(a)){
        a=p$(png(a),'/')};
    function png(a){return e$(a,'png')}
    return a}

tI=function(a){if(a){return(iB(a))?f(a.image):a} }
sI=function(i){i=i||new Image();

    i.a=function(a){var t=this;
        t.addEventListener('load',a);
        return t}

    i._s=function(a){this.src=tU(a);return this}
    i.d=function(a){return $do(this,b)};
    i.s=function(a){var t=this;
        if(!a){return t.src}
        else{return t._s(a)}};
    i.r=function(f){return this.a(function(i){f(i.target)})};
    i.r(function(i){i.w=i.width;i.h=i.height});
    return i}



sI2=function(i){
    i=sEl(i||new Image());
    i.a=function(a){var t=this;
        t.addEventListener('load',a);
        return t}
    i.s=function(a){var t=this;
        if(a===undefined){return t.src}
        else{t.src=tU(a)};
        return t};
    i.r=function(F){
        return this.a(
            function(i){var g=i.target;
                F(g,sEl(g))})};
    i.r(function(i){
        i.w=i.width;i.h=i.height});
    return i}



I=function(a,b){if(!(a=tI(a))){return sI()};
    if(!b){if(iI(a)){return sI(a)};
        if(F(a)){return sI().r(a)};
        if(S(a)){return sI().s(a)}}
    else{if(iI(a)){return $do(sI(a),b)};
        if(S(b)){return I().r(function(i){$W[b]=i}).s(a)};
        if(F(b)){return I().r(b).s(a)}}}



I2=function(a,b){//if(a!=tI(a)){;
    if(b===undefined){return sI()}
    if(b===undefined){
        if(F(a)){return sI().r(a)};
        if(S(a)){return sI().s(a)}
        $l('!');return}

    if(S(b)){
        return I().r(function(i){
            $W[b]=i
        }).s(a)}

    if(F(b)){  return I().r(b).s(a) } }





