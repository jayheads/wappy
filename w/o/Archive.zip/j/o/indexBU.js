_$=function(a,b){oB(b).append(a);return a};
$_=function(a,b){oB(b).prepend(a);return a}


jj=jo=function f(a,b,c){
    return   (c)?  f(c, f(a,b)):
        (!b)?       a:  (!a)?       b:   (U(b[a]))?  a:    b[a]}

$j=ji=function(a,b){
    return ( U(b)&&!F(a) )? a:
        ( U(b)&&F(a) )? a():
            (F(a))? b(a):b }
$m= mm = mustObtain=function(a,b,c){     // this is a normal getter.
    // u use at global, level1 or level2
    return (U(a))?false:
        (U(b))?  $f[a]    // it returns exactly what u ask for
            :(U(c))?  a[b]      // that could be undefined
            :         a[b][c]}






 //return(c)?a[b][c]:(b)?a[b]:(a)?$f[a]:false

   // return   (c)?f(c,f(a,b)):  (b)? b[a]||a||b


 //   if( F(a) ){ return (b)?  b(a) :  a()}  return (b)?  b:     a}










                      //jo
oOo=function(o){ return _D(o,oo) }
oO = oOo(function f(a,b){ return (U(a))? _K(f):  (a==="*")? $r(b||'c'): jo(a,f,b)}) // get keys,result,random//safe
Oo = oOo(function f(a,b){if(a&&b){return $m(f,a,b)}})

//jo
ss=function(a,b,c){


    var cc =function f(a,b,c){

        if(O(b)){

            _e(b, function(k, v){ f(a, v, k) }); return a}

        if(U(c)){

            return  a.css( oO('S',b) )};

        a.css( oO('S',b),  oO(jo(b,oO('R')), c)     );

        return a}



    var ss=function(a){a=$(oB(a));

        return function f(b,c){if(U(b)){return a}

            if(F(b)){return b(a)}

        if(S(b) && U(c)) {return cc(a,b)}

        cc(a,b,c);return f}}



    if(U(b)){return ss(a)}

    return cc(a,b,c)}



//ji






                  //ji


ee = $e = function(a,b,c,d,e){

    var t=function(a,b){return $($l("<"+oO('t',a||'d')+" "+(b||'')+">")) }

    var df= function(a,b){return _D(a||{},oO('D'||b))};

    a=ji(a);

    if(Z(a)){return t()}


    if(U(a)){

        return css(t(),df())};

    if(S(a) && (S(b))){

        return (Z(c)) ? t(a,b):

               css( t(a,b), df(e) )}

    if(S(a)){

        if(Z(b)){return t(a)}

        if(U(b)){

            return css(t(a), df()) }

        if(O(b)){

            return css(t(a), df(b)) }

        if(O(a)){

            if(S(b)){

                a = qq( a )(b, c) }

            if( Q(a)||E(a) ){

                a = css( a, b|| df() ) }

            else{

                a = css( t(),

                        (Z(c)) ?  b:  df(b) )  }

            return a}

    }  }















$o=function(o){ return function(a,b){  return(Z(b))? Oo(o,a): oO(o,a)} };  oS=$o('S'); Co=$o('c'); oQ=$o('Q'); Qo=$o('q',0); oX=$o('X'); Xo=$o('x',0)




rr=$r=function(a){ a=a||'c';  var r=function(o){return _R(Zz(oO(o)))};  return tA(oO(a))[r(a)]}

rot=function(a){return jo(a,oO('R'))}



$i=function f(a,b,c,d){var o;

    if(!U(d)){o = f(b,c,d);  a[ o.k ] = o.v; return  a[ o.k ] }

    if(!U(c)){ return {k: oO(a, b), v: oO( rot(b) , c)}  }

}


    //  $i(X,'gc','di')


bb=$b=function(a){ if(U(a)){return $("body")};   if(Z(a)){return $b().empty()};  $b().append(a);return a}






                                  //ji

$f = fo = font = makeFont = function rc(a){

    var F, W, S, Z, f='fantasy', n='normal',

        p=function(a){return a+'px'},

        z=function(a){a=chop(a);
            return p(a[0])+((a[1])?'/'+p(a[1]):'')};

    _e(pS(a),
        function(p){
            if(V(p[0])){Z=z(p)};
            F=F||Oo('ff',p);
            W=W||Oo('fw',p);
            S=S||Oo('fs',p)})

    return $l([W||n,S||n,Z||p(100),F||f].join(' '))}

$c=cC=function f(a,b,c,d){
    var mC=function(r,w,h){var C, s='',
            p=function(a){return(U(a))?' ':' '+a+' '},
            cl=function(a){ if(a){return Oo('c',a)} else  {return $r()}},
            k=function(a,b){
                if(N(b)){s=a+"="+b};
                if(S(b)){s="style='"+a+":"+b+"'"};
                return p(s)};
            return(function(a,b){
                return $( $l( $e(a,b,0) ) )[0]}(
                    'c',k(bg, cl(r)) + k("width",w) +k ("height",h)))},
        df={c:null, z:4},
        bg=oO('S','C')

    if(U(a)){C=mC(df.c,df.z*100,df.z*100 )}
    if(S(a)&&U(b)){C=mC(a,df.z*100,df.z*100)}
    if(S(a)&&N(b)&&U(c)){C=mC(a,b*100,b*100)}
    if(S(a)&&N(b)&&N(c)){C=mC(a,b*100,c*100)}
    if(N(a)&&U(b)){C=mC(df.c,a*100,a*100)}
    if(N(a)&&N(b)){C=mC(df.c,a*100,b*100)}
    if(a==="<"){C=$_(f(b,c,d))}
    if(a===">"){C=_$(f(b,c,d))}
    C.h=C.outerHTML;
    C.x=C.getContext('2d')
    return C}






qq=function(a){a=$(oB(a))

    return function f(b){

        if(U(b)){return a}

        if(F(b)){return b(a)}

        if(S(b)){


            a = a[ oO('q',b)  ].apply(a,_m(_r(arguments),ji) )

            return f}
    }
}






gg=function f(a,b,c,d){a=ji(a)
    if(O(b)){_e(b,function(v,k){f(c,k,v,a)});return a}
    if(U(b)){return function(b){return function(c,d){return f(b,a,c,d)}}}
    if(U(c)){return f(a,{},b)}
    if(!U(d)){$i(a,b,c,d)}
    return a[oO(oO(b),c)]}






xx = function(a){  //$x reserved in console for xpath
    var f=function(b){
        if(U(b)){return f.x}
        f.x[ Oo('x',b) ].apply(f.x, _r(arguments))
       return f}
    f.c=(E(a))?a:((Q(a)))?a[0]:(O(a))?a:$c.apply(this,arguments)
    f.x=xX( f.c )
    return f}



pop=function f(a,b,c,d){
    a = ji(a)

    if(O(b)){_e(b,function(v,k){
        f(c,k,v,a)});return a}

    if(U(b)){return function(b){

        return function(c,d){
            return f(b,a,c,d)}}}

    if(U(c)){return f(a,{},b)}
    if( !U(d) ){$i( a,b,c, d) }

    return a[oO(  oO(b),  oO(jo(b,    oO('R')) ,     c)  )]}
xp=pop('X')  ///oO(  jo(b, oO('R')  )
xm=function(a){

    var f=function(b){if(U(b)){return f.x}
        f.x[ Oo( 'x', b ) ].apply( f.x, _r( arguments ) )
        return f}

    f.c =(E(a))? a: ((Q(a)))?  a[0]:
        (O(a))? a: $c.apply(f,arguments)

    f.x =xX(f.c); return f}



// a brilliant function that you pass a canvas  to; it returns a fn that lets u make calls on the ctx by using the abbreviated obj keys


// an oo is a fn-ob that provides dependencies in a simple and awesome way!
// oOo is an abstract class for making oo's,
// which lets CLIENT determine  the function of the function object made from object oo !!!


//$i2 = function(I,k,v){return{k:oO(I,k),v:oO(k,v)}}
// k:k-safeTried-against-I,  v:v-safeTried-against-k || examples:
// $i(oO('S'))('dp','f')  -> k:'display',  v:'table-footer-group'
// $i(oO('S'))('dp')  --> k:'display',v:{(i:'inline')..}
// $i(oO('S'))('dp','zzz')   -->  'display':'zzz'
// $i('zzz','zzz')  --> 'zzz':'zzz'
// $i(oO('S'))('abc')--> 'abc':'abc'
// $i('zzz','zzz')  --> cool !//gen -> $i
//ex:  xi(  {hello:4},   {},    'hello'  ) --> 4
// xi(  {a:4},  {h:'hello'},  'h'   )  --> 4
//xi(  {display:3},'S', 'dp' ) -->3
//xi(  {display:3},'S', 'dp',5 )    --> {display:5}
//? xi(ctx,'X',gc, val )
//set/adds properties from a passed-in-ob(pi-Ob), to a pi-jQob
//if(S(b)){return $i(a,b,c)}




