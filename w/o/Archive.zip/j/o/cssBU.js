oo=function(o,b){ if(U(b)){return _D(o,ooo)};
    return function(a){return o(b, a)}}
oO=oo(function f(a,b,c){
    if(U(a)){return _K(f)};
    if(b==="*"){return ran(a)}
    if(U(b)){return f[a]||a}
    if(U(c)){if(f[a]&&f[a][b]){
        return f[a][b]};
        return b}
    return f(f(c,a),b)})

Oo=oo(function f(a,b){return (!U(b))?f[a][b]:f[a]});




ran=function(a){a=a||'c';
    var r=function(o){
        return _R(Zz(oO(o)))};
    return tA(oO(a))[r(a)]}
met=function(i,e,args,fn){
    var f=_f(args),r=_r(args);
    if(fn){r=map(r,fn)}
    return e[oO(i,f)].apply(e,r)}
pop=function f(i,e,p,v){
   var kv=function (i,p,v){return { k:oO(i,p), v:oO(p,v,'R')}}
    if(U(e)){return _p(f,i) }
    if(U(p)){return _p(f,i,e)}
    if(O(p)){_e(p,function(v,k){f(i,e,k,v)});return e}
    if(v==="*"){return f(i,e,p,ran(p))}
    var o=kv(i,p,v);if(v){e[o.k]=o.v};return e[o.k]}



Tag=function(a,b,c){
    return "<"+oO('t', a||'d')+" "+(b||'')+">"+ (c||'')+ "</>"}

tag=function(a,b,c){
    var t;
    if(O(b)){t=$('<'+oO(a)+'>', b)}
    else {t=$(Tag(a,b,c))}

return $l(t)}






css=function f(jq,b,c){

    var ss=function(jq,b,c){

        var k = oO('S',b)

        if(U(c)){return jq.css(k)}

        jq.css(k, oO(b,c,'R')); return jq}



    var Ss =function(jq,ob){
        _e(ob,function(k,v){
            ss(jq,v,k)})
        return jq}

    if(O(b)){return Ss(jq,b)}
    return ss(jq,b,c)
}


def=function(a,b){
    return _D(a||{}, oO(b||''+'D'))}


el=function f(a,b){
    if(S(a)){return css(tag(a), def(b))}
    if(O(a)){return css(tag(), def(a))}}


tQ=function f(a,b,c){
    var s=css;
    if(Q(a)){return   s(a,b,c)}
    if(Q(a.q)){return s(a.q,b,c)}
    if(E(a)){return   s($(a),b,c)}
    return el(a,b)}




qq=function(a,b,c){

    var o=function f(b){
        if(b.q){b=b.q}
        if(F(b)){return b(f.q)}
        if(Z(b)){return f.emp()}
        if(U(b)){return f.ch()}
        if(S(b)){f.met(b)}
        if(O(b)){css(f.q, b); return f}
        return f('ap', b)}

    o.q=tQ( a,b,c )

    o.s=function(a,b){return css(o.q,a,b)}
    o.m=function(b){o.q = met('q',o.q, arguments,tQ);return o}
    o.e=function(){o.q.empty(); return o()}
    o.C=function(){return o.q.children()}
    o.w=function(w,b) {
        if(U(w)){return o.q.width()}
        if(w==='+'){return o.w( o.w()+b ) }
        if(w==='*'){return o.w( o.w()*b) }
        if(w==='%'){return o.w( o.w()*b *.01 ) }
        return o.q.width(  (w<10)?w*100:w  )}
    o.h=function(h,b) {
        if(U(h)){return o.q.height()}
        if(h==='+'){return o.h( o.h()+b ) }
        if(h==='*'){return o.h( o.h()*b) }
        if(h==='%'){return o.h( o.h()*b *.01 ) }
        return o.q.height(  (h<10)?h*100:h)}
    o.z=function(z,b) {
        if(U(z)){
            //return {    w:o.q.width(), h:o.q.height()  }
            return o.ch().size()
        }

        if(z==='+'){ o.w( o.w()+b );o.h( o.h()+b )      }
        if(z==='*'){ o.w( o.w()*b );o.h( o.h()*b )   }
        if(z==='%'){ o.w( o.w()*b * .01 );
            o.h( o.h()*b *.01 )  }
        o.h(z); o.w(z)
        return o}
    o.x=function(x) {if(!x){return o.q.offset().left}
        return parseInt( x - o.x() )}
    o.y=function(y){if(!y){return o.q.offset().top}
        return parseInt( y - o.y() )}
    o.o=function(a,b,c){
        o.q.bind(oO('e',a),b,c);
        return o
    }
    o.$=function(a){
        o.o('click',
            function(e){
                var x=e.clientX,
                    y=e.clientY;
                var t= e.target;t.e=e;
                a(qq(t), x - o.x(), y - o.y(), x, y)});
        return o}
    o.$$=function(a){
        o.o('dblclick',
            function(e){
                var x=e.clientX,y=e.clientY;   var t= e.target;t.e=e;
                a(qq(t),x - o.x(),  y - o.y(), x, y )});



        return o}
    o.t=function(a){o.q.text(a);return f}
    o.__=function(a){return o.q.hasClass(a)}
    o._=function(a){o.q.addClass(a);return o}
    return o}





//f.q[oO('q',b)].apply(f.q, _m( _r(arguments), tQ));
//o.can=function(){o(0); return $c('<',12) }


//tQ=function(a){  return (P(a))?  el(a): (E(a)||Q(a))?   $(a):  a.q}







bb=function(a){
    $("body").prepend(a||el());
    return a}



btn=function(a){
   var t= tag('b',
     " class='btn btn-lg ' " +
     " type ='submit' ").html(a)

    $l( t[0].outerHTML   )
     return t
 }



but=function(a,b){
    var bt= btn(a)

    if(F(b)){bt.click(b)}

    css(bt, 'C', ran())
    css(bt, 'c', ran())
         //,c:ran()})

    bt.dblclick(function(e){
      e=$( (e.target)  )

        $l( css(e, 'C')   )
        $l( css(e, 'c')   )

    })

    return bt}

$(function(){




  bb(
      b=but('hifsaasfsfd', function(){ })

  )



   bd=$("body")
})


//Entity, Index, Pop, Value
//rO=function(a,b){return oO(oO('R',a),b)}
// oC=oo(oO,'c');  oS=oo(oO,'S'); oX=oo(oO,'X');  ox=oo(oO,'x');Xo=oo(Oo,'x'); oq=oo(Oo,'q');  oQ=oo(oO,'Q');





sq=function f(a){
    var ag=arguments,n=0;
    _e(ag,function(a){n+=(a*a)})
    return n}
sqr=function f(a,b){var ag=arguments;
    if(U(b)){return $M.sqrt(a)};
    return f(sq.apply(this, ag))}
abs=function f(a,b){
    if(N(b)){return f(a-b)}
    return $M.abs(a)}

 ja=function(a,b){
     return map(arguments,function(a){
         if(O(a)){return _C([a.x, a.y, a.z])}
         return a})}



dst=function f(a,b){
    var ag=arguments;

    if(O(a)){
        ag=ja(a,b)
        a=ag[0]
        b=ag[1]}

    if(A(a)){
        return sqr.apply(
            this,
            map(a,function(v,k){
                return f(v, b[k])
            }))}

    return abs(a,b)}



xyz=function(x,y,z,l){

    if(A(x)){
        z=x[2];
        y=x[1];
        x=x[0]}

    return {
        x:x,
        y:y,
        z:z,
        l:l,
        dst:function f(a,b,c){

            if(O(a)){
                return dst(this, a)}
            if(A(a)) return f({x:a[0],y:a[1],z:a[2]})
        }
    }}



po=function(r,g,b){
    p16=function(a){return parseInt(a,16)}//hr=function(r){var f=$M.floor,n=256, v=p16(rr(r)); return new po(f((v/(n*n))%n),f((v/n)%n),f(v%n))}
    mF=$M.floor;
    nP=function(a){return a.replace("#","")}
    rgr=function(r){return r[0]+r[0]+r[1]+r[1]+r[2]+r[2]}
    z3=function(a){return _z(a)==3}


    if(S(r)){
        if(z3(a=nP(a))){a=rgr(a)}
        var v=p16(a)
        b=mf(v%256)
        g=mf((v/256)%256)
        r=mf((v/(256*256))%256)
    } return Po(r,g,b)}


poi=function(url,cb){
    var arr=[]
    $.getJSON(url,function(P){
        _e(P,function(p){
            arr.push(
                Po(p.x, p.y, p.z, p.l))})
        cb(arr)})}


tH=function(p){
    p=(p.x*(256*256)+p.y*256+ p.z).toString(16)
    while(_z(p)<6){p="0"+p}
    return "#"+p}



mD=minDist=function(p,Pnts){

    var P=po(p),m={di:Infinity, in:-1}

    _e(Pnts,function(p, pI){

        if(P.di(p) < m.di){

            m={   p:p,  d:P.di(p), l:p   }

        }}); return m}






cc=function(da){return {

    da:da||[],

    cl:function(p){var t=this,
        m=mD(p,t.da)
        t.lr=m.p;return m.l},

    cch:function(){ return tH(this.lr) }}}






url="http://gauth.fr/wp-content/uploads/2011/09/color_classif/dataset.js";
gj=function(){
    $.getJSON(url,
        function(da){$("body").text( da )})}

 $(function(){//$.getJSON( url, ) dad(dt)
 })
dt={
    "one": "Singular sensation",
    "two": "Beady little eyes",
    "three": "Little birds pitch by my doorstep"}
ul=function(a){return tag('ul', {"class":"list", html:a||''})}
id=function(a){return (U(a))?'':"id='"+a+"'" }
cob=function f(a,b){var corn=function(o,a,b){
    // this function returns a hash of css key/vals
    o[oO('S',a)]=oO(a,b,'R');return o}, o={}
    if(S(a)){corn(o,a,b)} else{_e(a,function(v,k){
        corn(o,k,v)})}; return o}
li=function(a,b){return tag('li', id(b), a)}
ul=function(a){var arr

    if (A(a)){arr=a} else {arr=arguments}

    var l=tag('ul', {"class":"list"} )

    _e(arguments, function(i){l.append(li(i))})

    return l}

// alt key!!! ≈≈∂ƒ˜©˙∆˚¥¨∫˜≤åß∂∑œ˜˜∫√˙˙√√√√√√√√ΩΩΩΩ≈≈ßß∂∂∑∆∂µ∆ß

