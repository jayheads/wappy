

STGMOUSE={d:"mousedown",m:"pressmove",u:"pressup",r:"rotation"};



TAG={c:"canvas", d:"div", i:"input", s:"span",f:"form",g:"img", b:"button", "1":"h1"};
QMETS={
    a:"after",
    at:"appendTo",
    ap:"append",
    ac:"addClass",
    ar:"removeAttr",
    b:"before",
    cr:"removeClass",
    c:"clone",
    d:"detach",
    e:"empty",
    hc:"hasClass",
    h:"height",
    ia:"insertAfter",
    ib:"insertBefore",
    ih:"innerHeight",
    iw:"innerWidth",
    l:"html",
    n:"position",
    o:"offset",
    op:"offsetParent",
    oh:"outerHeight",
    ow:"outerWidth",
    pp:"prepend",
    p:"prop",
    pt:"prependTo",
    pr:"removeProperty",
    r:"remove",
    ra:"replaceAll",
    rw:"replaceWith",
    s:"css",
    sl:"scrollLeft",
    st:"scrollTop",
    tt:"attr",
    tc:"toggleClass",
    t:"text",
    u:"unwrap",
    v:"val",w:"width",
    wr:"wrap",
    wa:"wrapAll",
    wi:"wrapInner"}
QSTATE={
    kf:"@keyframes",
    a:"animation",
    an:"animation-name",
    ad:"animation-duration",
    at:"animation-timing-function",
    al:"animation-delay",
    ac:"animation-iteration-count",
    ar:"animation-direction",
    ap:"animation-play-state",
    bg:"background",
    ba:"background-attachment",
    C:"background-color",
    bi:"background-image",
    bp:"background-position",
    br:"background-repeat",
    bl:"background-clip",
    bo:"background-origin",
    bs:"background-size",
    d:"border",
    dc:"border-color",
    ds:"border-style",
    dw:"border-width",
    dt:"border-top",
    dtc:"border-top-color"	,
    dts:"border-top-style",
    dtw:"border-top-width",
    dr:"border-right",
    drc:"border-right-color",
    drs:"border-right-style",
    drw:"border-right-width",
    db:"border-bottom",
    dbc:"border-bottom-color",
    dbs:"border-bottom-style",
    dbw:"border-bottom-width",
    dl:"border-left",
    dlc:"border-left-color",
    dls:"border-left-style",
    dlw:"border-left-width",

    o:"outline",
    oc:"outline-color",
    os:"outline-style",
    ow:"outline-width",
    di:"border-image",
    dio:"border-image-outset",
    dir:"border-image-repeat",
    disl:"border-image-slice",
    dis:"border-image-source",
    diw:"border-image-width",

    xs:"box-shadow",
    vs:"overflow-style",
    vx:"overflow-x",
    vy:"overflow-y",
    rt:"rotation",
    rp:"rotation-point",
    cp:"color-profile",
    op:"opacity",
    ri:"rendering-intent",
    h:"height",
    mh:"max-height",
    nh:"min-height",
    w:"width",
    mw:"max-width",
    nw:"min-width",

    xa:"box-align",
    xd:"box-direction",
    xf:"box-flex",
    xfg:"box-flex-group",
    bxl:"box-lines",
    xog:"box-ordinal-group",
    xo:"box-orient",
    xp:"box-pack",

    f:"font",
    ff:"font-family",
    fs:"font-size",
    fy:"font-style",
    fv:"font-variant",
    fw:"font-weight",
    fc:"@font-face",
    fj:"font-size-adjust",
    fh:"font-stretch",



    ct:"content",
    ci:"counter-increment",
    cr:"counter-reset",
    q:"quotes",
    crp:"crop",
    to:"move-to",
    pp:"page-policy",





    gc:"grid-columns",
    gr:"grid-rows",


    //linebox

    aj:"alignment-adjust",
    ab:"alignment-baseline",
    bh:"baseline-shift",

    dm:"dominant-baseline",
    daj:"drop-initial-after-adjust",
    dal:"drop-initial-after-align",
    dbj:"drop-initial-before-adjust",
    dbl:"drop-initial-before-align",
    dz:"drop-initial-size",
    dv:"drop-initial-value",

    ix:"inline-box-align",
    sk:"line-stacking",
    ss:"line-stacking-shift",
    st:"line-stacking-strategy",
    th:"text-height",
    ls:"list-style",
    li:"list-style-image",
    lp:"list-style-position",
    lt:"list-style-type",
    m:"margin",
    mt:"margin-top",
    mr:"margin-right",
    mb:"margin-bottom",
    ml:"margin-left",

    qd:"marquee-direction",
    qp:"marquee-play-count",
    qs:"marquee-speed",
    mq:"marquee-style",

    pd:"padding",
    pt:"padding-top",
    pr:"padding-right",
    pb:"padding-bottom",
    pl:"padding-left",




//page media
    ft:"fit",
    fp:"ftp",
    e:"image-orientation",
    g:"page",
    s:"size",

//positioning

    b:"bottom",
    cl:"clear",
    clp:"clip",
    u:"cursor",
    y:"display",
    fl:"float",
    l:"left",
    of:"overflow",
    r:"right" ,
    t:'top',
    p:'position',
    v:'visibility',
    z:"z-index",


//table
    co:"border-collapse",
    sp:"border-spacing",
    cs:"caption-side",
    ec:"empty-cells",
    ly:"table-layout",

//text
    c:"color",
    n:"direction",



    //hyperlink
    tg:"target",
    tn:"target-name",
    tw:"target-new",
    tp:"target-position",


    lts:"letter-spacing",
    lh:"line-height",
    ta:"text-align",
    td:"text-decoration",
    ti:"text-indent",
    ttf:"text-transform",
    ub:"unicode-bidi",
    va:"vertical-align",
    wh:"white-space",
    wo:"word-spacing",

    hp:"hanging-punctuation",
    pu:"punctuation-trim",
    tal:"text-align-last",
    j:"text-justify",
    tl:"text-outline",
    tv:"text-overflow",
    tsh:"text-shadow",
    twr:"text-wrap",
    wbr:"word-break",
    wwr:"word-wrap",

    //2d/3d
    tf:"transform",
    tfo:"transform-origin",
    ts:"transform-style",
    ps:"perspective",
    po:"perspective-origin",
    bv:"backface-visibility",



//transition
    tr:"transition",
    ty:"transition-property",
    tu:"transition-duration",
    tt:"transition-timing-function",
    te:"transition-delay",

    //user interface
    pe:"appearance",
    xz:"box-sizing",
    ic:"icon",
    ni:"nav-index",
    nl:"nav-left",
    dd:"nav-down",
    nr:"nav-right",
    nu:"nav-up",
    oo:"outline-offset",
    rs:"resize"
}
DISPLAY={
    i:"inline",
    b:"block",
    ib:"inline-block",
    t:"table",
    n:"none",
    '#':"inherit",
    it:"inline-table",
    l:"list-item",
    c:"table-column",
    r:"table-row",
    cg:"table-column-group",
    rg:"table-row-group",
    p:"table-caption",
    h:"table-header-group",
    f:"table-footer-group",
    e:"table-cell"}
POSITION={s:"static",a:"absolute",r:"relative",f:"fixed","#":"inherit"};
OVERFLOW={v:"visible",h:"hidden",s:"scroll",a:"auto","#":"inherit"};
STRETCH={n:"normal",
    sc:"semi-condensed",c:"condensed",ec:"extra-condensed", uc:"ultra-condensed",
    se:"semi-expanded", e:"expanded",  ee:"extra-expanded",  ue:"ultra-expanded"};
CURSOR={
    d:"default",
    p:"pointer",
    m:"move",
    e:"e-resize",
    ne:"ne-resize",
    nw:"nw-resize",
    n:"n-resize",
    se:"se-resize",
    sw:"sw-resize",
    s:"s-resize",
    w:"w-resize",
    t:"text",
    W:"wait",
    h:"help"}
THICKNESS = {'|':'thin','||':'medium','|||':'thick'};
DF={w:300, h:300, c:'/', C:'!', p:20, m:20,  y:'ib', f:'50px fantasy'};
DF1={
    w:300,
    h:300,
    c:'/',
    C:'!',
    p:20,
    m:20,
    y:'ib',
    f:'50px fantasy'
};
DF2={w:300,h:300,c:'/',bc:'!',p:20,m:20}
COLOR={
    "*":"Snow",
    "0":"Black",
    "!":"DeepPink" ,
    "'":"GhostWhite",
    "$":"Gold",

    "(":"BlanchedAlmond",
    "+":"CadetBlue",
    ":":"Chartreuse",
    ")":"Chocolate",
    "<":"Coral",
    "//":"DarkSlateBlue",
    "^": "DeepSkyBlue",
    "[":"FireBrick",
    "3":"FloralWhite",
    "?":"DarkOliveGreen",
    "%":"DarkOrchid",
    "~":"DarkSeaGreen",
    ".":"AntiqueWhite",
    ",":"CornflowerBlue",
    "`": "Cornsilk",
    "&":"DarkSlateGray",
    "#":"Thistle",
    "{":"RoyalBlue",
    "}":"Tomato ",
    "-":"SaddleBrown",
    ";":"RosyBrown",
    "=":"DarkGray",
    "@":"WhiteSmoke",

    '"':"MediumSpringGreen ",

    _:"LightSteelBlue",
    "~a":"Aquamarine",

    "`b":"AliceBlue",

    "!v":"BlueViolet",





    "!B":"SlateBlue",
    "!g":"LimeGreen",  "!b":"MidnightBlue ", "!G":"SeaGreen", "/":"LavenderBlush",
    "/g":"LightGray",
    _g:"LightGreen",
    _p:"LightPink",
    _s:"LightSalmon",
    _G:"LightSeaGreen",
    "|":"LightSkyBlue",
    _sg:"LightSlateGray",

    _y:"LightYellow",
    _b:"LightBlue",
    _co:"LightCoral",
    _c:"LightCyan",

    "-b":"MediumBlue",
    "-g":"MediumSeaGreen",
    "-s":"MediumSlateBlue ",
    "-o":"MediumOrchid",
    "-p":"MediumPurple ",
    "-t":"MediumTurquoise ",
    "-v":"MediumVioletRed ",

    "~G":"Gainsboro",
    "!t":"DarkTurquoise",
    "`!":"PaleGoldenRod",

    "^b":"SkyBlue",
    "`g":"SpringGreen",
    "`l":"Linen",
    "`c":"MintCream ",
    "`r":"MistyRose ",
    "`s":"SeaShell",
    "/b":"SandyBrown",
    "`G":"PaleGreen ",
    "`t":"PaleTurquoise ",
    "`q":"PaleVioletRed ",
    "db":"DodgerBlue",
    "bw":"BurlyWood",
    "!o":"OliveDrab ",
    "*!" :"NavajoWhite ",
    "!!":"MediumAquaMarine",
    "*b":"PowderBlue",
    "@b":"SteelBlue",
    li:"Lime",
    mg:"Magenta",
    or:"OrangeRed ",
    ir:"IndianRed",
    a:"Aqua",
    "b":"Blue",
    "bg":"Beige",
    "br":"Brown",
    "c": "Cyan",
    "cr": "Crimson",
    "d":"DimGray",
    e:"LemonChiffon",
    f:"ForestGreen",
    g:"Green",
    go:"GoldenRod",
    gr:"gray",
    gy:"GreenYellow",
    h:"HoneyDew",
    i:"Indigo",
    j:"PeachPuff",
    k:"Khaki",
    l:"Lavender",
    m:"Maroon",
    n:"Sienna",
    ol:"OldLace",
    ov:"Olive ",
    o:"Orange ",
    oc:"Orchid ",
    p:"Pink ",
    q:"Bisque",
    r:"Red",
    s:"Silver",
    t:"Turquoise",
    u:"Peru",
    v:"Violet" ,
    w:"Wheat",
    x:"SlateGray",
    y:"Yellow",
    z:"Teal",
    A:"Azure",
    B:"DarkBlue",
    C:"DarkCyan",
    D:"DarkGoldenRod",
    F:"Fuchsia",
    G:"DarkGreen",
    H:"HotPink",
    I:"Ivory",
    J:"Salmon",
    "K":"DarkKhaki",
    L:"LawnGreen",
    "M":"DarkMagenta",
    N:"Navy",
    "O":"DarkOrange",
    P:"Plum ",
    Q:"PapayaWhip ",
    "R":"DarkRed",
    "S":"DarkSalmon",
    T:"Tan",
    U:"Purple",
    V:"DarkViolet",
    W:"White",
    X:"LightGoldenRodYellow",
    Y:"YellowGreen",
    Z:"Moccasin"
}
BASELINE={
    s:'sub',
    S:'super',
    t:'top',
    tt:'text-top',
    m:'middle',
    b:'bottom',
    tb:'text-bottom'}
STYLE={"#":"inherit", n:"normal",i:"italic",o:"oblique"};
WEIGHT={n:"normal", "+":"bold", "++":"bolder", "-":"lighter", "*1":100, "*2":200, "*3":300,"*4":400, "*5":500, "*6":600, "*7":700, "*8":800, "*9":900};
DECORATION={u:"underline",o:"overline",l:"line-through",b:"blink"}
TRANSFORM={c:"capitalize",u:"uppercase",l:"lowercase"}  //SP!!!   <- ?
OSTYLE= {n:'none',h:'hidden','.':'dotted','-':'dashed',s:'solid',d:'double',g:'groove',r:'ridge','>':'inset','<':'outset',"#":'inherit'};
FACE={c:"cursive", f:"fantasy", m:"monospace", ss:"sans-serif", s:"serif"}
ALIGN={l:"left",r:"right",c:"center",j:"justify"   }
PATTERN={x:"repeat-x",y:"repeat-y",z:"no-repeat"}
CAP={r:'round',f:'butt',s:'square'},
JOIN={r:'round',b:'bevel',m:'miter'}
XS={// also part of S: tfMk, clPth
    ga:'globalAlpha',   //num
    wb:'shadowBlur',    //num
    wx:'shadowOffsetX',   //num
    wy:'shadowOffsetY' ,  //num
    lw:'lineWidth' ,     //num
    ml:'miterLimit',      //num
    fs:'fillStyle',                //str:col
    ss:'strokeStyle',              //str:col
    wc:'shadowColor',              //str:col
    lc:'lineCap',                  //str    XLineCap
    lj:'lineJoin',                  //str      XLineJoin
    f:'font',                     //str
    ta:'textAlign',                    //str
    tb:'textBaseline',   //?
    gc:'globalCompositeOperation'  //str (XGlobComp)
}
COMP={d:'destination-over',
    da:'destination-atop',
    do:'destination-out',
    di:'destination-in',
    s:'source-over',a:'source-atop',
    o:'source-out', i:'source-in',
    l:'lighter', x:'xor',c:'copy'}
XMETS={a:"arc",at:"arcTo",z:"bezierCurveTo",
    b:"beginPath",c:"closePath",cr:"clearRect",
    j:"clip",d:"drawImage",f:"fill",fr:"fillRect",ft:"fillText",
    g:"createLinearGradient",gi:"getImageData",i:"createImageData",
    ip:"isPointInPath",is:"isPointInStroke",v:"save",
    l:"lineTo",m:"moveTo",mt:"measureText",pi:"putImageData",
    p:"createPattern",q:"quadraticCurveTo",rg:"createRadialGradient",
    rc:"rect",r:"restore",S:"scale", T:"translate" , R:"rotate",
    s:"stroke",sr:"strokeRect",st:"strokeText",
    t:"transform",tf:"setTransform"}

