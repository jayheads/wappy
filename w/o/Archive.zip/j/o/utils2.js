//p: pop,splice,split//_p: parse //s:shfit,tostrng,slice, i:len,io, _r?,m:match, j:strigify,join, r:replace,_rv:reverse
$f=function(a){return function(){eval(a)}}
_stringify=function(a){return JSON.stringify(a)}
_toString=function(a){return a.toString()}
 $a=function(a,b){b=b||"this";return a+".apply("+b+",arguments)"}
eq=function(a,b){return $cat('$w.',a,'=',b)}
$gl=function(a,b){return eval(eq(a,b))}
tS=function(a){return(iO(a))?_j(a):_s(a)}
_e=function(a,b){if(!b){return _r(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g,"\\$&",a)};
        return _R(_e(a),b)}
$cat=function(){return(_.r(arguments,function(a,b){return a+tS(b)},''))}
$log=function(a){$c.l(tS(a));return a}
$l=function(){return $log(eval($a('$cat')))}
$do=function(a,b){if(iF(b)){b(a)};if(iS(b)){$w[b]=a};return a}
$df=function(a,b){return(!iW(a))?a:b}
$V=function(a,b,c,d){a=a||0;if(d){return $V((a-c)/2,(b-d)/2)};
        if(iA(a)){return $V(a[0],a[1])};if(iN(a)){return $V({x:a, y:b})}
        var x=a.x||0, y=$df(a.y,x);return {x:x,y:y}}
$fir=function(a,b){return (b)?ind(a,b)==0:a[0]}//:1->last char,2:isLastChar?
$lst=function(a,b){return(b)?ind(a,b)==_l(b)-1:a[_l(a)-1]}
$wof=function(a,b){return _sl(ind(a,b),_l(b),b)}//2:removes all before first(IndexOf)
$h=function(a,b){
        if(iN($i(a,b))){a=_m(_e(a,'g'),b);
            return(a)?_l(a):false}}//2:howMany
$pre=function(a,b){return (fir(a,b))?b:a+b}//2
$ext=function(a,b){if(!b){return(has('.',a))?_sl(ind('.',a),ind(a),a):0};//1:ext,2:newExt(ifDoesntHave)
        return(ext(a))?a:a+pre('.',b)}
$t=function(a){return _r(/\s\s*$/,'',_r(/^\s\s*/,'',a))  }




f=function(j,ff){

    var s="var t=this,S='',O={},R=[],N=0,A=tA(arguments),L=_l(A)";


    var f=function(a){
        var f=function(J){return new Function('a','b','c','d',J)};
        var F=function(J){return f("return "+J)};
        var r=F("'return('+$t(a)+');'");

        var b=_.l(_s(';',a));
        if(a==b){a=r(a)};
        return f(_r(';'+b,';'+r(b),s+a))}//dfn

    if(!j||iF(j)){return j}
    if(iS(j)){j=f(j)};
    if(ff){j=ff(j)}
    return j

}



DEF=function(a,b){
    var z=F("(a)?'='+a:''"),v=f("a=_s(':',a);return a[0]+z(a[1])"),
        m=F("_j(d,_.m(_s(b,a),c))"),//<3=splMapJnWr=magic
        V=F("'var '+m(a,',',v,',')+';'");
    var fS="S:'',O:{},R:[],N:0,A:tA(arguments),L:_l(A),Z,Y,X";
    if(!b){b=a;a=fS}
    return V(a)+'\n'+BODY(b)}









ZERO();ONE();TWO();