
Img=function(i){i=i|| new Image();
    i._setSrc =function(a){this.src=tU(a);return this}
    i.s =function(a){if(!a){return this.src}
    else{return this._setSrc(tU(a))}};
    i.p=function(p){return this.s('/png/'+p+'.png')}
    i.r=function(f){this.addEventListener('load',f);return this}; i.r(function(i){this.w=tg(i).width;this.h=tg(i).height})
    return i}


l('canvas');

// images
im = function(){return new Image()}
wh=function(i){i.w = i.width; i.h=i.height; return i}
setPNGSource =  function (img, png) {img.src = '/png/' + png + '.png'; return img}
Im = function (fn) {
    im = new Image();
    im.addEventListener('load', function(e){evt = e;d(e)} );
    if (fn){ im.addEventListener('load', fn); }return im;}

replacePic   = function (a, b)  { a.parentNode.replaceChild(a,  b )}
replaceFirstWithSecond = function (){  a = document.getElementsByTagName('img')[0];  b = document.getElementsByTagName('img')[1];
    switchPics(a,b)}  //document.location.href
pngLoaded = function(png, fxn){
    return setPNGSource(      imLoaded(im(),fxn) ,        png)}
plopPng = function(nam, png){w[nam]=pngLoaded(png); }
PNG = function(img){plopPng(img,img)}



//canvas
miniCtx=function(C){
    // C.c=C.canvas;   // C.w=C.c.width  // C.h=C.c.height;
    // C.l=$(C.canvas).offset().left   // C.t = $(C.canvas).offset().top;
    // C.mx=function(x){return parseInt(x - this.l)};C.my = function(y){return parseInt(y - this.t + pageYOffset)}
    C.T=C.translate;
    C.R=C.rotate;
    C.S=C.scale;
    C.D=C.drawImage;
    C.cid=C.createImageData;
    C.gid=C.getImageData;
    C.p =   C.pid=C.putImageData;

    return C}

Stg = function(can) {return new createjs.Stage(can)}
Ctx = function(can){return can.getContext('2d');}
jCan = function(canId){return $('#' + canId)}
Can = function(canId){return CanJ(canId)[0]}
Can2 = function(can) {return document.getElementById(can)}
cCanC = function(clsNm){if (cls) {return $("canvas ." + clsNm)} else  { return $('canvas')}}
xCan = function(canId){return Ctx(Can(canId))}
sCan = function(canId){return Stg(Can(canId))}


function CAN(canId){
    canId = canId || 'can';
    c  =  {};  can = c.c = Can(canId);
    c.j = jCan(canId);
    c.x = xCan(canId);

    stg = c.s =  sCan(canId);
    c.w = c.c.width;    c.h = c.c.height;
    c.col = function(col){this.jq.css('backgroundColor', col)}
    c.u = c.c.toDataURL;
    window[canId] = c;
    return c}



jq = function(fn){ $(function(){fn();}); }
def = function(fn){l(fn.toString());}


Con =  function(){return new createjs.Container}
tkr = T = Ticker = createjs.Ticker;
tk = tickStage = function(stage){stage = stage || stg; Ticker.addEventListener("tick", stage); return stage}

Lq = function(){return new createjs.LoadQueue(true)}
makeBlock = function (blockStr){
    readyBlock = "manReady = function(){l('READY');" + blockStr + ";}";
    l(readyBlock); return readyBlock;}
mfReady = function(man, block){ eval(block); man.addEventListener("complete", manReady);}
Ready = function(fn, manifest){ $(function(){
    manifest = manifest || mf;
    mf =  Lq();
    mf.addEventListener(fn);
    mf.loadManifest(manifest);
})
}
READY = function(blockStr, manifest){

    $(function(){
        manifest = manifest || mf;
        man =  Lq();
        mfReady(man, makeBlock(blockStr));
        man.loadManifest(manifest);
    })

}
MAN = function(manifest){
    manifest = manifest || mf;
    mf =  Lq();
    mf.loadManifest(manifest);
    return mf;
}
INIT = function(){CAN(); MAN(); tk(stg);}

Bm =   function(im){bm = new createjs.Bitmap(im); return bm}
BmS =  function (src) {   Im(function(e){Bm( e.target )}).src = src }
BmM = function(imStr, manLoader){
    manLoader = manLoader || man;
    window[imStr] = bm = Bm(manLoader.getResult(imStr));
    return bm;}
add = function(bm,stage){
    stage = stage || stg;
    stage.addChild(bm); stage.update(); return bm ;}
plop = function (im, x, y) {  // gotta fix plop! if (!x) {return ploop(image)}// if (!y) {return ploop(image, x)}}             // works great

    bm.x = x || 0; bm.y = y  || 0;
    add(bm);
    return bm;}

xy = function(bm, x, y){ bm.x = x; bm.y = y; }
width = function (bm){ return bm.getBounds().width  * bm.scaleX   }
height = function (bm){ return bm.getBounds().height  * bm.scaleY   }
halfWidth =  function(bm){return width(bm)/2 }
halfHeight =  function(bm){return height(bm)/2 }
xCenter = function(bm){ return  halfWidth(bm) + bm.x  }
yCenter = function(bm){ return  halfHeight(bm) + bm.y  }
centerAt = function(bm, x,y){bm.x = x - halfWidth(bm);bm.y = y - halfHeight(bm)}
center = function(bm, stg) {var c= stg.canvas; var x = c.width/2; var y = c.height/2;  centerAt(bm,x,y) ; return bm}






/////








getDataURL=function() {
    canvas = $('#myCanvas'); ctx = canvas.get(0).getContext('2d');
    d(ctx); ctx.fillRect(10,10,10,10);
    dataURL=canvas.get(0).toDataURL();
    canvas.click(function(){            alert(dataURL);  })}

ctxToPng=function(ctx, nam){
    ctx.canvas.toBlob(function(blob)  {
        saveAs(blob, nam + ".png")    })}

ctxToImage=function(c){
    var i = new Image();  i.src = c.canvas.toDataURL("image/png");
    return i;}

pingy=function(ctx){
    ctx.canvas.toBlob(function(blob){       saveAs(blob, nam +".png")           })}

CANVAS = function(dimm, coll, namm){
    var dim = dimm * 100;
    var nam = namm || coll || 'ctx';  var col = coll || 'yellow';
    var  canvasHtml = "<canvas id= " + nam + " width = " + dim + " height = " + dim + " style ='background-color: " + col + "' class='canvas'></canvas>" ;
    j = $(canvasHtml);
    $("body").append(j);  window[nam] =  miniCtx(j[0].getContext('2d')); return  window[nam]}






////
CLR = clearCanvas = function(ctx){ctx.clearRect(0, 0, ctx.w, ctx.h)}
reset = resetCanvas = function(c){c.canvas.width = c.canvas.width}
changeData = function(d, str){var f = new Function("v","k","l","l[k]=" + str);ea(d.data, function(v,k,l){f(v,k,l);})}
changeData2 = function (d, str){var s = "l[k]=" + str; $m(d.data, s);}
gD = getData = function(c){ return c.getImageData(0,0, c.w, c.h) }
pD = putData = function (data, c) {c.putImageData(data, 0, 0)};
gcp = getChangePut = function(c1, str, c2){var d = gD(c1);cD(d, str);pD(d,c2);}
DD = copyPasteData = getPutData = function (c,d){pD(gD(c),d)}
dit = function (d, str){  var s = "l[k]=" + str; $m(d.data, s);  }
cD = function(d, str){    var f = new Function("v","k","l","l[k]=" + str);  ea(d.data, function(v,k,l){f(v,k,l) })}


setStyles = function (C, fillStyle, strokeStyle, lineWidth) {C.strokeStyle = strokeStyle;C.fillStyle = fillStyle;C.lineWidth = lineWidth;}
circ = function(ctx,x,y,radius){ctx.beginPath(); ctx.arc(x, y, radius, 0, 2 * Math.PI, false); ctx.fill(); ctx.stroke();}
TenArr = function(){return [1,2,3,4,5,6,7,8,9,10]}
rad = function (deg) {var rads = deg * (Math.PI / 180);   return rads}

///


























// getting img/canvas/ctx


//getCtx = function(ctx) {var can =  document.getElementsByClassName(ctx)[0];return can.getContext('2d'); }
//CTX=function(ctxName){window[ctxName]=miniCtx(getCtx(ctxName))}




//draw300 = function(ctx, pic){ctx.drawImage(pic, 0,0,300,300,0,0,300,300  )}




//imgOnCv = function(img, ctx){ctx.drawImage(img, sx,sy,sw,sh,dx,dy,dw,dh)} // Draw 1






// canvasClick = function(ctx, fxn){//works// ctx.canvas.onclick = function(e){var X = e.clientX, Y = e.clientY; var left = ctx.canvas.offsetLeft; var top = ctx.canvas.offsetTop;  var x = X - left; var y = Y - top; fxn(e, x, y, X, Y);} }





//clearVertices = function(ctx,x,y){VX=[]; resetCanvas(ctx)}















//genPath = function(ctx){ var start = VX.shift(); ctx.moveTo(start.x, start.y); ea(VX, function(vertex, index, list){ctx.lineTo(vertex.x,vertex.y)}); c.closePath();}
//makeCut = function(ctx){ctx.save(); clearCanvas(ctx); genPath(ctx);  ctx.clip(); dO(me,c)};// c.restore();} //G = function() {dat= getData(c) };P = function() {putData(dat,c) }

//getCut = function(ctx){ l('getCut');  var copy = gD(ctx); CLR(ctx); var start = VX.shift() ;  ctx.moveTo(start.x, start.y);  _.each(VX, function(vx, index, list){ctx.lineTo(vx.x, vx.y)});  ctx.closePath();  ctx.clip(); pD(copy, ctx)}

//pathToSrc= function(path){return "http://localhost:4000/" + path}        // *

//imgSrc = function(img, src){img.src = src}   //setSRC = function(src,img){ if (src) { if (img){SRC(img,src)} else {SRC()}   }}

//getCtxOld=function(id){return $('#' + id).get(0).getContext('2d')}

//getCtxMini=function(name,id){w[name]=miniCtx(getCtx(id))}

//CTX2=function(id){window[id]=miniCtx(getCtx(id))}

//canvasClick(ctx, function(e,x,y){dVX(c, x, y); VX.push( {x:x,y:y})})}
//canvasClick(clr, function(e,x,y){reset(c);VX=[]})
//canvasClick(cut, function(){clr(c); getCut(c);})                       // and then: "t()"    ??? wtf



//dI = getData(c);da=dI.data;
// s1 = stamp(chicks,c);s2 = stamp(chicks,cc);
// t = function(){s1(0,0)}; tt = function(){ c.drawImage(chicks,0,0)}; ttt = function(){ cc.drawImage(chicks,20,20)};



// 1 make circles on canvas  2 make them in response to mouse click         /
// 3 store them in an array     4 gen path from array  5 use outside of path as clipping region
// 6 apply transparency to clipping region, 7 get imageData of new canvas  8 save it as a cutty!
//make clipping region from a circle?a

// my2y = CUT(My)(0,0)(My.w, My.h)(blue)(My.w,My.h)// onY = cutY = function(what){what(img,yellow, 10,10)}  // onB = cutB = function(what){what(img,blue, 10,10)}
//ii.src = "http://localhost:4000/" + imagePath;
//var can = document.getElementById('canvas'); canvas = $('#can'); can = canvas.get(0); ctx = can.getContext('2d');
////////////////////
// f = function(def){return new Function(def)}
// bigger:f(img,"ctx.scale(1.3,1.3);  ctx.drawImage(I, 0, 0, img.width, img.height)")
// can.width = img.width;   can.height = img.height;
//src = '/0cf14fee2317209e455ed59feb89a8c8.jpg'
//$('#invert').click(   invert   ); $('#grayscale').click(
//function flipY () {ctx.translate(img.width-1, img.height-1);    ctx.rotate(Math.PI);    ctx.drawImage(img, 0, 0, img.width, img.height);}
/*
 / This is the canvas where you want to draw
 var canvas = document.getElementById('your-canvas');
 var ctx = canvas.getContext('2d');
 // I'll use a skyblue background that covers everything
 // Just to demonstrate - ctx.fillStyle = "skyblue"; ctx.fillRect(0, 0, canvas.width, canvas.height);
 // Create a canvas that we will use as a mask
 var maskCanvas = document.createElement('canvas');
 // Ensure same dimensions - maskCanvas.width = canvas.width; - maskCanvas.height = canvas.height;
 var maskCtx = maskCanvas.getContext('2d');
 // This color is the one of the filled shape
 maskCtx.fillStyle = "black";
 // Fill the mask - maskCtx.fillRect(0, 0, maskCanvas.width, maskCanvas.height);
 // Set xor operation - maskCtx.globalCompositeOperation = 'xor';
 // Draw the shape you want to take out - maskCtx.arc(30, 30, 10, 0, 2 * Math.PI);  maskCtx.fill();
 // Draw mask on the image, and done !  - ctx.drawImage(maskCanvas, 0, 0);​*/
///////////////////////////////////////////////////////////////////////////////////////////////////////////////



l('easel');
SRC=function(s){if(s.toDataURL){s=s.toDataURL(); l('dataURL');}return s} // turns returns src-str from both src-str and canvas el (via dataToURL)
I=function(S,R){var i=new Image();
    i.s=function(s){if(!s){return this.src} else {this.src=SRC(s); return this}}; i.sp=function(p){this.s('/png/'+p+'.png');return this};
    i.r=function(f){this.addEventListener('load',f);return this}; i.r(function(e){this.w=e.target.width;this.h=e.target.height});
    if(S){if(R){i.r(R);i.s(S)} else{S=SRC(S);l(S); if(typeof S=='string'){i.src=S} else{i.r(S)}}} return i}
B=function(i,onB,bd){
    l('received i'); var B=function(i,bd){var b=new createjs.Bitmap(i);l('b(i)=');d(b);
        bd=bd||'BM'; W[bd]=b; l('i -> b(i) = d(W[' + bd + ']) ='); return b}
    if(!onB){l('returning b'); return B(i);}
    else {l('recieved sr'); I(i,function(e){onB(B(e.target, bd))})}}// works: !!  Bm('/png/guy.png', function(b){bg.s.a(b); bg.s.u();})
gC=genCan=function(d,w,h,r,l){d=d||'CV';w=w||960;h=h||450;r=r||'blue';var c,iS,rS,lS,S;//var q = $(str);  var can = q[0];
    iS=" id='"+d+"'"; if(!l){lS=''}else{lS=" class='"+l+"' "};if(!r){rS=''} else{rS="style='background-color:"+r+"' "};
    S=("<canvas "+iS+lS+rS+"  height="+h+" width="+w+"></canvas>");
    c=$(S)[0]; W[d]=c; return c}
qId=function(cid){return $('#' + cid)};
mB=MugBox=function(z,r,d){r=r||'pink'; d=d||'MUG'; z=zToD(z||'medium');  return gC(d,z,z,r)}
cI = canId=function(d){d=d||'CANNY';var c= qId(d)[0]; W[d]=c; return c}

C=sC=SUPERCAN=function(canvasEl){var c={};                       // (accepts/requires any canvas element)
    c.c=canvasEl;c.e=c.c.outerHTML;c.q=$(c.c);c.q.s=c.q.css;c.x=c.c.getContext('2d');c.x.d=c.x.drawImage;
    c.p=function(){$("body").append(this.q);return this};c.u=function(){return this.c.toDataURL()};c.bg=function(cl){this.q.css('backgroundColor', cl)};
    c.w=function(w){var c=this;if(w){c.c.width = w};return c.c.width};c.h=function(h){var c=this;if(h){c.c.height = w};return c.c.height};
    c.bo=function(S,C,Y){var c=this;if(S==undefined){S=10}; S=" "+S+"px "; Y=Y||"solid";Y=" "+Y+" "; C=C||"blue ";C=" "+C+" "; var str=S+Y+C; l(str); c.q.s('border', str)};
    c.r =c.solid=function(n1,n2,n3,n4){if(!n2){style=n1;} else{style="rgba("+n1+","+n2+","+n3+","+n4+")"}; l(style);c.x.save();c.x.fillStyle=style; this.x.fillRect(0,0,this.w(),this.h()); c.x.restore()};
    c.s=new createjs.Stage(c.c);c.s.a=c.s.addChild;c.s.u=c.s.update;c.tk = function(){createjs.Ticker.addEventListener("tick", this.s)};
    c.kt = function(){createjs.Ticker.removeEventListener("tick", this.s)};createjs.Ticker.setFPS(1); //c.tk();//stg.autoClear = false;
    c.d=function(sr,x,y){var c=this;  x=x||0;y=y||0;sr=SRC(sr); // if(src.u != undefined){src=src.u()};
        if(typeof src != 'string'){c.x.d(sr,x,y); return c} else{l('@');I(sr,function(e){c.x.d(e.target,x,y)})}}
    c.fit=function(sr){l('c.fit'); var c=this;
        sr=SRC(sr);
        if(typeof sr != 'string'){
            l('-@'); c.x.d(sr,0,0,c.w(),c.h())}
        else{l('@'); I(sr, function(e){c.x.d(e.target,0,0,c.w(),c.h())})}}
    c.a=function(ch){var ch=SRC(ch); c=this; var add=function(bm){c.s.addChild(bm); c.s.update(); return bm;}
        if(typeof ch !="string"){return add(ch)} else {B(ch,add)}}
    c.bm=function(i,z,onB,bd){var m,x,w,h,c=this;
        z=z||'medium';bd=bd||'bitmap';
        onB=onB||function(b,c){c.s.a(b);c.s.u()};
        m=superMugBox(z,'pink','temp');
        I(i,function(e){ m.fit(e.target); I(m,function(e){var b=Bm(e.target); onB(b,c);W[bd]=b})})};  // x=mugCan.getContext('2d');w=m.width; h=m.height; x.drawImage(e.target,0,0,w,h);// add: function(b){bg.s.a(b); bg.s.u()}
    return c}


sci=superCanId=function(d){l('sci');W[d]=sC(cI(d));return W[d]}

sgc=superGenCan=function(d,w,h,r,r){l('sgc');return sC(gC.apply(null, arguments))}

sM=smb=superMugBox=function(z,r,d){l('sM');return sC(mB(z,r,d))}

the=$$$=function(e){return e.target}
Spr=onBmSz=function($,onB,z){I($,function(i){var w,h,x,u,m=sM(z); m.fit(the(i)); I(m.c,function(i){onB(B(the(i)))})})}
SPR = function(C, $, z){Spr($,function(b){C.a(b)},z)}










c.g={};  c.g=createjs.Graphics;
c.shape = function(gx){gx = new createjs.Shape(gx);  return gx;}
c.g.b=function(fn){this.c.toBlob(fn);}  //  c.sv = function(nm){ this.bb(  function(b){ saveAs(bl, nm +".png")  }) }
c.g.p=function(c, nm){this.bb(function(b){saveAs(b, nm + ".png")})}
c.g.urlToIm = function(c){return new Im(this.u("image/png"))}






// c.l=c.q.offset().left; c.mx =function(x){return parseInt(x - c.l)}; c.t=c.q.offset().top; c.my = function(y){return parseInt(y - c.t + pageYOffset)}
// c.x.gD=function(){var x= this;return x.getImageData(x.canvas.width, x.canvas.height)};
// c.x.pD=function(d){var x=this; x.putImageData(d, 0, 0)};
// c.x.DD=c.x.copyPasteData=c.x.getPutData=function(c,d){var x=this; x.pD(x.gD(c),d)}; //c.x.gcp = x.getChangePut = function(x, str){var d = x.gD(); d = cD(d, str); this.pD(d);}
// c.x.t=c.x.translate; c.x.r=c.x.rotate; c.x.s=c.x.scale; c.x.cID=c.x.createImageData; c.x.gID=c.x.getImageData; c.x.pId=c.x.putImageData;




// ,0,0,m.w(),m.h());
// (typical of a pattern)














X=function(can){return can.getContext('2d')};
Stg=function(can) {return new createjs.Stage(can)};
clr=function(c){c.canvas.width = c.canvas.width};
CLR=function(c){c.x.clearRect(0,0,c.w(),c.h())};// rst=function(c){c.w(c.w())};


//testMug = function(){stg = mCan.s;  src='/png/berlin.jpg';  onMug = function(mug,stg){alert('onMug,baby!');   l('mug: '); d(mug);   stg.addChild(mug)}; l(src); def(onMug); d(stg);l('about to call: Mug(src, onMug, stg)');  Mug(src, onMug, stg)}
//SrcToStageMug = function(src, stg){srcToMug(src, function(m){stg.addChild(m)})}
//bmTo=function(b,x,y){b.x=x||0;bm.y=y||0;return b}
//BM=function(s, onB, bd){ else {l('@');if(s.u != undefined){s=s.u()};                       // c -> dURL -> i(->bm (+onB), on load) I(function(e){var b=bm(e.target); if(onB){onB(b)};if(bd){W[bd]=b}})(s)}}


add=function(b,c){c.s.a(b);   c.s.u();  return b}
Add = function(src, stg){Mug(src, function(m,s){s.addChild(m); TRANS(m)}, stg )}
Pop = function(stg){return function(src){Mug(src,       function(m,s){s.a(m);m.scaleX=.5},     stg)}}
mugFns = {Tiny: function(m,s){s.a(m); m.scaleX=.2;m.scaleY=.2; TRANS(m)} }

Lq = function(){return new createjs.LoadQueue(true)}
BmM = function(imStr, manLoader){manLoader = manLoader || man;  W[imStr]=bm=Bm(manLoader.getResult(imStr)); return bm};
plop = function (im, x, y) {add(BmM(im));    bm.x = x || 0; bm.y = y  || 0;    return bm;}// gotta fix plop! if (!x) {return ploop(image)}// if (!y) {return ploop(image, x)}}             // works great
T = createjs.Ticker;//tk = tickStage = function(stage){stage = stage || mCan.s; Ticker.addEventListener("tick", stage); return stage}
makeBlock = function (blockStr){readyBlock = "manReady = function(){l('READY');" + blockStr + ";}";l(readyBlock); return readyBlock;}
mfReady = function(man, block){ eval(block); man.addEventListener("complete", manReady);}
Ready = function(fn, manifest){ $(function(){ manifest = manifest || mf; mf =  Lq(); mf.addEventListener(fn);mf.loadManifest(manifest)})}
READY = function(blockStr, manifest){  $(function(){ manifest = manifest || mf;man =  Lq();mfReady(man, makeBlock(blockStr)); man.loadManifest(manifest)})}
MAN = function(manifest){manifest = manifest || mf; man =  Lq(); man.loadManifest(manifest); return man}
INIT = function(){CAN(); MAN(); tk(mCan.s);}
Con =  function(){return new createjs.Container}



snap = function(can, cb){can = can || mCan; cb = cb || function(){};  I.m(cb, can.u())}
Save = function(can){can = can || can; can.toBlob(function(blob){var formData = new FormData();
    var oReq = new XMLHttpRequest();formData.append("pic", blob); oReq.open("POST", "http://localhost:4000/upload"); oReq.send(formData)})}




//compare to Bm//should it be leveraging Bm??
// loads image i so that when it get src'ed, it makes a bm from itself and passes it to onB
// the bm fxnality is wrapped by the process...
// createjs.Ticker.addEventListener('tick', c.s);
//  c.addSrc = function(bid, src){var c = this;var bmRdy = function(b){c.addBm(b)}; c.BM(bid, bmRdy, src)}
// d(c);
// step 1: draw img AT 'standard' S  // when THAT one loads, make a Bitmap out of it// finally, pass the new Mug into onMug f
//var X = {}
//X.dit = function (d, str){ var s = "l[k]=" + str; $m(d.data, s);  }
//X.changeData = function(d, str){ var f = new Function("v","k","l","l[k]=" + str); ea(d.data, function(v,k,l){f(v,k,l);})};
//X.changeData2 = function (d, str){var s = "l[k]=" + str; $m(d.data, s);}
//X.cD = function(d, str){var f = new Function("v","k","l","l[k]=" + str);  ea(d.data, function(v,k,l){f(v,k,l) })}



--


    l('EASEL'); jq = function(fn){ $(function(){fn()})};  def = function(fn){l(fn.toString())};

t = temp = {};
t.e = {};



replacePic   = function (a, b)  { a.parentNode.replaceChild(a,  b )}
replaceFirstWithSecond = function (){  a = document.getElementsByTagName('img')[0];  b = document.getElementsByTagName('img')[1];
    switchPics(a,b)}  //document.location.href



// images
miniIm = wh = function(im){ im.w = im.width;im.h = im.height;
    im.p = function(png){this.src = '/png/' + png + '.png'; return this};
    return im;}


Im = function (cb, src) {t.i = new Image();
    t.i.l = function(cb){this.addEventListener('load', cb); return this}
    t.i.l( function(evt){t.e.e=evt;  t.e.t= t.e.e.target;  t.e.c= t.e.e.currentTarget;  t.e.o= t.e.e.originalTarget; d(t.e)} )
    t.i = miniIm(t.i);
    if (cb){t.i.l(cb)};
    t.i.s = function(src){if (src){this.src = src;}; l(this.src); return this}
    if (src){t.i.s(src);}
    return t.i}


IM = function (cb, src) {
    var i = new Image();


    i.l = i.loaded = function(cb){
        this.addEventListener('load', cb); return this
    }


    // i.l(function(evt){ i.e=evt;  t.e.t= t.e.e.target;  t.e.c= t.e.e.currentTarget;  t.e.o= t.e.e.originalTarget;   d(i.e)} )
    i = miniIm(i);
    if (cb){i.l(cb)};
    i.s = function(src){if (src){this.src = src;}; l(this.src); return this}
    if (src){i.s(src);}
    return i}


// pngLoaded = function(png, fxn){return setPNGSource(      imLoaded(im(),fxn) ,        png)}
//plopPng = function(nam, png){w[nam]=pngLoaded(png); } //PNG = function(img){plopPng(img,img)}





//canvas
miniCtx=function(C){
    C.c=C.canvas;    C.w=C.c.width; C.h=C.c.height;
    C.l=$(C.c).offset().left;  C.t = $(C.c).offset().top;
    C.mx=function(x){return parseInt(x - this.l)};C.my = function(y){return parseInt(y - this.t + pageYOffset)}
    C.T=C.translate;
    C.R=C.rotate;
    C.S=C.scale;
    C.D=C.drawImage;
    C.cid=C.createImageData;
    C.gid=C.getImageData;
    C.p =   C.pid=C.putImageData;   return C}
Stg = function(can) {return new createjs.Stage(can)}
jCan = function(canId){return $('#' + canId)}
Can = function(canId){return (jCan(canId)[0])}
Can2 = function(can) {return document.getElementById(can)}
cCanC = function(clsNm){if (cls) {return $("canvas ." + clsNm)} else  { return $('canvas')}}
Ctx = function(can){return can.getContext('2d');}
xCan = function(canId){return Ctx(Can(canId))}
sCan = function(canId){return Stg(Can(canId))}
function CAN(canId){l('CAN');canId = canId || 'can'; l(canId);c  =  {};
    c.q = jCan(canId);
    can = c.c = Can(canId);
    ctx = c.x = miniCtx(xCan(canId));  //d(c.x);
    stg = c.s =  sCan(canId); //stg.autoClear = false;
    c.w = function(w){if(w){c.c.width = w;}; return c.c.width;}
    c.h = function(h){if(h){c.c.height = w;}; return c.c.height;}
    c.g = new createjs.Graphics();
    c.shape = function(g){gx = new createjs.Shape(g);  return gx;}
    //c.c.width;    c.h = c.c.height;
    c.b = function(size, color, style){

        if(size==undefined) {size = 10;}
        size = " " + size + "px ";
        style = style || "solid";

        style = " " + style + " ";

        color = color || "pink "; color = " "  + color + " ";
        var str = size + style + color; l(str);

        c.q.css('border', str);}

    c.l = c.col = function(col){this.jq.css('backgroundColor', col)}
    c.u = c.c.toDataURL;

    c.solid = function(n1,n2,n3,n4){ if (!n2) {style = n1;} else {


        style = "rgba(" + n1 + "," + n2 + "," + n3 + "," + n4+ ")" ;};

        l(style);


        c.x.save(); c.x.fillStyle = style; this.x.fillRect(0,0,this.w(),this.h());c.x.restore();

    }



    return c}







Shp = function(){s = new createjs.Shape(); s.g = s.graphics;  g = s.g;  return g;  }

blue = function(){

    var shape =  Shp();

    shape.f('blue').drawCircle(100,100,50);  return shape;
}




Con =  function(){return new createjs.Container}
tkr = T = Ticker = createjs.Ticker;

tk = tickStage = function(stage){stage = stage || stg; Ticker.addEventListener("tick", stage); return stage}
kt = function(stage){
    stage = stage || stg;
    Ticker.removeEventListener("tick", stg)}


Lq = function(){return new createjs.LoadQueue(true)}
makeBlock = function (blockStr){
    readyBlock = "manReady = function(){l('READY');" + blockStr + ";}";
    l(readyBlock); return readyBlock;}
mfReady = function(man, block){ eval(block); man.addEventListener("complete", manReady);}
Ready = function(fn, manifest){ $(function(){
    manifest = manifest || mf;
    mf =  Lq();
    mf.addEventListener(fn);
    mf.loadManifest(manifest);
})
}
READY = function(blockStr, manifest){

    $(function(){
        manifest = manifest || mf;
        man =  Lq();
        mfReady(man, makeBlock(blockStr));
        man.loadManifest(manifest);
    })

}
MAN = function(manifest){
    manifest = manifest || mf;
    man =  Lq();
    man.loadManifest(manifest);
    return man;
}
INIT = function(){CAN(); MAN(); tk(stg);}

Bm =   function(im){bm = new createjs.Bitmap(im); return bm}


BmS =  function (src, nam) {
    Im(function(e){var bm = Bm( e.target );  if (nam) {window[nam] = bm}; l('got it!')}).src = src
}


BmM = function(imStr, manLoader){
    manLoader = manLoader || man;
    window[imStr] = bm = Bm(manLoader.getResult(imStr));
    return bm;}


add = function(bm, stage){
    stage = stage || stg;
    stage.addChild(bm); stage.update(); return bm ;}

plop = function (im, x, y) {  // gotta fix plop! if (!x) {return ploop(image)}// if (!y) {return ploop(image, x)}}             // works great
    add(BmM(im));
    bm.x = x || 0;
    bm.y = y  || 0;
    return bm;}


moveBm = function (x, y) {  // gotta fix plop! if (!x) {return ploop(image)}// if (!y) {return ploop(image, x)}}             // works great

    bm.x = x || 0;
    bm.y = y  || 0;
    return bm;
    stg.update();}


xy = function(bm, x, y){ bm.x = x; bm.y = y; }


width = function (bm){ return bm.getBounds().width  * bm.scaleX   }


height = function (bm){ return bm.getBounds().height  * bm.scaleY   }
halfWidth =  function(bm){return width(bm)/2 }
halfHeight =  function(bm){return height(bm)/2 }
xCenter = function(bm){ return  halfWidth(bm) + bm.x  }
yCenter = function(bm){ return  halfHeight(bm) + bm.y  }
centerAt = function(bm, x,y){bm.x = x - halfWidth(bm);bm.y = y - halfHeight(bm)}
center = function(bm, stage) {
    stage = stage || stg;

    var c = stage.canvas;

    var x = c.width/2;
    var y = c.height/2;
    centerAt(bm,x,y) ; return bm}



function pathToSrc(p){return "http://localhost:4000/"+p}


drawIm = function(c){$(i).load(function(){this.simpleD(i)})}


/////








getDataURL=function() {
    canvas = $('#myCanvas'); ctx = canvas.get(0).getContext('2d');
    d(ctx); ctx.fillRect(10,10,10,10);
    dataURL=canvas.get(0).toDataURL();
    canvas.click(function(){            alert(dataURL);  })}

ctxToPng=function(ctx, nam){
    ctx.canvas.toBlob(function(blob)  {
        saveAs(blob, nam + ".png")    })}

ctxToImage=function(c){
    var i = new Image();  i.src = c.canvas.toDataURL("image/png");
    return i;}

pingy=function(ctx){
    ctx.canvas.toBlob(function(blob){       saveAs(blob, nam +".png")           })}


CANVAS = function(dimm, coll, namm){
    var dim = dimm * 100;
    var nam = namm || coll || 'ctx';  var col = coll || 'yellow';
    var  canvasHtml = "<canvas id= " + nam + " width = " + dim + " height = " + dim + " style ='background-color: " + col + "' class='canvas'></canvas>" ;
    j = $(canvasHtml);
    $("body").append(j);  window[nam] =  miniCtx(j[0].getContext('2d')); return  window[nam]}






////
CLR = clearCanvas = function(ctx){ctx.clearRect(0, 0, ctx.w, ctx.h)}
reset = resetCanvas = function(c){c.canvas.width = c.canvas.width}
changeData = function(d, str){var f = new Function("v","k","l","l[k]=" + str);ea(d.data, function(v,k,l){f(v,k,l);})}
changeData2 = function (d, str){var s = "l[k]=" + str; $m(d.data, s);}
gD = getData = function(c){ return c.getImageData(0,0, c.w, c.h) }
pD = putData = function (data, c) {c.putImageData(data, 0, 0)};
gcp = getChangePut = function(c1, str, c2){var d = gD(c1);cD(d, str);pD(d,c2);}
DD = copyPasteData = getPutData = function (c,d){pD(gD(c),d)}
dit = function (d, str){  var s = "l[k]=" + str; $m(d.data, s);  }
cD = function(d, str){    var f = new Function("v","k","l","l[k]=" + str);  ea(d.data, function(v,k,l){f(v,k,l) })}


setStyles = function (C, fillStyle, strokeStyle, lineWidth) {C.strokeStyle = strokeStyle;C.fillStyle = fillStyle;C.lineWidth = lineWidth;}
circ = function(ctx,x,y,radius){ctx.beginPath(); ctx.arc(x, y, radius, 0, 2 * Math.PI, false); ctx.fill(); ctx.stroke();}
TenArr = function(){return [1,2,3,4,5,6,7,8,9,10]}
rad = function (deg) {var rads = deg * (Math.PI / 180);   return rads}

///


























// getting img/canvas/ctx


//getCtx = function(ctx) {var can =  document.getElementsByClassName(ctx)[0];return can.getContext('2d'); }
//CTX=function(ctxName){window[ctxName]=miniCtx(getCtx(ctxName))}




//draw300 = function(ctx, pic){ctx.drawImage(pic, 0,0,300,300,0,0,300,300  )}

















//genPath = function(ctx){ var start = VX.shift(); ctx.moveTo(start.x, start.y); ea(VX, function(vertex, index, list){ctx.lineTo(vertex.x,vertex.y)}); c.closePath();}
//makeCut = function(ctx){ctx.save(); clearCanvas(ctx); genPath(ctx);  ctx.clip(); dO(me,c)};// c.restore();} //G = function() {dat= getData(c) };P = function() {putData(dat,c) }

//getCut = function(ctx){ l('getCut');  var copy = gD(ctx); CLR(ctx); var start = VX.shift() ;  ctx.moveTo(start.x, start.y);  _.each(VX, function(vx, index, list){ctx.lineTo(vx.x, vx.y)});  ctx.closePath();  ctx.clip(); pD(copy, ctx)}

//pathToSrc= function(path){return "http://localhost:4000/" + path}        // *

//imgSrc = function(img, src){img.src = src}   //setSRC = function(src,img){ if (src) { if (img){SRC(img,src)} else {SRC()}   }}

//getCtxOld=function(id){return $('#' + id).get(0).getContext('2d')}

//getCtxMini=function(name,id){w[name]=miniCtx(getCtx(id))}

//CTX2=function(id){window[id]=miniCtx(getCtx(id))}

//canvasClick(ctx, function(e,x,y){dVX(c, x, y); VX.push( {x:x,y:y})})}
//canvasClick(clr, function(e,x,y){reset(c);VX=[]})
//canvasClick(cut, function(){clr(c); getCut(c);})                       // and then: "t()"    ??? wtf



//dI = getData(c);da=dI.data;
// s1 = stamp(chicks,c);s2 = stamp(chicks,cc);
// t = function(){s1(0,0)}; tt = function(){ c.drawImage(chicks,0,0)}; ttt = function(){ cc.drawImage(chicks,20,20)};



// 1 make circles on canvas  2 make them in response to mouse click         /
// 3 store them in an array     4 gen path from array  5 use outside of path as clipping region
// 6 apply transparency to clipping region, 7 get imageData of new canvas  8 save it as a cutty!
//make clipping region from a circle?a

// my2y = CUT(My)(0,0)(My.w, My.h)(blue)(My.w,My.h)// onY = cutY = function(what){what(img,yellow, 10,10)}  // onB = cutB = function(what){what(img,blue, 10,10)}
//ii.src = "http://localhost:4000/" + imagePath;
//var can = document.getElementById('canvas'); canvas = $('#can'); can = canvas.get(0); ctx = can.getContext('2d');
////////////////////
// f = function(def){return new Function(def)}
// bigger:f(img,"ctx.scale(1.3,1.3);  ctx.drawImage(I, 0, 0, img.width, img.height)")
// can.width = img.width;   can.height = img.height;
//src = '/0cf14fee2317209e455ed59feb89a8c8.jpg'
//$('#invert').click(   invert   ); $('#grayscale').click(
//function flipY () {ctx.translate(img.width-1, img.height-1);    ctx.rotate(Math.PI);    ctx.drawImage(img, 0, 0, img.width, img.height);}
/*
 / This is the canvas where you want to draw
 var canvas = document.getElementById('your-canvas');
 var ctx = canvas.getContext('2d');
 // I'll use a skyblue background that covers everything
 // Just to demonstrate - ctx.fillStyle = "skyblue"; ctx.fillRect(0, 0, canvas.width, canvas.height);
 // Create a canvas that we will use as a mask
 var maskCanvas = document.createElement('canvas');
 // Ensure same dimensions - maskCanvas.width = canvas.width; - maskCanvas.height = canvas.height;
 var maskCtx = maskCanvas.getContext('2d');
 // This color is the one of the filled shape
 maskCtx.fillStyle = "black";
 // Fill the mask - maskCtx.fillRect(0, 0, maskCanvas.width, maskCanvas.height);
 // Set xor operation - maskCtx.globalCompositeOperation = 'xor';
 // Draw the shape you want to take out - maskCtx.arc(30, 30, 10, 0, 2 * Math.PI);  maskCtx.fill();
 // Draw mask on the image, and done !  - ctx.drawImage(maskCanvas, 0, 0);​*/
///////////////////////////////////////////////////////////////////////////////////////////////////////////////










