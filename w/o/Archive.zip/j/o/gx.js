$l('gx');$w=window;_.e=_.each;_.r= _.random;

$t="tick"
cj=createjs;W=cj.Tween;W.g=W.get;Es=cj.Ease
T=cj.Ticker;
T.a= T.addEventListener;T.r=T.removeEventListener;
function tk(r){T.on('$t',r)};
function el(a){return new cj.DOMElement(a)};

function open(c){$w.open(c.toDataURL(), 'new_window', 'width=310,height=30')}
function $1(n){return _.range(1,(n||10)+1)}

function iA(a){return _.isArray(a)}
function iF(a){return _.isFunction(a)}
function iS(a){return _.isString(a)}
function iN(a){return _.isNumber(a)}
function iO(a){return _.isObject(a)&&!iF(a)&&!iA(a)}
function iI(a){return a.toString()=="[object HTMLImageElement]"}
function iC(a){return a.toString()=="[object HTMLCanvasElement]"}
function iB(a){return a.toString()=="[Bitmap (name=null)]"}
function tS(a){return (iO(a))?JSON.stringify(a): a.toString()}
function tA(a){return _.toArray(a)}
function lg(a){console.log(tS(a));return a}
function cat(){return(_.reduce(arguments, function(a,b){return a+tS(b)},''))}
function $l(a){function $a(a){return a + ".apply(this,arguments)"};return lg(eval($a('cat')))}// just returns a string//test$a(){eval($a('console.log'))}
function sr(a,b){if(!b){return a};if(iS(b)){$w[b]=a};if(iF(b)){b(a)};return a}
function xE(i){function xQ(i){return $('#'+i)};return xQ(i)[0]}
function tU(s){if(iS(s)){return s};if(s.toDataURL){$l('c');return s.toDataURL()};if(s.u){$l('C');return s.u()};if(iI(s)){$l('i');return s.src};if(s.image){$l('b');return s.image.src}}//s/c/C/i/b->s sync
function $p(a){return '/png/'+a+'.png'}


function $V(a,b,c,d){//returns coords needed for centering
    if(iO(a)){return a};
    if(d){return $V((a-c)/2,(b-d)/2)};
    if(iA(a)){return{x:a[0],y:a[1]}}
    else{return {x:a||0,y:b||a||0}}}

function sfl(c,f,s,l){c.c.fillStyle=f;if(s){c.c.strokeStyle=s};if(l){c.c.lineWidth=l};return c}
function circ(c,x,y,r){var X=c.c;X.beginPath();X.arc(x,y,r,0,2*Math.PI,false);X.fill();X.stroke();return c}




function G(c){var g=new cj.Graphics();var R=[
    'black','white','blue','green','yellow','red','orange','pink','purple']
    g.D=g.draw(c.c);
    g.q=function(x,y,z,r,s){z=z||_.r(300);this.f(r||R[_.r(8)]).r(x||_.r(800),y||_.r(300),z,z).D()}
    g.o=function(r,x,y,z){this.s('black').f(r||'yellow').dc(x||100,y||100,z||100).D()};
    return g}



function H(a,b,c){var h;function Sh(a){var h=new cj.Shape(a);h.g=h.graphics;return sB(h)}
    if(iO(a)){h=Sh(a)} else{h=Sh()};
    if(iS(a)){h.g.f(a)};if(iS(b)){h.g.f(b)};
    if(iF(a)){a(h.g,h)};if(iF(b)){b(h.g,h)};if(iF(c)){c(h.g,h)};
    return h}//function gH(a,b){var h=H(a);if(b){if(iF(b)){b(h,hg)} else{b.a(h)};return h}
H.r=function(g,h){
    c.t();g.f('red').dr(700,40,200,200)}







function ul(a,u){var r=new XMLHttpRequest();r.open("POST",u);r.send(a)}
function sv(a,u){ul((new FormData()).append("png",a), u||"http://localhost:4000/upload")}//function del(pid){pic.remove(pd)}



