W=$W=$w=window;
//
$A=Array;
$B=Boolean;
$D=Date;
$E=Error;
$F=Function;
$I=Infinity;
$J=JSON;$J.s=$J.stringify;$J.p=$J.parse;
$M=Math; $M.a=$M.abs; $M.q=$M.sqrt;
$N=Number;
$O=Object;
$R=RegExp;
$S=String;


_.a=_.range;
_.b=_.bind;
_.c=_.contains;_.cm= _.compact;
_.d=_.defaults;
_.e=_.each;
_.f=_.first;
_.g=_.groupBy;
_.h=_.has;
_.i=_.indexOf;_.ib=_.indexBy;
_.it=_.initial;
_.j=_.reject;
_.l=_.last;
_.li=_.lastIndexOf;
_.m=_.map;
_.o=_.omit;_.O=_.isObject;
_.p=_.partial;
_.r=_.reduce;
_.rs=_.rest;
_.s=_.some;
_.t=_.times;
_.u=_.union;
_.v=_.every;
_.w=_.where;
_.x=_.extend;
_.z=_.size;_.Z=_.zip;

//_l=function(a){console.log(a)}
_s=function(a,b){return a.split(b||'')}
_sl=function(a,b,c){return a.slice(b,c)}
_sp=function(a,b,c){return a.splice(b,c)}
_ts=function(a){return a.toString()}
_p=function(a,b,c){if(!b){return a.pop()};return a.push.apply(a,_.rest(arguments))}
_js=function(a){return $J.stringify(a)}
_jn=function(a,b){return a.join(b)}
_ps=function(a){return $J.parse(a)}
_rp=function(a,b,c){return a.replace(b,c)}
_tr=function(a){return _r(/\s\s*$/,'',_r(/^\s\s*/,'',a))}
_mh=function(a,b){return a.match(b)}
_rv=function(a){return a.reverse()}
_sh=function(a,b){if(!b){return a.shift()};return a.unshift.apply(a,_.rest(arguments))}
_cc=function(a){return a.concat.apply(a,_.rs(arguments))}
_io=function(a,b,c){return a.indexOf(b,c)}
_lo=function(a,b,c){return a.lastIndexOf(b,c)}
_ca=function(a,b){return a.charAt(b)}
//


iF=_.isFunction;
iA=_.isArray;
iS=_.isString;
iN=_.isNumber;
iO= function(a){return _.O(a)&&!iF(a)&&!iA(a)   }



IS={
  '0':function(a){return a==0},
    a:iA,
    b:function(a){return _s(a)=="[Bitmap (name=null)]"},
   bl:_.isBoolean, c:function(a){return _s(a)=="[object HTMLCanvasElement]"}   ,
    d:_.isDate,
    e:_.isEmpty,
    f:iF,
   fi:_.isFinite,
    g:_.isArguments,
    h:_.isElement,
    i:function(a){return _s(a)=="[object HTMLImageElement]"} ,
    l:function(a){return(iO(a)||iA(a))},
    n:iN,
   na:_.isNaN,
   nl:_.isNull,
   ng:function(a){return _.isNumber(a)&&a<0},
   ps:function(a){return _.isNumber(a)&&a>0},
    nn:function(a){return _.isNumber(a)&&a>=0},
    np:function(a){return _.isNumber(a)&&a<=0},
    o:iO,
    r:_.isRegExp,
    s:iS,
    sy:function(a){return a==(')')|| a==('(')||  a==(']')||  a==('[')    }   ,

    w:function(a){return a==$W},
    '=':function(b,c){return b==c}  ,
    '==':function(b,c){return b===c}  ,
    '!':function(b,c){return b!=c}  ,
    '!=':function(b,c){return b!==c}  ,
    '=':function(b,c){return b==c}  ,
    '<':function(b,c){return b<c}  ,
    '>':function(b,c){return b>c}  ,
    '<=':function(b,c){return b<=c}  ,
    '>=':function(b,c){return b>=c}  ,
     ud:_.isUndefined,
     '*':function(){return true}}

//than=function(){}
//sy:function(a){return a=='('||a==')'||a=='['||a==']'},
//if(_.f(a)=='/'){return _.r(a)==b;l('/')}

is=function(a,b,c){return IS[a](b,c)}
not=function(a,b,c){return !is(a,b,c)}
and=function(a,b,c){return _.v(_s(a,','),function(a){return is(a,b,c)})};
or=function(a,b){return _.s(_s(a,','),function(a){return is(a,b)})};
nand=function(a,b){return !and(a,b)}
nor=function(a,b){return !or(a,b)}//what=function(a){var o={ d:iD(a)||'',u:iU(a)||'',_:i_(a)||'',$:i$(a)||'',b:iB(a)||'',n:iN(a)||'',np:iNp(a)||'',nn:iNn(a)||'', '0':i0(a)||'','8':i8(a)||'', n_:iN_(a)||'',s:iS(a)||'',a:iA(a)||'',sa:iSA(a)||'',o:iO(a)||'',l:iL(a)||'',f:iF(a)||'',e:iE(a)||'',h:iH(a)||'',g:iG(a)||'',d:iD(a)||'',r:iR(a)||''};return o}
any=function(a,b){return _.s(_s(a,','),function(a){return b==a})}


tO=_.object;
tA=_.toArray;
tS=function(a){return(iO(a))?_js(a):_ts(a)}
$ev=function(a){return function(){eval(a)}}
$a=function(a,b){b=b||"this";return a+".apply("+b+",arguments)"}
$cat=function(){return(_.r(arguments,function(a,b){return a+tS(b)},''))}
$lg=function(a){console.log(tS(a));return a}
$g=ag=function(b){return function(a,c){c=c||'e';var s=a.split(','),S=_.z(s),B=_.z(b);
    if(c=='e'){return aE(b)};if(c=='m'){return aM(b)};if(c=='l'){return aL(b)};
    if(c=='n'){return aN(a,b)};if(c=='s'){return aS(a,b)};if(c=='a'){return aA(a,b)};
    function ck(a){return is(a[0],a[1])};function ab(a){return function(b){return is(a,b)}}
    function aE(b){if(S==B){return _.v(_.Z(s,b),function(a){return ck(a)})}}
    function aM(b){b=_.Z(s,b);if(S>=B){return _.v(b,function(a){return !a[1]||ck(a)})}}
    function aL(b){if(S<=B){return _.v(_.Z(s,b),function(a){return !a[0]||ck(a)})}}
    function aA(a,b){return _.v(b,ab(a))}
    function aN(a,b){return !aS(a,b)}
    function aS(a,b){return _.s(b,ab(a))}}}

$l=function(str,b){
    if(!str){$lg('nada, bitch');return false}

    return $lg(eval($a('$cat')))}

$V=function(a,b,c,d){a=a||0;
    if(d){return $V((a-c)/2,(b-d)/2)};
    if(iA(a)){return $V(a[0],a[1])};
    if(iN(a)){return $V({x:a,y:b})}
    return {x:a.x||0, y:not('ud',a.y)?a.y:a.x||0}}
//$df=function(a,b){return(not('w',a)? a: b}
iff=function(a,y,n){
    if(a){
        if(is('f',y)){y(a)}
        else{eval(y)}}
    else{
        if(n){iff(!a,n)}}
    return a}//a_=function(a,b,c){ff(iA(a),b,c);return a};f_=function(a,b,c){i_(iF(a),b,c);return a};s_=function(a,b,c){i_(iS(a),b,c);return a};n_=function(a,b,c){i_(iN(a),b,c);return a};o_=function(a,b,c){i_(iO(a),b,c);return a};w_=function(a,b,c){i_(iW(a),b,c);return a}
$do=function(a,b){
    if(iF(b)){b(a)};
    if(iS(b)){W[b]=a};
    return a}

ide=function i(v,y,n){
    if(v){eval(y)};i(!v,n);
    return v}


_rg=function(a,b){return $R(eR(a),b)
    function eR(a){return _rp(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g,"\\$&",a)}}
_rG=function(a,b){return _rg(a,'g')}
/////

S$=function(a,b,c){return _cc(_sl(a,0,b),_sl(a,c,_.z(a)))}//inverse slice
f$=function f($,q,r){var A=ag(arguments);if(A("s")){return _sl($,0,1)};if(A("s,n")){return _sl($,0,q)}
    if(A("s,n,s")){return f($,q)==r};if(A("s,s")){return f($,1,q)}}//ex: _f("jason",2,"ja") / true
l$=function f($,q,r){var A=ag(arguments),z=_.z($);if(A("s")){return _sl($,z-1,z)};if(A("s,n")){return _sl($,q*-1,z)}
    if(A("s,n,s")){return f($,q)==r};if(A("s,s")){return f($,1,q)}}
r$=function f($,q,r){var A=ag(arguments),z=_.z($);if(A("s")){return _sl($,1,z)};if(A("s,n")){return _sl($,q,z)}
    if(A("s,n,s")){return f($,q)==r};if(A("s,s")){return f($,1,q)}}
i$=function f($,q,r){var A=ag(arguments),z=_.z($);if(A("s")){return _sl($,0,z-1)};if(A("s,n")){return _sl($,0,z-q)}
    if(A("s,n,s")){return f($,q)==r}if(A("s,s")){return f($,1,q)}}
sw$=function f($,q){var A=ag(arguments),z=_.z(q);return f$($,z)==q}
ew$=function f($,q){var A=ag(arguments),z=_.z(q);return l$($,z)==q}
io$=function f(a,b,c){if(c<0){c+=_.z(a)}return _io(a,b,c)};
lo$=function f(a,b,c){if(c<0){c+=_.z(a)}return _lo(a,b,c)};
b$=function f(a,b){var i=io$(a,b),A=_.z(a),B=_.z(b);return _sl(a,0,i)}//$l(i,A,B)
bi$=function f(a,b){var i=io$(a,b),A=_.z(a),B=_.z(b);return _sl(a,0,i+B)}
bl$=function f(a,b){var i=lo$(a,b),A=_.z(a),B=_.z(b);return _sl(a,0,i)}
bli$=function f(a,b){var i=lo$(a,b),A=_.z(a),B=_.z(b);return _sl(a,0,i+B)}
a$=function f(a,b){var i=io$(a,b),A=_.z(a),B=_.z(b);return _sl(a,i+1,A)}//$l(i,A,B)
ai$=function f(a,b){var i=io$(a,b),A=_.z(a),B=_.z(b);return _sl(a,i,A)}
al$=function  f(a,b){var i=lo$(a,b),A=_.z(a),B=_.z(b);return _sl(a,i+1,A)}
ali$=function f(a,b){var i=lo$(a,b),A=_.z(a),B=_.z(b);return _sl(a,i,A)}
c$=function(a,b){return io$(a,b)!==-1}
p$=function(a,b){return(f$(a,b))?a:b+a}//2
e$=function(a,b){if(!b){return c$(a,'.')?ali$(a,'.'):false};if(!e$(a)){a+=p$(b,'.')};return a}
//

iI=function(a){
    return c$( _ts(a),"Image")
}

 iC=function(a){return c$(_ts(a),"Canvas")}
 iB=function(a){return c$(_ts(a),"Bitmap")}
png=function(a){return e$(a,'png')}
iDu=function(a){return sw$(a,'data:')}
tDu=function(a){if(a.toDataURL){return a.toDataURL()};if(iF(a.u)){return a.u()};return a}
tP=function(a){if(iS(a)&&!iDu(a)){return p$(png(a),'/')};return a}
tI=function(a){if (a){return(iB(a))?f(a.image):a} }
tU=function f(a){if(a){return(iI(tI(a)))?a.src:tP(tDu(a))}}


sI=function(i){i=i||new Image();
        i.a=function(a){var t=this;t.addEventListener('load',a);return t}
        i._s=function(a){this.src=tU(a);return this}
        i.d=function(a){return $do(this,b)};
        i.s=function(a){var t=this;
            if(!a){return t.src}
            else{return t._s(a)}};
        i.r=function(f){return this.a(function(i){f(i.target)})};
        i.r(function(i){i.w=i.width;i.h=i.height});
        return i}


I=function(a,b){if(!(a=tI(a))){return sI()};
    if(!b){if(iI(a)){return sI(a)};
        if(iF(a)){return sI().r(a)};
        if(iS(a)){return sI().s(a)}}
    else{if(iI(a)){return $do(sI(a),b)};
        if(iS(b)){return I().r(function(i){$W[b]=i}).s(a)};
        if(iF(b)){return I().r(b).s(a)}}}




///////////////////////////
I4=function f(a,b){
    if(!(a=tI(a))){$l('!');   return sI()};

    if(!b){ $l('!b')
        if(iI(a)){return sI(a)};
        if(iF(a)){return sI().r(a)};
        if(iS(a)){return sI().s(a)}}

    if(iI(a)){return sI(a).d(b)};

    return I().r(function(i){i.d(b)}).s(a)}







sI4=function(i){i=i||new Image();
    var w="width",s="src",h="height",t="target",l="load";
    i._a=i.addEventListener;
    i._s=function(a){this[s]=tU(a);return this}
    i.a=function(a){t._a(l,a);return this}
    i.d=function(a){return $do(this,a)};
    i.s=function(a){return(!a)?t[s]:t._s(a)};
    i.r=function(f){return this.a(function(i){f(i[t])})};
    i.r(function(i){i.w=i[w];i.h=i[h]});
    return i}
sI2=function(i){i=i||new Image();
    i.a=function(a){var t=this;t.addEventListener('load',a);return t}
    i._s=function(a){this.src=tU(a);return this}
    i.d=function(b){if(iF(b.d)){b.d(this)};
        if(iO(b.d)){b.d.d(this)};
        return sr(sI(this),b)};
    i.s=function(a){var t=this;
        if(!a){return t.src}
        else{return t._s(a)}};
    i.r=function(f){return this.a(function(i){f(i.target)})};
    i.r(function(i){i.w=i.width;i.h=i.height});
    return i}

I3=function(a,b){
    if(!a){return sI()};
    if(!b){
        if(iI(a)){return sI(a)};
        if(iF(a)){return sI().r(a)};
        if(iS(a)){return sI().s(a)}}
    else{
        if(iI(a)){return sr(sI(a),b)};
        if(iS(b)){return I().r(function(i){$w[b]=i}).s(a)};
        if(iF(b)){return I().r(b).s(a)}}}



//function I(a,b){var i=sI();if(b) {if(iI(a)){i=sI(a).d(b)}else{i.r(function(i){i.d(b)}).s(a)}}else  {if(!a||iI(a)){i=sI(a)};if(iF(a)){i.r(a)}else{i.s(a)}};return i}
//function tU(a){var s="src",i="image";a=tD(a);if(a[S]){a=a[S]};if(a[I]){a=tU(a[I])};return $src(s)}                       //s/c/C/i/b->s sync
J="jasonjasonjasonjasonjason"
//s/c/C/i/b->s sync
//if(p=='['){n2++};if(p==')'){n2*=(-1)};if(p==']'){n2=(n2*-1)+1}}});
//n$=function($){return sw$($,'!')
// }//s$=function($,q,qq){var A=ag(arguments),z=_.z($),n=false;if(n$(q)){n=true;q=r$(q)}}

txAg=function(){var a=arguments;
    if(ag("n,n,n",a)){alert('exactly 3 numbers')}
    if(ag("n",a,'l')){alert('starts with number')}
    if(ag("n",a,'n')){alert('no numbers')}
    if(ag("n",a,'s')){alert('at LEAST 1 number')}
    if(ag("n",a,'a')){alert('all numbers')}
    if(ag("n",a,'m')){alert('one number')}}

