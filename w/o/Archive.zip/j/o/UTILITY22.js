$A=Array
$B=Boolean
$D=Date;
$E=Error;
$F=Function
$I=Infinity;
$J=JSON;$J.s=$J.stringify;$J.p=$J.parse;
$M=Math; $M.a=$M.abs;
$N=Number;
$O=Object
$R=RegExp
$S=String
$W=$w=window;

_.a=_.range;
_.b=_.bind;
_.c=_.contains;_.cm= _.compact;
_.d=_.defaults;
_.e=_.each;
_.f=_.first;
_.g=_.groupBy;
_.h=_.has;
_.i=_.indexOf;_.ib=_.indexBy;
_.it=_.initial;
_.j=_.reject;
_.l=_.last;
_.li=_.lastIndexOf;
_.m=_.map;
_.o=_.omit;_.O=_.isObject;
_.p=_.partial;
_.r=_.reduce;
_.rs=_.rest;
_.s=_.some;
_.t=_.times;
_.u=_.union;
_.v=_.every;
_.w=_.where;
_.x=_.extend;
_.z=_.size;_.Z=_.zip;


iF=_.isFunction;
iA=_.isArray;
iS=_.isString;
iN=_.isNumber;
iO= function(a){return _.O(a)&&!iF(a)&&!iA(a)   }

IS={
  '0':function(a){return a==0},
    a:iA,
    b:function(a){return _s(a)=="[Bitmap (name=null)]"},
   bl:_.isBoolean, c:function(a){return _s(a)=="[object HTMLCanvasElement]"}   ,
    d:_.isDate,
    e:_.isEmpty,
    f:iF,
   fi:_.isFinite,
    g:_.isArguments,
    h:_.isElement,
    i:function(a){return _s(a)=="[object HTMLImageElement]"} ,
    l:function(a){return(iO(a)||iA(a))},
    n:iN,
   na:_.isNaN,
   nl:_.isNull,
   ng:function(a){return _.isNumber(a)&&a<0},
   ps:function(a){return _.isNumber(a)&&a>0},
    o:iO,
    r:_.isRegExp,
    s:iS,
    w:function(a){return a==$W},
    '=':function(b,c){return b==c}  ,
    '==':function(b,c){return b===c}  ,
    '!':function(b,c){return b!=c}  ,
    '!=':function(b,c){return b!==c}  ,
    '=':function(b,c){return b==c}  ,
    '<':function(b,c){return b<c}  ,
    '>':function(b,c){return b>c}  ,
    '<=':function(b,c){return b<=c}  ,
    '>=':function(b,c){return b>=c}  ,
     ud:_.isUndefined,
     '*':function(){return true}}

 //than=function(){}
//sy:function(a){return a=='('||a==')'||a=='['||a==']'},
//if(_.f(a)=='/'){return _.r(a)==b;l('/')}
is=function(a,b,c){return IS[a](b,c)}

not=function(a,b,c){return !is(a,b,c)}
and=function(a,b,c){return _.v(_s(a,','),function(a){return is(a,b,c)})};
or=function(a,b){return _.s(_s(a,','),function(a){return is(a,b)})};
nand=function(a,b){return !and(a,b)}
nor=function(a,b){return !or(a,b)}//what=function(a){var o={ d:iD(a)||'',u:iU(a)||'',_:i_(a)||'',$:i$(a)||'',b:iB(a)||'',n:iN(a)||'',np:iNp(a)||'',nn:iNn(a)||'', '0':i0(a)||'','8':i8(a)||'', n_:iN_(a)||'',s:iS(a)||'',a:iA(a)||'',sa:iSA(a)||'',o:iO(a)||'',l:iL(a)||'',f:iF(a)||'',e:iE(a)||'',h:iH(a)||'',g:iG(a)||'',d:iD(a)||'',r:iR(a)||''};return o}
any=function(a,b){return _.s(_s(a,','),function(a){return b==a})}


ag=function(a,b,c){c=c||'e';
    if(c=='e'){return aE(a,b)};if(c=='m'){return aM(a,b)};
    if(c=='l'){return aL(a,b)};if(c=='n'){return aN(a,b)};
    if(c=='s'){return aS(a,b)};if(c=='a'){return aA(a,b)};

    function aE(a,b){
        if(_.z(a=a.split(','))!=_.z(b)){return false}
        else{
            return _.v(_.Z(a,b),function(a){
                if(!(a)[1]){return true}
            return is(a[0],a[1])})||false}
    }


    function aM(a,b){if(_.z(a=a.split(','))<_.z(b)){return}
        return _.v(_.cm(_.Z(a,b)),function(a){if(! (a)[1]){return true}
            return is(a[0],a[1])})||false}

    function aL(a,b){if(_.z(a=a.split(','))>_.z(b)){return}
        return _.v(_.cm(_.Z(a,b)),
            function(a){if(!(a)[0]){return true};
                return is(a[0]||null,a[1]||null)||false})}

    function aA(a,b){return _.v(b,function(b){return is(a,b)})}

    function aN(a,b){return !agS(a,b)}

    function aS(a,b){return _.s(b,function(b){return is(a,b)})}}



_l=function(a){console.log(a)}
_s=function(a,b){return a.split(b||'')}
_sl=function(a,b,c){return a.slice(b,c)}
_sp=function(a,b,c){return a.splice(b,c)}
_ts=function(a){return a.toString()}
_p=function(a,b,c){if(!b){return a.pop()};return a.push.apply(a,_.rest(arguments))}
_js=function(a){return $J.stringify(a)}
_jn=function(a,b){return a.join(b)}
_ps=function(a){return $J.parse(a)}
_rp=function(a,b,c){return a.replace(b,c)}
_tr=function(a){return _r(/\s\s*$/,'',_r(/^\s\s*/,'',a))}
_mh=function(a,b){return a.match(b)}
_rv=function(a){return a.reverse()}
_sh=function(a,b){if(!b){return a.shift()};return a.unshift.apply(a,_.rest(arguments))}
_cc=function(a){return a.concat.apply(a,_.rs(arguments))}





    tx=function(){

        if(ag('n',arguments,'s')){alert('y')} else{alert('n')}

    }




