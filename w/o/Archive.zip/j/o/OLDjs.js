
css2=function f(q,b,c){

    var s1=function(q,b,c){var k=oO('S',b)
            if(U(c)){return q.css(k)}
            q.css(k,oO(b,c,'R'))
            return q},

        s2=function(q,ob){_e(ob,function(k,v){

            s1(q,v,k)})
            return q}

    if(O(b)){return s2(q,b)} return s1(q,b,c)}
    font=function rc(a){var f,w,s,z,S;
    each(parse(a), function(p){
        if(oF(p)){f=oF(p)}
        if(oFw(p)){w=oFw(p)}
        if(oFs(p)){s=oFs(p)}
        if(V(p[0])){z=p.split('/');S=z[0]+'px';
            if(z[1]){S+='/'+z[0]+'px'}}})
    return $l([(s||oFs('n')),(w||oFw('n')),
        (z||100)(f||of('f'))].join(' ') )}

gg=function f(a,b,c,d){a=ji(a)

    if(O(b)){
        _e(b,function(v,k){
            $i(c,k,v,a)});
        return a}


    if(U(c)){return f(a,{},b)}

    if(!U(d)){$i(a,b,c,d)}

    return a[oO(oO(b),c)]

}




gG=function(a){
    return function(b){
        return function(c,d){
            return gg(b,a,c,d)}}}


o.pop=function(a,b,c,d){
    if(U(a)){o.x(0,0,o.w(),o.h());return o}
    if(N(a)){o.x(a,b||a,c||200,d||c)}
    if(!b){return t[xPops[a]]};
    t[xPops[a]]=b;
    return o}



oldTr=x.translate;oldR=x.rotate;oldS=x.scale;oldaf=function(a,b,c,d){      //transformations
    if(a=='t'){x[tl](a,b,c,d)};
    if(a=='r'){x[rt](a,b,c,d)};
    if(a=='s'){x[sc](a,b,c,d)};
    if(a=='k'){x[sk](a,b,c,d)};
    return o}


DObjectM={u:"getCacheDataURL",
    cm:"getConcatenatedMatrix",
    m:"getMatrix",
    s:"getStage",
    tb:"getTransformedBounds",
    v:"isVisible",
    lg:"localToGlobal",
    ll:"localToLocal",
    gl:"globalToLocal"}
DObjectP={
    a:"alpha",
    c:"cacheCanvas",
    d:"suppressCrossDomainErrors",
    e:"mouseEnabled",
    f:"filters",
    h:"hitArea",
    i:"cacheID",
    kx:"skewX",
    ky:"skewY",
    m:"mask",
    n:"name",
    o:"compositeOperation",
    p:"parent",
    rx:"regX",
    ry:"regY",
    r:"rotation",
    sx:"scaleX",
    sy:"scaleY",
    t:"onTick",
    u:"cursor",
    v:"visible",
    w:"shadow"}

BooColor=['black','white','blue','green','yellow','red','orange','pink','purple']
math={p:2*Math.PI}
Url={u:"http://localhost:4000/upload"}
Vector={ipad:[960,450]}
BooAlert={b:'primary',g:'success',t:'info',o:'warning',r:'danger',l:'link'};
BooSize={b:'lg',s:'sm',t:'xs'}




o.bn=function(a,b,c,d){if(U(a)){return o.getBounds}
    o.setBounds(a,b,c,d);return o}
o.cache=function(){var g=arguments;
    if(U(a)){o.uncache()}
    else if(U(b)){o.updateCache(a)}
    else {o.cache.apply(stg,g)}
    return o}
o.X=function(a){o.updateContext(a);return o}
o.w=function(){return o.bn().width*o.scaleX};
o.h=function(){return o.bn().height*o.scaleY}
o.t=function(x,y){var v=$V(x,y);
    o.x=v.x;o.y=v.y;
    return o}
o.z=function(c){return o.c(o.w()/2,o.h()/2)}
o.c=function(x,y){if(!x){
    return $V(o.x+o.w()/2,o.y+o.h()/2)};
    o.t(x-o.w()/2, y-o.h()/2);
    return o}
Mouse={
    a3:"onclick",
    af:"ondblclick",
    aad:"onkeydown",
    ada:"onkeypress",
    aa:"onkeyup",
    az:"onmousedown",
    af4:"onmousemove",
    afd:"onmouseout",
    asfd:"onmouseover",
    asd:"onmouseup",
    aj:"onresize",
    ak:"onsubmit",
    a6:"onscroll",
    a4:"onselect",
    a7:"onblur",
    ad:"onchange",
    ads:"onfocus",
    as:"onload",
    adf:"onunload"}