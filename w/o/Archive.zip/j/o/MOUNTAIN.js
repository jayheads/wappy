s$=S;
$D=Date;
$E=Error;
$F=Function;
$I=Infinity;
$A=Array;
$M=Math;
$B=Boolean;
$J=JSON;
$N=Number;
$O=Object;
$S=String;
$R=RegExp

A=  _.isArray
B=  _.isBoolean
C =function(a){
    if(O(a)){
        if(a.canvas){return a.canvas}
        if(_h('Canvas', _g(a))){
            return _g(a)}}}
D   =function(a,b,c){
    return  U(b)? !U(a)
        :_a( _.defaults,arguments)}
Du  =iD =function(a){
    return _h(a,'data:')}
E=function e(a,b,c){
    if(D(b)){
        return _.every(a,b||N,c)}
    if(O(a)){if(a.q){a=a.q}
        if(C(a)){return C(a)}
        if(_.isElement(_g(a))){return _g(a)}}}
F=function f(a,b,c){
    return b? _.filter(a,b,c)
        :_.isFunction(a)?
        a.prototype||true:0}
G=function(a){ var p,n
    if(_.isArguments(a)){
    a= _.toArray(a)
    if( _l(a) === '+' ){p=a.pop()}
    if( _l(a) === '-' ){n=a.pop()}
    return D(a, {
        z: a.length,
        f:_f(a),
        l:_l(a),
        r:_r(a),
        i:_i(a),
        p:p,
        P:!p,
        e:E(_f(a)),
        _g:_g(_f(a)),
        n:n,
        N:!n })}}
I=function(a){if(_h('Image',_g(a))){return _g(a)}}//can something be an image and if so// return its data-url or a string
J=function(a,b){return U(b)? H(a,"Sprite"):gJ}
K=function(a,b,c){
    return N(a)? sI(b, a*1000)
        : N(b)? sI(a, b)
        :_.keys(a) }
Lc=function(a){return s$(a).isLower()}
N  = _.isNumber
Nn  =_.isNan
O=function(a,b){
    return U(b)? _.isObject(a): $a(_.extend, arguments)}

Q=function q(a){if(O(a)){
    if(a.q){return a.q}
    if(E(a)){return $(E(a))}}}

R=function(a,b,c){
    return U(b)? _.isRegExp(a): N(a)? _.range(a,b,c):0}
S=function(a,b,c){
    return U(b)? _.isString(a) : _.some(a,b||F,c)}
U=function u(a,b){
    var iU=_.isUndefined;
    return iU(b)? iU(a)
        :_a(_.extend,arguments)}
V=_.values
W=$w=window
X=function(c){
    if(O(c)){
        if(c.canvas){return c}
        if(C(c)){return C(c).getContext('2d')}
        if(c.q){return x(a.q)}}}


_a=function(a,b,c){return a.apply(c||a, b)}
_b =function(a,b,c){
            if (U(a)) {return $('body')}
            return  F(a)? _.bind(a,b,c):  _.bindAll(a,b,c)}
_c=function(a,b){
            if(U(b)){return a.clone()}
            if(!A(a)){a=[a]}
            return a.concat(b)}
_e=function(a,b,c){if(b){return _.each(a,b,c)}
            return a.empty()}
_f=function(a,b,c){return F(b)? _.find(a,b,c): _.first(a,b)}
_g =function(a){if(O(a)){
    return a.target||$(a)[0]} }

_h=function h(a, b){
            if( O(a) && F(a.height) ){
                if(U(b)){return a.height()}  //|| a.w
                if(N(b)){a.height(b)}
                return a}


            if(U(b)){return D(a.height)? a.height: a.h }  //|| a.h
            if(N(b)){return _s(a,'height',b)}


            if(A(a)){return _.contains(a,b) }
            if(O(b)){return h(_S(b),a)}
            if(S(a)){return s$(a).contains(b)}
            if(O(a)){return a.has(b)}}
_i=function(a,b){ return U(a)? new Image(): _.initial(a,b)}
_k=function(a){return a.complete}
_l= function(a,b){
    if (F(b)){$(a).load(b);return a}
            return  _.last(a,b)}
_m=function(a,b,c){return U(b)? _.min(a): _.map(a,b,c) }
_p=_.partial
_p2=pAr=function(f,B){return function(a,c){return f(a,B,c)}}
_r=function r(a,b,c,d){
            return  (F(b) && D(c))? _.reduce(a, b, c)
                :(F(a) && D(c))? _.reduceRight(a, c, b)
                :(F(a) || F(b))? r(c,a,b)
                :N(a)?_.random(a,b,c)
                :_.rest(a,b)}
_s=function(a,b,c){
            if(D(b)){a[b]=c;return a}
            var q=$('<br>')

            if(N(a)){_t(a-1,function(){q=q.add(_s())})}
            return q}
_t= function t(a,b,c){
            if(F(a)){return t(1,a)}
            if(N(a)){return _.times(a,b,c)}

            if(U(a)){return t(_b())}

            if(U(b)){
                if(S(a)){return t(_b(), a)}
                return $(a).text()
            }

            //  if(!O(a)){return t($("body"), a)}

            return $(a).text(b)
        }
_w=function(a,b){
            if(F(a.width)){
                if(U(b)){return a.width()}  //|| a.w
                if(N(b)){a.width(b)}
                return a}
            if(U(b)){return D(a.width)? a.width: a.w}

            if(N(b)){return _s(a,'width',b)}}
_z=function z(a,b,c){
            return  U(b)? _.size(a)
                : N(b)? _z(a) == b
                : _z(a)== _z(b)}



_C = _.compact
_F=  _.flatten
_I=  function(a,b){return U(b)? _.invert(a)  :_a(_.intersection,arguments)}
_M=  _.max
_S=  function(a){return a.toString()}//=tS
_U=  _.union
_W=  _.where
_Z=   _.zip





tDU=function(a){return a.toDataURL()}
iW=function(a){return $(a).get(0).innerWidth}
iH=function(a){return $(a).get(0).innerHeight}
cL =function(a){console.log(a);return a}
clk=function(a,b,c){return  a.dblclick(b)}

clr=function(c){var x=xx(c);x.X()}


dbl=function(a,b,c){return  a.dblclick(b)}
eL =function(a,b){return s$(a).ensureLeft(b).s}
eR =function(a,b){return s$(a).ensureRight(b).s}
eW =function f(a,b){return l$(a, _z(b))==b}
fF=function(a){return f(a)? a(): a}      //?
gJ =function(a,b,c){return $.getJSON(a,b,c)}
jS =function(a){return JSON.stringify(a)}
lC =function(a){return a.toLowerCase()}
lIO=function(a,b,c){return a.lastIndexOf(b,c < 0?c+_z(a): c)}
mC =$M.ceil
mF =$M.floor
pI =parseInt
sI=setInterval
sW = function(a,b){return s$(a).startsWith(b)}
sT =function(a,b){return setTimeout(a,b)}
tA =function(a){return O(a)? _.toArray(a): [a]}
tT=function(a){$('body').prepend(a);return a}
tB=function(a){$('body').append(a);return a}
uC =function(a){return a.toUpperCase()}
oH=function(a){return E(a) && E(a).outerHTML}
bC=function bc(a,b){return b? ss(a,'C',b):bc('body',a)}


shf=function(a){return a.shift()}
ush=function(a){return a.unshift()}
pop=function(a){return a.pop()}
psh=function(a){return a.push()}
rpl=function(a,b,c){return a.replace(b||'#', c||'')}
pre=function(a,b){return sW(a,b)?a:b+a}
ext=function(a,b){return(_h(a,'.'))?a: eR(a, b||'.png')}
def=function(d,b){return _D(d=d||{}, oO(b||''+'D'))}//dst,srcPre
inn=function(a){return {w:iW(W),h:iH(W)}}
dim=function(a,w,h){a=E(a)
    _w(a,w); _h(a,h||w)
    return a}

