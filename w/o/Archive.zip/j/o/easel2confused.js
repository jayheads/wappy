uu=iUd=function(a){return a===undefined}
pp=spl=function(a){return _.cm(_s(a,' '))}
hh=oh=function(a){return $(a)[0].outerHTML}
O=function(){

oo=o=function f(h,k){

    if(f.m[h]){h=f.m[h]}

       if(f[h]){h=f[h]};

if(uu(k)){return h};  //1 r eo-item
    if(h[k]){k=h[k]};
    return k}
o.m={bc:'c'}

o.q={
        a:"after",
        at:"appendTo",
        ap:"append",
        ac:"addClass",
        ar:"removeAttr",
        b:"before",
        cr:"removeClass",
        c:"clone",
        d:"detach",
        e:"empty",
        hc:"hasClass",
        h:"height",
        ia:"insertAfter",
        ib:"insertBefore",
        ih:"innerHeight",
        iw:"innerWidth",
        l:"html",
        n:"position",
        o:"offset",
        op:"offsetParent",
        oh:"outerHeight",
        ow:"outerWidth",
        pp:"prepend",
        p:"prop",
        pt:"prependTo",
        pr:"removeProperty",
        r:"remove",
        ra:"replaceAll",
        rw:"replaceWith",
        s:"css",
        sl:"scrollLeft",
        st:"scrollTop",
        tt:"attr",
        tc:"toggleClass",
        t:"text",
        u:"unwrap",
        v:"val",w:"width",
        wr:"wrap",
        wa:"wrapAll",
        wi:"wrapInner"};
o.s={

        kf:"@keyframes",

        a:"animation",
        an:"animation-name",
        ad:"animation-duration",
        at:"animation-timing-function",
        al:"animation-delay",
        ac:"animation-iteration-count",
        ar:"animation-direction",
        ap:"animation-play-state",
        bg:"background",
        ba:"background-attachment",
        bc:"background-color",
        bi:"background-image",
        bp:"background-position",
        br:"background-repeat",
        bl:"background-clip",
        bo:"background-origin",
        bs:"background-size",
        d:"border",
        dc:"border-color",
        ds:"border-style",
        dw:"border-width",
        dt:"border-top",
        dtc:"border-top-color"	,
        dts:"border-top-style",
        dtw:"border-top-width",
        dr:"border-right",
        drc:"border-right-color",
        drs:"border-right-style",
        drw:"border-right-width",
        db:"border-bottom",
        dbc:"border-bottom-color",
        dbs:"border-bottom-style",
        dbw:"border-bottom-width",
        dl:"border-left",
        dlc:"border-left-color",
        dls:"border-left-style",
        dlw:"border-left-width",

        o:"outline",
        oc:"outline-color",
        os:"outline-style",
        ow:"outline-width",
        di:"border-image",
        dio:"border-image-outset",
        dir:"border-image-repeat",
        disl:"border-image-slice",
        dis:"border-image-source",
        diw:"border-image-width",

        xs:"box-shadow",
        vs:"overflow-style",
        vx:"overflow-x",
        vy:"overflow-y",
        rt:"rotation",
        rp:"rotation-point",
        cp:"color-profile",
        op:"opacity",
        ri:"rendering-intent",
        h:"height",
        mh:"max-height",
        nh:"min-height",
        w:"width",
        mw:"max-width",
        nw:"min-width",

        xa:"box-align",
        xd:"box-direction",
        xf:"box-flex",
        xfg:"box-flex-group",
        bxl:"box-lines",
        xog:"box-ordinal-group",
        xo:"box-orient",
        xp:"box-pack",

        f:"font",
        ff:"font-family",
        fs:"font-size",
        fy:"font-style",
        fv:"font-variant",
        fw:"font-weight",
        fc:"@font-face",
        fj:"font-size-adjust",
        fh:"font-stretch",



        ct:"content",
        ci:"counter-increment",
        cr:"counter-reset",
        q:"quotes",
        crp:"crop",
        to:"move-to",
        pp:"page-policy",





        gc:"grid-columns",
        gr:"grid-rows",


        //linebox

        aj:"alignment-adjust",
        ab:"alignment-baseline",
        bh:"baseline-shift",

        dm:"dominant-baseline",
        daj:"drop-initial-after-adjust",
        dal:"drop-initial-after-align",
        dbj:"drop-initial-before-adjust",
        dbl:"drop-initial-before-align",
        dz:"drop-initial-size",
        dv:"drop-initial-value",

        ix:"inline-box-align",
        sk:"line-stacking",
        ss:"line-stacking-shift",
        st:"line-stacking-strategy",
        th:"text-height",
        ls:"list-style",
        li:"list-style-image",
        lp:"list-style-position",
        lt:"list-style-type",
        m:"margin",
        mt:"margin-top",
        mr:"margin-right",
        mb:"margin-bottom",
        ml:"margin-left",

        qd:"marquee-direction",
        qp:"marquee-play-count",
        qs:"marquee-speed",
        mq:"marquee-style",

        p:"padding",
        pt:"padding-top",
        pr:"padding-right",
        pb:"padding-bottom",
        pl:"padding-left",




//page media
        ft:"fit",
        fp:"ftp",
        e:"image-orientation",
        g:"page",
        s:"size",

//positioning

        b:"bottom",
        cl:"clear",
        clp:"clip",
        u:"cursor",
        y:"display",
        fl:"float",
        l:"left",
        of:"overflow",
        r:"right" ,
        t:'top',
        ps:'position',
        v:'visibility',
        z:"z-index",


//table
        co:"border-collapse",
        sp:"border-spacing",
        cs:"caption-side",
        ec:"empty-cells",
        ly:"table-layout",

//text
        c:"color",
        n:"direction",



        //hyperlink
        tg:"target",
        tn:"target-name",
        tw:"target-new",
        tp:"target-position",


        lts:"letter-spacing",
        lh:"line-height",
        ta:"text-align",
        td:"text-decoration",
        ti:"text-indent",
        ttf:"text-transform",
        ub:"unicode-bidi",
        va:"vertical-align",
        wh:"white-space",
        wo:"word-spacing",

        hp:"hanging-punctuation",
        pu:"punctuation-trim",
        tal:"text-align-last",
        j:"text-justify",
        tl:"text-outline",
        tv:"text-overflow",
        tsh:"text-shadow",
        twr:"text-wrap",
        wbr:"word-break",
        wwr:"word-wrap",

        //2d/3d
        tf:"transform",
        tfo:"transform-origin",
        ts:"transform-style",
        ps:"perspective",
        po:"perspective-origin",
        bv:"backface-visibility",



//transition
        tr:"transition",
        ty:"transition-property",
        tu:"transition-duration",
        tt:"transition-timing-function",
        te:"transition-delay",

        //user interface
        pe:"appearance",
        xz:"box-sizing",
        ic:"icon",
        ni:"nav-index",
        nl:"nav-left",
        dd:"nav-down",
        nr:"nav-right",
        nu:"nav-up",
        oo:"outline-offset",
        rs:"resize"
    };
o.c={
        "*":"Snow",
        "0":"Black",
        "!":"DeepPink" ,
        "'":"GhostWhite",
        "$":"Gold",

        "(":"BlanchedAlmond",
        "+":"CadetBlue",
        ":":"Chartreuse",
        ")":"Chocolate",
        "<":"Coral",
        "//":"DarkSlateBlue",
        "^": "DeepSkyBlue",
        "[":"FireBrick",
        "3":"FloralWhite",
        "?":"DarkOliveGreen",
        "%":"DarkOrchid",
        "~":"DarkSeaGreen",
        ".":"AntiqueWhite",
        ",":"CornflowerBlue",
        "`": "Cornsilk",
        "&":"DarkSlateGray",
        "#":"Thistle",
        "{":"RoyalBlue",
        "}":"Tomato ",
        "-":"SaddleBrown",
        ";":"RosyBrown",
        "=":"DarkGray",
        "@":"WhiteSmoke",

        '"':"MediumSpringGreen ",

        _:"LightSteelBlue",
        "~a":"Aquamarine",

        "`b":"AliceBlue",

        "!v":"BlueViolet",





        "!B":"SlateBlue",
        "!g":"LimeGreen",  "!b":"MidnightBlue ", "!G":"SeaGreen", "/":"LavenderBlush",
        "/g":"LightGray",
        _g:"LightGreen",
        _p:"LightPink",
        _s:"LightSalmon",
        _G:"LightSeaGreen",
        "|":"LightSkyBlue",
        _sg:"LightSlateGray",

        _y:"LightYellow",
        _b:"LightBlue",
        _co:"LightCoral",
        _c:"LightCyan",

        "-b":"MediumBlue",
        "-g":"MediumSeaGreen",
        "-s":"MediumSlateBlue ",
        "-o":"MediumOrchid",
        "-p":"MediumPurple ",
        "-t":"MediumTurquoise ",
        "-v":"MediumVioletRed ",

        "~G":"Gainsboro",
        "!t":"DarkTurquoise",
        "`!":"PaleGoldenRod",

        "^b":"SkyBlue",
        "`g":"SpringGreen",
        "`l":"Linen",
        "`c":"MintCream ",
        "`r":"MistyRose ",
        "`s":"SeaShell",
        "/b":"SandyBrown",
        "`G":"PaleGreen ",
        "`t":"PaleTurquoise ",
        "`q":"PaleVioletRed ",
        "db":"DodgerBlue",
        "bw":"BurlyWood",
        "!o":"OliveDrab ",
        "*!" :"NavajoWhite ",
        "!!":"MediumAquaMarine",
        "*b":"PowderBlue",
        "@b":"SteelBlue",
        li:"Lime",
        mg:"Magenta",
        or:"OrangeRed ",
        ir:"IndianRed",
        a:"Aqua",
        "b":"Blue",
        "bg":"Beige",
        "br":"Brown",
        "c": "Cyan",
        "cr": "Crimson",
        "d":"DimGray",
        e:"LemonChiffon",
        f:"ForestGreen",
        g:"Green",
        go:"GoldenRod",
        gr:"gray",
        gy:"GreenYellow",
        h:"HoneyDew",
        i:"Indigo",
        j:"PeachPuff",
        k:"Khaki",
        l:"Lavender",
        m:"Maroon",
        n:"Sienna",
        ol:"OldLace",
        ov:"Olive ",
        o:"Orange ",
        oc:"Orchid ",
        p:"Pink ",
        q:"Bisque",
        r:"Red",
        s:"Silver",
        t:"Turquoise",
        u:"Peru",
        v:"Violet" ,
        w:"Wheat",
        x:"SlateGray",
        y:"Yellow",
        z:"Teal",
        A:"Azure",
        B:"DarkBlue",
        C:"DarkCyan",
        D:"DarkGoldenRod",
        F:"Fuchsia",
        G:"DarkGreen",
        H:"HotPink",
        I:"Ivory",
        J:"Salmon",
        "K":"DarkKhaki",
        L:"LawnGreen",
        "M":"DarkMagenta",
        N:"Navy",
        "O":"DarkOrange",
        P:"Plum ",
        Q:"PapayaWhip ",
        "R":"DarkRed",
        "S":"DarkSalmon",
        T:"Tan",
        U:"Purple",
        V:"DarkViolet",
        W:"White",
        X:"LightGoldenRodYellow",
        Y:"YellowGreen",
        Z:"Moccasin"
    }
o.os={n:'none',h:'hidden','.':'dotted','-':'dashed',
    s:'solid',d:'double',g:'groove',r:'ridge',
    '>':'inset','<':'outset',i:'inherit'}
o.w={'|':'thin','||':'medium','|||':'thick'}
o.t={c:"canvas",
    d:"div",
    i:"input",
    s:"span",
    f:"form",
    b:"button",
    "1":"h1"}
o.e=function(a){var t=this, e={

    "-":"keydown",  "=":"keypress",  "+":"keyup",

    "$": "click","$$":"dblclick",


    "_":"mousedown",  ">":"mouseenter",  "<":"mouseleave",

    "~":"mousemove",  "!":"mouseout",   "^":"mouseover",  "`":"mouseup",


    "&":"blur",   "*":"change",   "@":"load",   "1":"one",


    ".":"ready",   "{}":"resize",   "[]":"scroll",


    "?":"select", "#":"submit",   "|":"focus",


    "|-":"focusin",  "-|":"focusout",   "%":"hover",




}

    a=$(a);

    return function f(b,c,d){

        if(e[b]){a[e[b]](c,d)}
        else {f("$",b,c)}


    }}
o.y={

    i:"inline",
    b:"block",
    ib:"inline-block",
    t:"table",
    n:"none",
   '|':"inherit",

    it:"inline-table",

    l:"list-item",
    c:"table-column",
    r:"table-row",
    cg:"table-column-group",
    rg:"table-row-group",

    p:"table-caption",


   h:"table-header-group",
   f:"table-footer-group",

   e:"table-cell"




}
o.str="who cares what you think. you're just a sissy bitch, riiiiight?"
o.o={w:300,h:300,c:'/',bc:'!',p:20,m:20}};O();

tt=t=function(a){if(iUd(a)){a='d'}
    if(iS(a)){a="<"+o('t',a)+">"};return a}//wraps tags around el (def: div)
rr=r=function(i){i=i||o('c');return _.V(i)[_.R(_.z(i)-1)]}//gives random item (def: color)
vv=kv=function(k,v,i){i=i||'s';
  return {k:o(i,k),v:o(k,v)}}
jj=iJq=function(e){return _.isElement(e[0])}

ee=e=function f(e,s){e=e||{}

    if(!iJq(e)){
        if(s===undefined){return f('d',e)}
        e=$(t(e));s=_.d(s,o('o'))}


    if(iO(s)){
        _.e(s,function(v,k){
           var p=kv(k,v); e.css(p.k, p.v)});


    };


    $l(oh(e))


    return e}

yy=y=function(a){
    if(iUd(a)){return $("body").empty()}
    a=e(a)
    q(qB)('pp',a);
    return a}

yyy=Y=function(c){c=o('c',c||r());$l('* '+c+' *');e(qB,{bc:c})}

ll=ol=function(b){

    if (iUd(b)){b="H"}
    b=spl(b);

    var w=function(w){if(!_.isNaN($N(w))){

        w+='px'};return w}

    return $l(
        o('c',b[0])+' '+w(o('w', b[1]||5))+' '+ o('os',b[2]||'-')
    )}

  qq=q=function(a){
      a=$(a||"body")
           return function f(g){if(iUd(g)){return a}
                g=_.toArray(arguments);var m=_.f(g),p=_.rs(g)
                a=a[o('q',m)].apply(a,p)
               return f}}

Lauren=function(a){qB.css(
    'backgroundColor',o('c',a))}  // set bd bc


e$$$=function(){

    bb.prepend(
        e$$.apply(this,arguments)
    )
}
//dv=function(){return $("<div>")}

//
$(function(){

    d3=y({m:10,pd:10,d:ol(),bc:'y',c:'@',w:50,h:50,y:'ib',})
    d2=y({m:10,pd:10,d:ol(),bc:'y',c:'@',w:100,h:100,y:'ib'})
    d1=y({m:10,pd:10,d:ol(),bc:'y',c:'@',w:300,h:300,y:'ib',d:ol("b 200 r")})
})


sEl=function(h){

    h.$=Fransi($(h));

    h.H=function(){return this.outerHTML}



    // dims
    h.$=function(a){var t=this;
        $(t).click(function(e){
            var x=e.clientX,y=e.clientY;
            a(x-c.x(),y-c.y(),x,y)});
        return t}//target?
    h.$$=function(a){var t=this;
        $(t).dblclick(function(e){var x=e.clientX,y=e.clientY;
            a(x-c.x(),y-c.y(),x,y)});
        h.x=function(x){var t=this;
            if(!x){return t.$.os().left};return $pI(x-t.x())}
        h.y=function(x){var t=this;
            if(!x){return t.$.os().top};return $pI(x-t.x())}


        h.ap=function(){$("body").append(this);return this}
        h.pp=function(){$("body").prepend(this);return this}

        h.l=function(){var t=this;t.$.c.apply(t.Q,arguments);return t}

        h.bg=function(a){this.l('backgroundColor',a)};

        h.bd=function(s,c,y){
            var t=this;if(s==undefined){s=10};
            var ws=function(a){return ' '+a+' '}
            t.l(
                'border',$l(ws(s+"px")+ws(y||"solid")+ws(c||"blue"))
            );return t}



        return t}
    return h}
el2=function(a,b){a=el(a);if(b===undefined){return a[0]};if(iO(b)){
    _.e(b,function(v,k){a.css(x(CSS,k),v)})}
    $l(oh(a));return a}
//

    canvii=function(){
        cS=function(n,c,r,w,h){
            n=$l("<canvas"+((n)?" id='" +n+ "'":'')+
                ((c)?" class='"+c+"'":'')+
                ((r)?" style='background-color:"+r+"' ":'')+
                ((w)?" width="+w+' ':'')+
                ((h)?" height="+h+' ':'')+
                "></canvas>");return $(n)[0]};
        C=function(v,r,f,n,c){var gC=function(a){return W[a]=sC($('#'+a)[0])};if(iS(v)){return gC(v)};
            v=$V(v||500);
            return $do(sC(cS(n,c,r||'purple',v.x,v.y)),f)}
    }



////////  OTHER ///////// OLD  /////// DOM ///////







applyCss=function(jQO,v,k){return jQO.css(k,v)}




bb2=function(a){qq($b)('ap', a)}
bb=function(a){
    if(F(a)){a.prepend($b)} else { $b.prepend(a) } return a}
bb2=function(a){qq($b)('ap', a)}
bb=function(a){if(iF(a)){a.prepend($b) }else { $b.prepend(a) } return a}
bb2=function(a){qq($b)('ap', a)}
bb=function(a){if(iF(a)){_pp($b,a())} else{_pp($b,a)}; return a}
bb=function(){


}
bb2=function(a){qq($b)('ap', a)}
bb=function(a){if(iF(a)){a.prepend($b) }else { $b.prepend(a) } return a}
bb2=function(a){qq($b)('ap', a)}
bb=function(a){if(iF(a)){_pp($b,a())} else{_pp($b,a)}; return a}






CSS=function(q){return function(v,k){ v=ooo(k,v); k=sss(k); _ss(q, k, v)}}
CSS=function(q){return function(v,k){
    v=ooo(k,v);k=sss(k);
    q.css(k,v)}}
CSS=function(q){return function(v,k){ v=ooo(k,v); k=sss(k); _ss(q, k, v)}}





dd=function(q, p){ii(_dd(p||{}), CSS(q)); return q}
dd=function(q, p){
    ii( _dd( p||{} ), CSS(q) );
    return q}
dd=function(q, p){ii(_dd(p||{}), CSS(q)); return q}
_dd=function(a){return _.d(a, oo('D'))};
df=function(a){ return dd(a||{}, oo('D'))}
_dd=function(a){return _.d(a, oo('D'))};
_dd=function(a){return _.d(a, oo('D'))};



dd=function(jQO, startObj){
    startObj=startObj||{}
    startObj=giveDivDefaults(startObj)
    forEachIn(startObj,
        function(val,key){jQO.css(key,val)})
    return qQO}
_dd=function(a){return _.d(a, oo('D'))};

Element=function(tag){var element, tag=tag||'div';
    if(O(tag)){return $(tag)[0]}
    element = $('<'+tag+'>');
    console.log(element)
    return giveDivDefaults(element)}
_e  =function(a){return function(v,k){
    v=kk(k,v);a.css(v.k,v.v)}}
ee  =function f(a,b){var o;
    if(!Q(b)){b=$(tt(b||'d'))};
    o=D(a||{},oo('D'));
    ii(o,_e(b));
    return hh(b)}




ee=function(e){e=e||'d';
    if(F(e)&&e.name==='f'){e=e()};
    if(O(e)){return $(e)[0]}
    var q=$('<'+oo('t', e)+'>'); return dd($lh(q))}
emp=function(a){return a.empty()}
eE=function(a){if(a){return $(a)[0]}}
ee  =function f( a, b ){

    b = tag( b );

    ii( df( a||{} ),

        function(v, k){

            v = oo(k, v ) || v;
            b.css(os(k) || k, v);

        })

    return   eee(    $lh(b)    )}
eee=function( a ){return function f( o ){ if(U(a)){return a}; ee(o,a);return f}}
ee=function(e){e=e||'d';

    if( F(e)&&e.name==='f' ){e=e()}; if(O(e)){return $(e)[0]}


    var q=$('<'+oo('t', e)+'>');

    return dd($lh(q))}
ee=function(e){e=e||'d';
    if(e.name==='f'){e=e()};
    if(O(e)){return $(e)[0]}
    var q=$('<'+oo('t', e)+'>');
    return dd($lh(q))}



font=function f(a){var s,w,z,f;  a=pp(a); ii(a, function(p){
    if(of(p)){f=of(p)}; if(ofw(p)){w=ofw(p)};  if(ofs(p)){s=ofs(p)};
    if(nNn(p[0])) {z=_s(p,'/'); var fz=z[0],fl=z[1];
        z=fz+'px'; if(fl){z+='/'+fl+'px'}}})
    f=[(s||ofs('n')),(w||ofw('n')),(z||100),(f||of('f'))];return $l(_jn(f,' '))}
font =function f(a){

    var s,w,z,f;  a=pp(a);

    ii(a, function(p){

        if(of(p)){f=of(p)};

        if(ofw(p)){w=ofw(p)}

        if(ofs(p)){s=ofs(p)};

        if(nNn(p[0])) {
            z=_s(p,'/');
            var fz=z[0],fl=z[1];
            z=fz+'px';
            if(fl){z+='/'+fl+'px'}}})

    f=[(s||ofs('n')),(w||ofw('n')),(z||100),(f||of('f'))]

    return $l(_jn(f,' '))}
font=function f(a){var s,w,z,f;  a=pp(a); ii(a, function(p){
    if(of(p)){f=of(p)}; if(ofw(p)){w=ofw(p)};  if(ofs(p)){s=ofs(p)};
    if(nNn(p[0])) {z=_s(p,'/'); var fz=z[0],fl=z[1];
        z=fz+'px'; if(fl){z+='/'+fl+'px'}}})
    f=[(s||ofs('n')),(w||ofw('n')),(z||100),(f||of('f'))];return $l(_jn(f,' '))}
font=function f(a){var s,w,z,f;  a=pp(a); ii(a, function(p){
    if(of(p)){f=of(p)}; if(ofw(p)){w=ofw(p)};  if(ofs(p)){s=ofs(p)};
    if(nNn(p[0])) {z=_s(p,'/'); var fz=z[0],fl=z[1];
        z=fz+'px'; if(fl){z+='/'+fl+'px'}}})
    f=[(s||ofs('n')),(w||ofw('n')),(z||100),(f||of('f'))];return $l(_jn(f,' '))}
font=function f(a){var s,w,z,f;  a=pp(a); ii(a, function(p){
    if(of(p)){f=of(p)}; if(ofw(p)){w=ofw(p)};  if(ofs(p)){s=ofs(p)};
    if(nNn(p[0])) {z=_s(p,'/'); var fz=z[0],fl=z[1];
        z=fz+'px'; if(fl){z+='/'+fl+'px'}}})
    f=[(s||ofs('n')),(w||ofw('n')),(z||100),(f||of('f'))];return $l(_jn(f,' '))}
font=function f(a){var s,w,z,f;  a=pp(a); ii(a, function(p){
    if(of(p)){f=of(p)}; if(ofw(p)){w=ofw(p)};  if(ofs(p)){s=ofs(p)};
    if(nNn(p[0])) {z=_s(p,'/'); var fz=z[0],fl=z[1];
        z=fz+'px'; if(fl){z+='/'+fl+'px'}}})
    f=[(s||ofs('n')),(w||ofw('n')),(z||100),(f||of('f'))];return $l(_jn(f,' '))}


giveDivDefaults=function(a){return defaults(a,
    {width:800,
        height:300,
        color:'red',
        backgroundColor:'blue',
        padding:20,
        margin:20,
        display:'inline-block',
        font:'50px fantasy'})}


giveDivDefaults=function(a){return defaults(a,
    {width:800,
        height:300,
        color:'red',
        backgroundColor:'blue',
        padding:20,
        margin:20,
        display:'inline-block',
        font:'50px fantasy'})}



kk=function(k,v,i){return{k:oo(i||'s',k),v:oo(k,v)}}






$lh=function(q){$l(q[0].outerHTML);return q}
ll=function f(a){var col,wid,sty;a=pp(a)
    col= oc(a[0]||'a'); wid= ow(a[1])||a[1]||5;if(nNn(wid)){wid+='px'}; sty= oos(a[2]||'-')
    return $l(_jn([col,wid,sty],' '))}
ll = function f(a){var col,wid,sty;a=pp(a)

    col= oc(a[0]||'a')
    wid= ow(a[1])||a[1]||5;if(nNn(wid)){wid+='px'}
    sty= oos(a[2]||'-')

    return $l(_jn([col,wid,sty],' '))}
ll=function f(a){var col,wid,sty;a=pp(a)
    col= oc(a[0]||'a'); wid= ow(a[1])||a[1]||5;if(nNn(wid)){wid+='px'}; sty= oos(a[2]||'-')
    return $l(_jn([col,wid,sty],' '))}
//Lauren=function(a){$B.css( 'backgroundColor', oo('c',a))}  // set bd bc
$lh=function(a){ a=$(a)[0].outerHTML; if(a){return $($l(a))}  }
$lh=function(q){$l(q[0].outerHTML);
    return q}
$lh=function(q){$l(q[0].outerHTML);return q}
ll=function f(a){var col,wid,sty;a=pp(a)
    col= oc(a[0]||'a'); wid= ow(a[1])||a[1]||5;if(nNn(wid)){wid+='px'}; sty= oos(a[2]||'-')
    return $l(_jn([col,wid,sty],' '))}
ll=function f(a){var col,wid,sty;a=pp(a)
    col= oc(a[0]||'a'); wid= ow(a[1])||a[1]||5;if(nNn(wid)){wid+='px'}; sty= oos(a[2]||'-')
    return $l(_jn([col,wid,sty],' '))}
ll   =function(b){
    if(U(b)){b="H"};
    b=pp(b);
    return $l(
        jj([oo('c',b[0]),
            (function(w){
                if(!N($N(w))){
                    w+='px'};
                return w}(
                    oo('w',b[1]||5))
                ),
            oo('os',
                b[2]||'-')]))}
$lh=logOuterHTML=function(jQO){console.log(qQO[0].outerHTML);
    return qQO}
ll=function f(a){var col,wid,sty;a=pp(a)
    col= oc(a[0]||'a'); wid= ow(a[1])||a[1]||5;if(nNn(wid)){wid+='px'}; sty= oos(a[2]||'-')
    return $l(_jn([col,wid,sty],' '))}




ooo=function(a,b){if(b){if(oo(a,b)){return oo(a,b)};return b};if(oo(a)){return oo(a)};return a}
ooo=function(a,b){
    if(b){
        if(oo(a,b)){return oo(a,b)};
        return b}
    if(oo(a)){
        return oo(a)};
    return a}
ooo=function(a,b){if(b){if(oo(a,b)){return oo(a,b)};return b};if(oo(a)){return oo(a)};return a}
ooo=function(a,b){
    if(b){
        if(oo(a,b)){return oo(a,b)};
        return b}
    if(oo(a)){
        return oo(a)};
    return a}



_pp=function(a,b){a.prepend(b); return a}
//perfect little parser.. handles any strings separated by any ws
pp=function(a){  if(!a){ return []};  return _.cm(  _s(a, ' ' )  ) } // (split on ws) - ''@
//perfect little parser.. handles any strings separated by any ws
pp=function(a){  if(!a){ return []};  return _.cm(  _s(a, ' ' )  ) } // (split on ws) - ''@
_pp=function(a,b){a.prepend(b); return a}
_pp=function(a,b){a.prepend(b); return a}
_pp=function(a,b){a.prepend(b); return a}
_pp=function(a,b){a.prepend(b); return a}
pp=perfectLittleParser=parser=parse=function(a){

    if(!a){return []}

    return compact(a.split(' '))

}
pp=function(a){  if(!a){ return []};  return _.cm(  _s(a, ' ' )  ) } // (split on ws) - ''@
//perfect little parser.. handles any strings separated by any ws
pp=function(a){  if(!a){ return []};  return _.cm(  _s(a, ' ' )  ) } // (split on ws) - ''@
//perfect little parser.. handles any strings separated by any ws
pp=function(a){  if(!a){ return []};  return _.cm(  _s(a, ' ' )  ) } // (split on ws) - ''@






_q=function(p){if(p.name==='f'){return p()};return p}
qq=function(q){

    q=q||$b;   if(iF(q)) {q=q()}


    return function f(m){if(U(m)){return q};

        if(iF(m)){return m(q)}

        var a=arguments, g=_.m(_.rest(a), _q), m=oq(m);

        $l('q.'+m+' -> '+a[1]||''+' '+a[2]||''+' '+a[3]||'');

        q[m].apply(q, g);

        return f}}
qq  =function f( e ){

    e = $( e || "body" );

    return function F(i){

        if(i){ e = e [oq( i )].apply( e, rr(arguments) ); return F }

        return e} }
Q=function(a){return E(a[0])}
//Q=function(a){return E(a[0])}
//nQ=function(a){return O(a)&&!Q(a)}
nQ=function(a){return O(a)&&!Q(a)}
_q=function(p){  if(p.name==='f'){  return p()}; return p}
qq=function(q){eval(g$);q=q||$b;if(F(q)){q=q()}
    return function f(m){if(U(m)){return q};
        if(F(m)){return m(q)}
        g= _.m(rG, _q), m=oq(m); $l( 'q.'+m+' -> '+a[1]||''+' '+a[2]||''+' '+a[3]||'');
        ap(q[m],q,g);return f}}
qq=function(jQ){  var args

    jQ=jQ||$b;   if(F(jQ)){jQ=jQ()}

    return function self(met){if(notProvided(met)){return jQ};

        if(F(met)){return met(jQ)}

        args = map(rest(arguments), invokeIfPossible);

        $l('jQ.'+ met +' -> '+a[1]||''+' '+a[2]||''+' '+a[3]||'');

        jQ[met].apply(jQ, args);  return self}}
_q=function(p){if(p.name==='f'){return p()};return p}
_q=function(p){if(p.name==='f'){return p()};return p}
qq=function(q){

    q=q||$b;   if(iF(q)) {q=q()}


    return function f(m){if(U(m)){return q};

        if(iF(m)){return m(q)}

        var a=arguments, g=_.m(_.rest(a), _q), m=oq(m);

        $l('q.'+m+' -> '+a[1]||''+' '+a[2]||''+' '+a[3]||'');

        q[m].apply(q, g);

        return f}}
qq=function(q){

    q=q||$b;   if(iF(q)) {q=q()}


    return function f(m){if(U(m)){return q};

        if(iF(m)){return m(q)}

        var a=arguments, g=_.m(_.rest(a), _q), m=oq(m);

        $l('q.'+m+' -> '+a[1]||''+' '+a[2]||''+' '+a[3]||'');

        q[m].apply(q, g);

        return f}}
qq=function f(a){
    a=f.n(a);
    return function f(g){
        if(U(g)){return a};
        a =a[oo('q', ff(g))].apply(a, rr(g))

        return f}
}
qq.n=qq.qNodeOrBody=function(a){return $(a||$b)}
qq.a=qq.apply2rsG=function(a,b,c){return a.apply(b, rr(c))}
//Q=function(a){return E(a[0])}
//nQ=function(a){return O(a)&&!Q(a)}




rr=function f(i){
    var n=function(a){
        return _.R( _.z(a) -1 )};
    var v=vv(oo(i||'c'));
    return v[f.n(i)]};
rr=function f(i){
    var n=function(a){
        return _.R( _.z(a) -1 )};
    var v=vv(oo(i||'c'));
    return v[f.n(i)]};
rr=function f(i){
    var n=function(a){
        return _.R( _.z(a) -1 )};
    var v=vv(oo(i||'c'));
    return v[f.n(i)]};
rr=function f(i){
    var n=function(a){
        return _.R( _.z(a) -1 )};
    var v=vv(oo(i||'c'));
    return v[f.n(i)]};


randomSample = function self(ob){ob||COLORS

    var num=function(a){
        return random( sizeOf(ob) -1 )};
    return every[ self.num(ob) ]};
R=function f(i){var v=vv(oo(i||'c'));  return v[f.n(i)]};
R.n=function(a){return _.R( _.z(a) -1 )}
runIfFun=funRun=tryToRun=invokeIfPossible=runIfCan=function(fUN){if(F(fUN)){return fUN()};return fUN}






_ss=function(a,b,c){a.css(b,c)};
sss=function(a){
    if(os(a)){
        return os(a)};
    return a}
ss=function(q){
    if(U(q)){q=ee()};if(S(q)){q=ee(q)};
    if(P(q)){q=dd(ee(),q)};q=_q(q);
    return function f(p, b){
        if(F(p)){return p(q)};  if(U(p)){return q};
        if(b){var a={};
            a[p]=b;
            p=a}
        else if(S(p)){
            return q.css(sss(p))}
        ii(p, CSS(q));
        return f}}
sss=function(a){if(os(a)){return os(a)};return a}
_ss=function(a,b,c){a.css(b,c)};
star=function(a){return a==="*"};
_ss=function(a,b,c){a.css(b,c)};
_ss=function(a,b,c){a.css(b,c)};
sss=function(a){
    if(os(a)){
        return os(a)};
    return a}
sss=function(a){if(os(a)){return os(a)};return a}
ss=function(q){
    if(U(q)){q=ee()};if(S(q)){q=ee(q)};
    if(P(q)){q=dd(ee(),q)};q=_q(q);
    return function f(p, b){
        if(F(p)){return p(q)};  if(U(p)){return q};
        if(b){var a={};
            a[p]=b;
            p=a}
        else if(S(p)){
            return q.css(sss(p))}
        ii(p, CSS(q));
        return f}}
ss=function(q){
    if(U(q)){q=ee()}; if(S(q)){q=ee(q)}; if(nQ(q)){q=dd(ee(), q)};q=_q(q);
    return function f(p, b){  if(iF(p)){return p(q)};  if(U(p)){return q};
        if(b){var a={};a[p]=b;p=a} else if(S(p)){return q.css( sss(p) )}
        ii(p, CSS(q)); return f}}
ss=function(jQ){
    if(notProvided(jQ)){jQ=$(elem())}
    if(F(jQ)){jQ=jQ()}
    if(S(jQ)){jQ=elem(jQ)}
    if(oButNotQ(jQ)){ jQ = setCss(el(), sDf(jQ))}

    return function self(pop,b){
        if(F(pop)){return pop(jQ)};
        if(notProvided(pop)){return jQ};
        if(b){var ob={}; ob[pop]=b; pop=ob}
        else if(S(pop)){return jQ.css(pop) }

        forEach(pop, setCss(jQ));

        return self}
}
ss=function(q){
    if(U(q)){q=ee()};
    if(S(q)){q=ee(q)};
    if(nQ(q)){q=dd(ee(), q)}
    q=_q(q);
    return function f(p, b){  if(iF(p)){return p(q)};  if(U(p)){return q};
        if(b){var a={};a[p]=b;p=a}
        else if(S(p)){return q.css( sss(p) )}
        ii(p, CSS(q));
        return f}}





tag=function f(t){

    if(O(t)){ return t };

    return $('<'+oo('t', t||'d')+'>')}








y=function(a){return bb(ss(a))}
y=function(a){return bb(ss(a))}
yy   =function f(a,b){


    if(a==='!'){$ls(b=oo('c',b||R()));f({bc:b},$b)}

    if(U(a)){$b.empty()}
    else{a=ee(a);
        qq($b)('ap',a)};
    return a};
Y=function f(a,b){
    if(a==='*'){$ls(b=oo('c',b||R()));return yy({bc:b},$b)}

    if(iN(a)){return $b.css(oo('s','fs'),a)}

    if(iS(a)){return $b.text(a)}

    $ls(a=oo('c',R()));
    $b.css( oo('s','bc'),a)
    $ls(a=oo('c',R()));
    $b.css( oo('s','c'),a)
}
yy=function f(a, b){  b=b||$b; if(U(a)){
    emp(b)};  a=ee( a )();
    bb(a);   return a}
Y=  function f(a,c){ if(star(a)){ $l(  c=oc(c)||R('c')   ); return yy(  {bc:c}, $b  ) }
    if(S(a)){return $b.text(a)};  if(N(a)){return qq($b)(os('fs'),a)};   $ls(a=oo('c', R()));
    $b.css( os('bc'), a);$ls(   a=oo('c', R() )    );  $b.css(os('c'), a)};
Y.y=function(a, b){var c=$l(  R('c') ); $b.css(os(b),c); return b}
yy=function f(a, b){  b=b||$b; if(U(a)){emp(b)};  a=ee( a )();  bb(a);   return a}
Y=  function f(a,c){ if(star(a)){ $l(  c=oc(c)||R('c')   ); return yy(  {bc:c}, $b  ) }
    if(S(a)){return $b.text(a)};  if(N(a)){return qq($b)(os('fs'),a)};   $ls(a=oo('c', R()));
    $b.css( os('bc'), a);$ls(   a=oo('c', R() )    );  $b.css(os('c'), a)};
Y.y=function(a, b){var c=$l(  R('c') ); $b.css(os(b),c); return b}
//perfect little parser.. handles any strings separated by any ws
yy=function f(a, b){  b=b||$b; if(U(a)){emp(b)};  a=ee( a )();  bb(a);   return a}
Y=  function f(a,c){ if(star(a)){ $l(  c=oc(c)||R('c')   ); return yy(  {bc:c}, $b  ) }
    if(S(a)){return $b.text(a)};  if(N(a)){return qq($b)(os('fs'),a)};   $ls(a=oo('c', R()));
    $b.css( os('bc'), a);$ls(   a=oo('c', R() )    );  $b.css(os('c'), a)};
Y.y=function(a, b){var c=$l(  R('c') ); $b.css(os(b),c); return b}
Y=  function f(a,c){ if(star(a)){ $l(  c=oc(c)||R('c')   ); return yy(  {bc:c}, $b  ) }
    if(S(a)){return $b.text(a)};  if(N(a)){return qq($b)(os('fs'),a)};   $ls(a=oo('c', R()));
    $b.css( os('bc'), a);$ls(   a=oo('c', R() )    );  $b.css(os('c'), a)};
Y=  function f(a,c){

    if(star(a)){ $l(  c=oc(c)||R('c')   ); return yy(  {bc:c}, $b  ) }

    if(iS(a)){return $b.text(a)}

    if(iN(a)){return qq($b)(os('fs'),a)}

    $ls(a=oo('c', R()));

    $b.css( os('bc'), a);

    $ls(   a=oo('c', R() )    );

    $b.css(os('c'), a)};
Y=  function f(a,c){ if(star(a)){ $l(  c=oc(c)||R('c')   ); return yy(  {bc:c}, $b  ) }
    if(S(a)){return $b.text(a)};  if(N(a)){return qq($b)(os('fs'),a)};   $ls(a=oo('c', R()));
    $b.css( os('bc'), a);$ls(   a=oo('c', R() )    );  $b.css(os('c'), a)};
y=function(a){return bb(ss(a))}
yy=function f(a, b){  b=b||$b;  if(U(a)){emp(b)};     a=ee(a);  qq(b)('ap', a);  return a}
yy=function f(a, b){  b=b||$b;  if(U(a)){emp(b)};  a=ee( a )();  bb(a);   return a}
Y.y=function(a, b){var c=$l(  R('c') ); $b.css(os(b),c); return b}





zz=function(a,b){b  =  oc(b)||R('c');  yy( {bc:b}, a )}


zz=function(a,b){b  =  oc(b)||R('c');  yy( {bc:b}, a )}
zz=function(a,b){b  =  oc(b)||R('c');  yy( {bc:b}, a )}







//wraps tags around el (s->s)(def: div)
_t=tt=function f(a){return f.b(f.e(a||'d'))}
_t.b=_t.brackets=function(a){return '<'+a+'>'}
_t.e=_t.expTagType=function(a){return oo('t',a)}


$f=function f(a){var F=new $F(
    "a","b","c","d","e",
    "var g=aA(arguments),"+
        "t=this,o={},s='',l=[],z=0;"+
        a+";return t");
    return F}

_U=function(a,b){if(U(a)){$f(b)(a,b)}}






aaa='a a a a a a a a a a a a a a a a a a a a aa a a a a a a a a a a a a '
bbb='b b b b b b b b b b b b b b b b b b b b b b b b b b b b b b b b b b '
ccc='cc c c c c c c c c c c c c  c c c c c c c c  c  c c c c c c  c c c c c'

$(function(){

    $b=$("body");

    z=yy()

    q=qq( z )

    e=eee( z );


    q('t', 'sdfa asfd asfd sadf asdf sadf')
    // $b.css(oo('s','fs'), 150)

    //  d3=yy({m:10,pd:10,d:ll(),bc:'y',c:'@',w:50,h:50,y:'ib',})
    //  d2=yy({m:10,pd:10,d:ll(),bc:'y',c:'@',w:100,h:100,y:'ib'})
    //  d1=yy({m:10,pd:10,d:ll(),bc:'y',c:'@',w:300,h:300,y:'ib',d:ll("b 200 r")})
})
$(function(){

    $b=$("body");

    // sc=ss({bc:'#',c:'%',w:100,h:100}); bb(sc); sc().text(ccc);




    // sb=ss(ee('c')); ss({bc:'r', c:'b',w:300,h:300}); bb(sb); sb().text(bbb);


    // sa=ss({bc:'y',c:'w',w:600,h:600}); bb(sa); sa().text(aaa);

    // qc=qq(sc);    qb=qq(sb); qa=qq(sa);

    //zz=function(){ z({c:'g'}) }







    // z=yy(); q=qq( z ); e=eee( z );


    // q('t', 'sdfa asfd asfd sadf asdf sadf')
    // $b.css(oo('s','fs'), 150)

    //  d3=yy({m:10,pd:10,d:ll(),bc:'y',c:'@',w:50,h:50,y:'ib',})
    //  d2=yy({m:10,pd:10,d:ll(),bc:'y',c:'@',w:100,h:100,y:'ib'})
    //  d1=yy({m:10,pd:10,d:ll(),bc:'y',c:'@',w:300,h:300,y:'ib',d:ll("b 200 r")})


})
//Lauren=function(a){$B.css( 'backgroundColor', oo('c',a))}  // set bd bc
Lauren=function(a){$B.css(
    'backgroundColor', oo('c',a))}  // set bd bc

$(function(){

    $b=$("body")
    $b.css(oo('s','fs'), 150)

    //  d3=yy({m:10,pd:10,d:ll(),bc:'y',c:'@',w:50,h:50,y:'ib',})
    //  d2=yy({m:10,pd:10,d:ll(),bc:'y',c:'@',w:100,h:100,y:'ib'})
    //  d1=yy({m:10,pd:10,d:ll(),bc:'y',c:'@',w:300,h:300,y:'ib',d:ll("b 200 r")})
})
$(function(){

    $b=$("body");

    // sc=ss({bc:'#',c:'%',w:100,h:100}); bb(sc); sc().text(ccc);




    // sb=ss(ee('c')); ss({bc:'r', c:'b',w:300,h:300}); bb(sb); sb().text(bbb);


    // sa=ss({bc:'y',c:'w',w:600,h:600}); bb(sa); sa().text(aaa);

    // qc=qq(sc);    qb=qq(sb); qa=qq(sa);

    //zz=function(){ z({c:'g'}) }







    // z=yy(); q=qq( z ); e=eee( z );


    // q('t', 'sdfa asfd asfd sadf asdf sadf')
    // $b.css(oo('s','fs'), 150)

    //  d3=yy({m:10,pd:10,d:ll(),bc:'y',c:'@',w:50,h:50,y:'ib',})
    //  d2=yy({m:10,pd:10,d:ll(),bc:'y',c:'@',w:100,h:100,y:'ib'})
    //  d1=yy({m:10,pd:10,d:ll(),bc:'y',c:'@',w:300,h:300,y:'ib',d:ll("b 200 r")})
})
//Lauren=function(a){$B.css( 'backgroundColor', oo('c',a))}  // set bd bc



$(function(){

    $b=$("body");

    sc=ss({bc:'#',c:'%',w:100,h:100}); bb(sc); sc().text(ccc);




    sb=ss(ee('c')); ss({bc:'r', c:'b',w:300,h:300}); bb(sb); sb().text(bbb);


    sa=ss({bc:'y',c:'w',w:600,h:600}); bb(sa); sa().text(aaa);

    qc=qq(sc);    qb=qq(sb); qa=qq(sa);

     zz=function(){ z({c:'g'}) }







  z=yy(); q=qq( z ); e=eee( z );


    q('t', 'sdfa asfd asfd sadf asdf sadf')
    $b.css(oo('s','fs'), 150)

     d3=yy({m:10,pd:10,d:ll(),bc:'y',c:'@',w:50,h:50,y:'ib',})
   d2=yy({m:10,pd:10,d:ll(),bc:'y',c:'@',w:100,h:100,y:'ib'})
      d1=yy({m:10,pd:10,d:ll(),bc:'y',c:'@',w:300,h:300,y:'ib',d:ll("b 200 r")})


})

Lauren=function(a){$B.css( 'backgroundColor', oo('c',a))}  // set bd bc


$(function(){
    i=y('g');

    i()[0].src="/me.png";

    c=y('c')
    x=xx( c)

    f=function(){ x('d',i(ee), 0, 0,50,50)   }
})

