

var Cv=function(c){
    var x=c.getContext('2d'),
        o={obj:c},  w="width",h="height" ,sv="save",rs="restore",
        rt="rotate",  sc="scale",  tl="translate",
        sk="skew",clR="clearRect", pt="createPattern",rg="createRadialGradient",
        lg="createLinearGradient",cs="addColorStop",
        bp="beginPath",cp="closePath", du="toDataURL",
        cl="clip",re="rect",mt="moveTo", fl="fill",fr="fillRect",
        ft="fillText", so="stroke",sr="strokeRect",  st="strokeText",
        lt="lineTo",at="arcTo",  gid="getImageData", pid="putImageData",
        fo="font", pp="isPointInPath",di="drawImage "}
//c.S=sS(S$(C),c);
//  c.C=sEl(C);
//  c.X=sX(C.getContext('2d'),c);
//h.$=sQ($(h));//c.H = _.b(c.C.H, c.C); c.pop=c.X_=_.b(c.X.pop,c.X);// o.q=Fransi($(h));o.ctx=x;


sQ=function($){
    $.a=$.after;	//Inserts content after selected elements
    $.b=$.before;	//Inserts content before selected elements
    $.ap=$.append;	//Inserts content at the end of selected elements
    $.apT=$.appendTo;	//Inserts HTML elements at the end of selected elements
    $.A=$.insertAfter;	//Inserts HTML elements after selected elements
    $.iB=$.insertBefore;	//Inserts HTML elements before selected elements
    $.pp=$.prepend;	//Inserts content at the beginning of selected elements
    $.ppT=$.prependTo;	//Inserts HTML elements at the beginning of selected elements
    $.ps=$.position;	//Returns the position (relative to the parent element) of an element
    $.t=$.text;	      //Sets or returns the text content of selected elements
    $.tCl=$.toggleClass; //Toggles between adding/removing one or more classes from selected elements
    $.uW=$.unwrap;	  //Removes the parent element of the selected elements
    $.w=$.wrap;	      //Wraps HTML element(s) around each selected element
    $.wA=$.wrapAll;	  //Wraps HTML element(s) around all selected elements
    $.wI=$.wrapInner;	  //Wraps HTML element(s) around the content of each selected element
    $.att=$.attr;	//Sets or returns attributes/values of selected elements
    $.aCl=$.addClass;	//Adds one or more class names to selected elements
    $.cl=$.clone;	//Makes a copy of selected elements
    $.c=$.css;	//Sets or returns one or more style properties for selected elements
    $.p=$.prop;	//Sets or returns properties/values of selected elements
    $.hCl=$.hasClass;	//Checks if any of the selected elements have a specified class name
    $.H=$.html;	//Sets or returns the content of selected elements
    $.w=$.width;	//Sets or returns the width of selected elements
    $.h=$.height;	//Sets or returns the height of selected elements
    $.os=$.offset;	//sets or returns the offset coordinates for selected elements (relative to the document)
    $.osP=$.offsetParent;	//Returns the first positioned parent element
    $.oH=$.outerHeight;	//Returns the height of an element (includes padding and border)
    $.oW=$.outerWidth;	//Returns the width of an element (includes padding and border)
    $.iH=$.innerHeight;	//Returns the height of an element (includes padding, but not border)
    $.iW=$.innerWidth;	//Returns the width of an element (includes padding, but not border)
    $.sL=$.scrollLeft;	//Sets or returns the horizontal scrollbar position of selected elements
    $.sT=$.scrollTop;	//Sets or returns the vertical scrollbar position of selected elements
    $.v=$.val; //Sets or returns the value attribute of the selected elements (for form elements)
    $.d=$.detach;	    //Removes selected elements (keeps data and events)
    $.e=$.empty;	        //Removes all child nodes and content from selected elements
    $.r=$.remove;	    //Removes the selected elements (including data and events)
    $.rAt=$.removeAttr;	//Removes one or more attributes from selected elements
    $.rCl=$.removeClass;	//Removes one or more classes from selected elements
    $.rP=$.removeProp;	//Removes a property set by the prop; method
    $.rpA=$.replaceAll;	//Replaces selected elements with new HTML elements
    $.rpW=$.replaceWith;   //Replaces selected elements with new content
    return $}
xxinterestingForComparisonOnAFewThings=function(c){
    if(E(x)){x=Xx(c)}return function(a, b){var rg=  rest(arguments);
        if(A(b)){rg=b};return x[XXX[a]].apply(x,rg) }}
}

o.S=sS(S$(C),c);


o.$=Fransi($(h));

o.H=function(){return this.outerHTML}
 