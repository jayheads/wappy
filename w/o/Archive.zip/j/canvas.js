

$c   =function cv(r,w,h){

    if(!S(r)){return cv($r(),r,w)}

    var c=em('c')

    w=w||4;   h=h||w

    w*=100; h*=100

    ss(c,{C:r})

    aaWH(c,w, h)
    //if(a==="<"){c=tT(f(b,c,d))}
    //if(a===">"){c=tB(f(b,c,d))}
    c.h=oH(c)
    c.x=X(c)
    tB(c)
    return c}