

o('pop',function(o){
    var e=function(a,b,c){
            if(!c){return}
            var s='<'+a+'>'+c.shift()+'</'+a+'>'
            _e(c, function(l){s+='<'+b+'>'+l+'<'+b+'>'})
            return s},
        h=function(a,b){$('#p'+a).html(b)}

    h('H',e('h2','h6',o.h));
    h('B',e('h1','h3',o.b));
    h('F',o.f)
    $('#pop').modal()})
o('cMsg',function(d){$("#chat").append(d)}) //receive
//cl('sub',function(d){var e=$("#mit")[0], v=e.value + '<br>'; $("#chat").append(v); e.value=''; k.e('uMsg', v)})      //send


div=function(r, w, h, tr, t, p, m){var d=em('d')

    ss(d, {

        w: w,      h: h,       p: p||0,
        m: m||0,   c: r||'g',  C: r||'r'})

    return d}




room=function(){var d=tT(div(600, 600, 0, 10))

    att(d,'id','room')

    ss(d,{
        ml: 100,  mh: 600,  c:'o',
        C:'b',   of:'s',  fz:16})}


nCht=function(m){cht(room,m,"pink","green")}
akCht=function(m){cht(room,m,"green","pink")}// k.o('uM',updateMap);
// k.o('n',function(n){nCht(n)})
//k.o('RmMak',function(m){akCht(m)})
//k.o('nPlr',function(p){d(p);//$("#baby").load('/mappy/newPlayer/'+p.u)})//$('#nPlr').modal({href:'/mappy/nPlr/'+p._id})
//function(rm){return function(m,r,br){rm.append(div(550,null,10,20,r,br,m));rm.scrollTop(190)}}
//$(function(){sm(function(p){$w.loc.href +='/'+p);return false})});
//function sem(f){ cll('sem', function(){f(this.innerHTML)})}
//$(function(){//c.t();e('eG')})
//o('mp',function(Gs,s){cD(Gs);_e(Gs,function(g){ups(g,s)})})
//o('you', function(u){me=u;  l(me);  p=mua();  p.T()})
//mua=function(){    return _.w(Gs, {u:me})[0]}
//sm=function(f){cl('sub',function(e){pD(e); f(_vl('mit'))})}
//act=function(){e('act', {x:p.x,  y:p.y})}
//$('.pop').click(function(){
// k.e('pop',{t:[$('.pop')[0].value],b:[$('.bop')[0].value]})})//send






BUTS=function(h){
    _e(h,
        function(v,k){
            cl(k,v)})}
ccl=function(elC,f){
    var b=$('.'+elC),k=clk

    k(b,  (!f)? $w[elC]: f)}


qid=function(a,b){
    var r=$('#'+ a)
    if(N(b)){r=r[b]}
    return r}
_vl=function(v){return _v(qid(v,0))}
cl=function(eI,f){
    var b=qid(eI),k=clk
    k(b, (!f)? $w[eI]: f)}
/// *** FN!-pass elID,fn: el -> btn w/ that behavior!




//ex:$('#rtC').cl(rtC) ==> clk("rtC")
//function gy(g){return _.w(Gs,{n:g})[0]}



ups=function(g,s,f){
    Gs=$w['Gs']||[]

    var G=_.w(Gs,{u:g.u})[0]

    if(!G){
        c.b(
            g.m,
            function(b){
                b.u=g.u
                b.x=g.x
                b.y=g.y
                if(b.u==s){
                    p=b
                    b.scaleX=b.scaleY=1.5
                    b.T()}

                b.$$(function(g){ alert(g.u) })
                Gs.push(b)
                if(f){f(b)}},
            1)}
    else{
        G.x=g.x
        G.y=g.y}
    return G}

pD=function(a){a.preventDefault()}