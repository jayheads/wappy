


 pix=function(x){
     x=xx(x)






 }


 eaPix=function(d,f){  _e(d,f)}


 theData=function(x){ x=xx(x)

          var iD= x('G',0,0, x.w(), x.h()).res,
              d=_d(iD)


     d.h=iD.height
     d.w=iD.width
     return d

 }

 gID=function(){}
 pID=function(x,d,px,py){xx(x)('P',d,px,py)}