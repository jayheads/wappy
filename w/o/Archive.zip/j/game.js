game=function(f){K(f,50)}


sir=function s(x,o,b,c){x=xx(x)
    var g=G(arguments)
    if(g.n){x.X()}
    if(g.P){x('b')}

    if(O(o)){
        x('a',
            o.x*100,
            o.y*100,o.r*10,
            pi(((o.b||0 )/6 )+1),
            pi(((o.e||12)/6 )+1),
            o.c)

        x('s')

        if(o.a){x({ga: o.a})}
        if(o.f){x({fs: o.f}, 'f' )}
        return _p(s, x)}


    else {s(x,{x:o,y:b,r:c} )}}



gals=function s(k){ if(X(k)){   _e(s, function(a){  sir(X(k), a)})}
    else{ return s[k]}}


sis=function s(n,o){

    if(N(n)){  _t(n, function(){s()});
        return}

    o=D(o||{},

        {x:_r(5)+3,
         y:_r(5),
         r:_r(10),
         f:$r('c'),
            a: _r(100)/100

        })

    gals[n|| _r(100)]=o}


miss=function(){  x.X(); _e(gals, function(a){

        update(a); sir(x,a) })}

cage=function c(a){
    if(a){ return a + c()}


    return (  _r(100) / 10000) * ( _r()? 1: -1)  }

neg=function(a){return -a}

tiny=function(a,r){
    var p=( _r(5)/10)* .01, n=a* p

    if(_r()){n=neg(n)}

    r=10.5-r

    a=a+  ((n * r *r )/5)
    cL(a)
    return a


}


update=function(a){

    a.x=tiny(a.x, a.r)
    a.y=tiny(a.y, a.r)

}



//anim
f30=function(f){K(f,1000/30)}


state=0

drawScreen=function(){
    x.X()
    if(state){p1(x, sh2)  }
    else {p1(x, sh1)}


}








//
hell=function(){
    x.$(function(a,b){
        x.D(p('me'),
            a,b)})}


jayHeads=function(){
    c.X()
    c.d(p('me'),
        50,
        50)
    c.d(p('me'),
        100,
        100)}



//


sh1=[ [1.0,0],[1.9,1.9],[1,.9],
    [.9,.9],[0,1.9],[.9,0]]

sh2= [
    [[1,0],[1.9,1.9],[1,.9],
     [.9,,9],[0,1.9],[.9,0] ],
    [[.8,1.3],[1.2, 1.3]],
    [[9,1.4],[9,1.8]],
    [[1,1.4],[1,1.8]]]



sun=function(x,a,b,s){
    x=X(x)
    a=a||0
    b=b||a||0
    s=s||1
    var w=s*100,
        h=s*500,
        r=rgba('p',0)
    gr(x,
        [[a,b],
            w,
            h],
        {'y':0,
            1:r},
        600,
        600)}








     scale=function(v,a){

         v.x*=a;
         v.y*=a
         return v
     }

unit=function(v){

    v.x= (v.x/v.l())
    v.y= (v.y/v.l())
        return v
}

tFx=function(a,b){return a.toFixed(b||3)}

vec=function(x,y){var v=function v(){}
    v.x= x||2
    v.y =y||2
    v.sq=function(){return sq(v.x, v.y)}
    v.l=function(){return sqr( v.sq() )}
    v.a=function(a){
        var g=G(arguments)
        if(g.n){a=(inv(a))}
        v.x+= a.x;
        v.y+= a.y;
        return v}
    v.s=function(a){v.x*= a;
        v.y*= a;
        return v}
    v.u=function(){v.x= v.x/v.l();
        v.y=v.y/v.l() }
    v.n=function(){v.x*=-1;  v.y*=-1}
    v.p=function(a){return (v.x*a.x)+(v.y*a.y)}
    v.r=function(a){
        v.x=v.x*cos(a)-v.y*sin(a)
        v.y=v.x*sin(a)+v.y*cos(a)
        return v}

    v.toString=function(){
        return '('+  tFx(v.x) +','+  tFx(v.y) + ')'}
    v.v= v.toString
    return v}



   canBall=function(x,v){

       x=xx(x)

       cir(v.x, v.y, 100)
         x({fs:'o'},'f')
   }