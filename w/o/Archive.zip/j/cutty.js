cutty=function(){
//
    //good ****
    //extend path//restroke to show new seg //add new pt to arr  //p gets set to FIRST pt
    clR=function clR(a,b,e,d){c.P().P(a,b,e,d).P('!')}
    CUT=function CUT(c){c.i();c.j();
        c.$(function(x,y){c.pp(x,y)});
        c.$$(function(x,y){
            c.cut()});
        $P=[]}

////


    p=cl=0;vx=[];
    c=C(400,'blue').pp().k('yellow').k(4).P();
    I('me',function(i){c.df(i);c.c()})
    c.$(function(x,y){
        if(cl==true){$l('cl');clip()}
        else{c.k(x,y).k();vx.push([x,y]);
            if(!p){p=[x,y]}
            else if(x<p[0]&&y<p[1]){
                cl=true}}});
    clip=function(){var f=_.f(vx),v= _.rs(vx);
        c._();c.P().k(f[0],f[1]);_.e(v,function(v){c.k(v[0],v[1])});
        c.P(0);c.P('!');c.p()}
    dst=function(a,b,c,d){
        var q=function(a){return a*a};
        return $M.q(q(a-c)+q(b-d))}}

////////////////////////////////////////////////////////////////////////

















o.pp=makeDot=function(X,Y){
    o.dc(x,X,Y);
    Dots.push({x:X,y:Y})}//sy(c,'white','black',3);


o.pp=function(a,b){return o.x.isPointInPath(a,b)}

o.makeDot2=function(x,y){this.dc(x,y);$P.push({x:x,y:y})}//sy(c,'white','black',3);
o.clPth = function(c,p){
    var x=Xx(c),
        p1=p.shift();
    x.moveTo(p1.x, p1.y);
    _e(p,function(p){
        x.lineTo(p.x, p.y) });
    x.closePath();  p=[]}   //x.fill()?
o.cut=function(){return o.X().clPath().copy().paste().Im() }



ppa=makeDot=function(X,Y){dc(x,X,Y)
    Dots.push({x:X, y:Y} )}//sy(c,'white','black',3);

cut=function(){
    x('m', p1.x, p1.y)
    _e(p,
        function(p){
            x('l',p.x, p.y)})
    x('c')
    p=[] //o('f')?

    return X().clPath().copy().paste().Im() }


clPth=function(c,p){var x=xx(c),p1=p.shift()}
clp=function(a){a.clip();return a}
