$O={a:Array,b:Boolean,d:Date,e:Error,
     f:Function,i:Infinity, j:JSON,
     m:Math,n:Number,o:Object,r:RegExp, s:String}

$O.a.c=$O.a.concat

O=function(a,b){
    if(U(b)){
        if(_.isObject(a)){return gC(a)} // if its an ob, pass back its constructor. all and only obs have them, and they are always truthy
        return O(b)?
            $a(_.extend, arguments)
            :false}}
O= _.defaults(O,$O)
eh= {
 qe:function(a){
    return ( E(a) || Q(a) )? $(a): a}
}





G=function(a,p,n){
    //if(U(b)){  // is it arguments obj?  if so pass it back suped up!.. better yet.. just sup it up!!  no need use its return val within functions?
    //if( _.isArguments(a) ){
//if(b==='j'){return gJ(a,b,c)}

    a=_.toArray(a)
    if(_l(a) === '+') p=a.pop()
    if(_l(a) === '-') n=a.pop()
    return {z: a.length,
        f: _f(a), l: _l(a),
        r: _r(a), i: _i(a),
        p: p, P:!p, n:n, N:!n}}




$g=function g(a){
    return G(a)? M(tA(a), g) : a }

cc= function(a){a=tA(a)
    var g=G(arguments), c=O.a.c
    return $a(c, g.r, tA(a) )}
cc.c=function(){return cc(M(arguments,tA))}


A=function(a,b){if(U(b)){
    return G(a)? G(a): _.isArray(a)?tA(a): false}}

_a=function(a,b,c){
    var p=function(a,b,c){
        return a.apply(b,c)}
    return p(a,c||a,b)}

$a=function(m,gA,o){var g=G(arguments)
    return S(m)?  a1(m,gA,o)
        : a0(m,gA,o ) || G(m) || m}
$a.f=function f(a, b,c){var g=G(arguments)
    return A(b)? _a(a,b, c):                                    //met-fn, [pam,pam..], [ctx||met-fn]
        f(a, _r(g))}               //what if ags are not IN an arr..?
$a.a=function(a,b,c){return S(b)? aS(b,c,a):aF(b,a,c) }
$a.s=function(a,b){var g=G(arguments)  // for dynamic method calling!!// you can pass it a string and the obj//met-key@, met-ob, pam,pam...  (applied to met-ob)
    return  _a(b[a], _r(g,2),b)}

T.a= tA =function(a,b){
    return !U(b)? G(arguments)
        :L(a)? _.toArray(a)
        :[a]}

to={}
is={}












atr=function l(q,b,c){if(U(q)){return};

    q= eh.qe(q)

    if( U(b) ){
        return S(q)?
            function(x,y){
                if(!U(x)){ return l(x,q,y) }}
            :_p(l,q)

    }


    if(O(b)){
        _e(b, function(v,k){
            l(q,k,v)}); return q}


    return U(c)?
        q.attr(b)
        :q.attr(b, c)}


aT=function(a,b,c){
    b=b||"body";if(ok(c)){a=$(a);b=$(b)} return $(a).appendTo(b)}

ap=aP=function(a,b){  return a.append(b)  }

co=function(a,b,c){ var s=css(a)
    if(U(b)){
        return {c:s('c'),C:s('C')}}
    s('C', b)
    if(!U(c)) {  s('c', c) }
    return a}



$b=bo=bd=function bo(a,b){

    var s=css($("body"))
    if(U(a)){return $("body")}
    if(S(a)){return co( bo(), a,b)}//if(S(a)){s('C',a)}
    if(F(a)){a=a()}
    if(N(a)){fo(a)}
    if(O(a)){a=$(a)}
    bo().html($(a))

    return a}


def=function(d,sP){return _D(d=d||{}, oO((sP||'')+'D'))}//dst,srcPre
dim=function(a,w,h){
    a=$(a)
    a[0].width=w
    a[0].height=h||w
    return a}

B=b$=b=_b=function(a,b,c){
    return U(a)?false
        :U(b)?_.isBoolean(a)
        :$a(b,F(a)?_.bind:_.bindAll)
}
oB=function(a){return $(a?a:$b())}


C=function(a){
    var tD=function (a){a=Ee(a)                 ///////
        if(a.toDataURL){
            return a.toDataURL()};
        if(F(a.du)){return a.du()};
        return a}
    return h$(a,"Canvas")?  $u(a) :false}
_C = _.compact;

D=function D(a,b,c){//=_D  d is defined so its single can be f that is guaranteed to return something truthy.
    if(B(a)&&F(b)){      if(a){b(a,b,c,D)}  else{if(c){c(a,c,b,D)}}  return a}
    return  U(a)? false
        :   O(a) && F(b) ? function(a,b){return a.dblclick(b)}
        :   S(a) || O(a) ? new Image()
        :   $a( _.defaults, arguments)
}
u$ = src = function f(e){var s=function(a){return pre(ext(a),'/') } //s/c/C/i/b->s sync
    e=e||'guy'
    if(Q(e)){e=e[0]}
    if(e.image){e=e.image}
    if(e.canvas){e=e.canvas}
    if(I(e)){e=e.src}
    if(C(e)){e=e.toDataURL()}
    return D(e)?e:S(e)?s(e):false}
eE  =tE =function(a){if(a.canvas){return a.canvas};
    return $(a)[0]}

$f=fo=function rc(a){
    var F, W, S, Z, f='fantasy', n='normal',
        p=function(a){return a+'px'},
        z=function(a){ a=pj(a); // $p/

            // add optional lineheight value

            return p(a[0])+((a[1])?'/'+p(a[1]):'')};

    _e(pS(a),
        function(p){
            if(  V( p[0] )  ){  Z = z(p)  }    //if 'could be a num' (V could be roman num!)

            F=F|| Oo('ff', p )
            W=W|| Oo('fw', p )
            S=S|| Oo('fs', p )})

    return $l(

        [  W ||'800',  S ||'oblique',

            Z || 50+'px', F ||'fantasy'   ].join(' ') )}//fF="100px sans-serif"
fo=function(a,b){ css(oB(b), {fz: a||50} )}
F=_F=function(a,b,c){
    if (U(b)){if(_.isFunction(a)){return gP(a)}}
    return  _.filter(a,b,c)}   //function(a){if( _.isFunction(a)) {return a.prototype||true } }
_F = _.flatten


$h=em=function em(t, b, d,e){
    if(N(b)){
        return em(t,{C:'p',c:0},b, d)}
    if(S(b)){
        return em(t,{C:b},d,e)}

    t=tag(oT(t))

    if(b){
        css(t,b)}
    if(d){
        dim(t,d,e)}

    if(!ne(arguments)){pT(t)}

    ok(   )

    return t}
$i = im=function f(a,b){

    var i=Im()
    if(U(a)){return i}

    if( rd(a) ){if(F(b)){b(a)}
        if (S(b)){$w[b]=a}
        return a}



    if(U(b)){if(F(a)){return i.r(a)} return i.s(a)}
    if(F(b)){return i.r(b).s(a)}
    if(S(b)){return i.r(function(i){$w[b]=i}).s(a)}
    return i
}

gC=function(a){return a.constructor}
gP=function(a){var p=function(a){return a.prototype}
    return p(a)?p(a):p( gC(a) )}








H=function(a,b){
    h$= _h=c$=_c=has=function(a,b){
        var c=function(a,b){return a.contains(b)}
        return !S(a)? c(a,b):
            O(b)?_.has(b,a):
                c(s$(a),b)}




    if(U(b)){return _.isEmpty(a)}
    return h$(a,b)
}
__i=function(a){return sW(a,'data:')}
I=function(a,b,c){

    //can something be an image and if so return its data-url or a string
    return U(b)? H(a,"Image")
       :a=='u'? s$(b).isUpper()
        :F(b)? _.indexBy(a,b,c)
        : _.indexOf(a,b,c)}

Im=function(s){
    var i= new Image()

    i.s=function(a){
        if(U(a)){return i.src}
        i.src=src(a)
        return i}

    i.r=function(a){
        $(i).load( function(e){a(e.target)})
        return i}
    //  i.r(function(im){i.w=im.width;i.h=im.height})

    // if(!U(s)){i.s(s)}

    return i}

E=function(a,b,c){
    _e = _.each
    eW  =function f(a,b){return l$(a, _z(b))==b}
    return S(a)?eW(a,b)
        :F(b)?_.each(a,b,c)
        :_.isElement(a)}
eR =function(a,b){return s$(a).ensureRight(b).s}
ext=function(a,b){return(h$(a,'.'))?a: eR(a, b||'.png')}


_f  =  function(a,b,c){
    //if(F(b)){return _.find(a,b,c)}
    return _.first(a, b) }


_i=function(a,b,c){//_I=inv=
   // return O(a)? _.invert(a):
        return _.initial(a,b)}

jS  =function(a){return JSON.stringify(a)}
gJ =function(a,b,c){return $.getJSON(a,b,c)}
J=function(a,b){if(U(b)){return H(a,"Sprite")}
    return gJ}
K=_K=_k=keep=function(a,b,c){
    return U(b)?_.isNull(a)
    :F(b)? a.click(b)
    :N(a)? setInterval(a,b*1000)
:false};keys=function(a, b){if(O(a)){return _.keys(a)} }
L=function l(a,b,c){return (O(a)||A(a))?_.pairs(a):false}


_l=_li=iL=function(a,b,c){
  //  if(a=='?'){return  s$(b).isLower()}
   // if(S(a) && S(b)){if(c < 0){c+= _z(a)}
     //   return a.lastIndexOf(b,c)}
 return _.last(a,b)}


$l=function f(a){
    $lg =function(a){cL(tS(a));return a}
    cL=function(a){console.log(a);return a}
    if(U(a)){return f($b())}
    var ag=arguments
    _e(ag,function(a){
        if(E(a)||Q(a)){f($(a)[0].outerHTML ); return a}
        if(O(a)||A(a)){console.log(JSON.stringify(a))}
        else{console.log( (a).toString() )}})
    return _l(ag)}



M=_m=map=function(a,b,c){
    F(b)? _.map(a,b,c): !_.isNan(a)}
$m=met=function f(i,x,m,ag){

    if(U(i)){return}

    if(U(x)){
        return _p(f,i)
    }

    if(A(ag)){return $a(x[oO(i,m)], ag, x)}

    return $a(f, [i,x,m,_r(arguments,3)])}

N=_.isNumber
iO =_.isObject;

P=_p=function(a,b){
   if (U(b)){
       return O(a)&&!Q(a)&&!E(a)? gP(a): false}
          return  F(a)? _.partial(a):  false}
$p=pop=function f(i,e,p,v){
    var kv = function(i,p,v){return {k:oO(i,p),v:oO(p,v,'R')}}
    if(U(p)){return _p(f,i,e)}
    if(O(p)){_e(p,function(v,k){f(i,e,k,v)});return e}
    if(U(v)){return e[oO(i,p)]}
    if(v=="*"){return f(i, e, p, ran(p))}
    var o=kv(i,p,v); e[o.k]=o.v
    return e}
$$p=function(p){
     if(U(p)){p=''}
    return function(a){
        if(U(a)){return []};
        if(A(a)){return a.join(p)}
        return _C($S(a).split(p))}}
pre=function(a,b){return sW(a,b)?a:b+a}
pT=pp=function(a,b,c){
    b=b||"body";
    if(!ne(c)){
        a=$(a);b=$(b)};return $(a).prependTo(b)}; pI=parseInt;


pro=function pro(q,b,c){
    if(U(q)){return};q=qe(q)


    if(U(b)){

        if(S(q)){
            return function(x,y){
                if(!U(y)){return pro(x,q,y)}
                return pro(x,q)}}

        return function(x,y){
            if(!U(y)){return pro(q,x,y)}
            return pro(q,x)} }




    if(O(b)){_e(b,function(v,k){
        pro(q,k,v)});return q}
    b=PRO[b]?PRO[b]:b
    return U(c)? q.prop(b): q.prop(b,c)}


Q=function(a){return !!E(a[0])}




R=function(a,b,c){
    return U(b)? _.isRegExp(a)
        :N(a)? _.range(a,b,c)
        :S(b)? a.replace(b,c||'')
        :U(c)? function(c){return R(c,a,b)}
        :F(b)?_.reduce(a,b,c)
        :_.reduceRight(a,c,b)}

_r=function(a,b,c,d){
    if(N(a)){
        return _.random(a,b,c)}
    return _.rest(a,b)

}



S=sW = function(a,b){
    return U(a)? false
        :U(b)? _.isString(a)
        :function(a,b){return s$(a).startsWith(b) }}//sW2  =function f(a,b){return f$(a,_z(b))==b}// *** s$ <- stringy.js  ***
tS=function(a,b){return a.toString(b)}
_sl   =inverseSlice=function(a,b,c){
    return a.slice(0,b).concat(a.slice(c,_z(a)))}
_sh =sh             =function(a){return a.shift()}



_t=function(a,b){return setTimeout(a,b)}
T=function T(a,b){//=tL
        if(a=='l'){return a.toLowerCase()}
    if(a=='u'){return a.toUpperCase()}

    if(U(b)){return _.isDate(a)  }
        return   N(a)? _t(b, a*1000)
                :F(a)&&U(b)?   T(2, a)
                :F(a)&&N(b)?
            _t(a,b):false}
$t=tag=function(a){return $('<'+(a||'')+'>')}



U=function(a){
    if(U(b)){return a===undefined}
    return $a( _.union, arguments) }
V=_v=_V=function(a){if(U(b)){
    if (!M( Number(a) )){return pI(a)}   //can be parsed/cast as num // same as pI?
    if(F(b)){return _.every(a,b||N,c) }
    if(O(a)&& U(b)){return _.values(a) }}}



W=$w=$W=window; _w=_.where;
wh=z$=function f(a,b,c,d){
    a=nm(a)
    var e=eE(a)
    if(C(e)||I(e)){  return {w: eE(a).width, h:eE(a).height}}
    if(O(a)){
        var w=a.w||0, h=b;
        if(U(a.h)){a.h=w}
        return {w:w,h:a.h}}
    return A(a)? $a(f,a):
        N(d)? f((a-c)/2,(b-d)/2) :
            f({w:a,h:b})    }
iWh=function(a){return {w:$($w).get(0).innerWidth(),h:$($w).get(0).innerHeight()} }




X  = function(a){return $h(a,"Context2D")}
tX = gX =xX =_x = $X = clr  = _t =function(a,b,c){
    if(U(a)){return $b().empty()}
    if(N(a)){return _.times(a,b,c)}
    if(O(b)){return $a(_.extend, arguments)}

    if(X(a)){return a}
    if(E(a)||Q(a)){return $(a)[0].getContext('2d') }
    if(ok(arguments)){
        return a}}
$x=ox=function(c){

    if(F(c)){return c}

    var l=function l(a,b){
        var g=tA(arguments)
        if(A(a)){return l.p(a[0])}
        if(O(a)){l.p(a)
            if(!b){return l.x}
            return $a(l.m,_r(g))}
        if(O(a)){l.p(a)
            return l}
        return $a(l.m,g)||l}

    l.x=tX(c);
    l.c=x.canvas;
    l.q=$(l.c)
    l.m=xm(l.x)
    l.p=xp(l.x)
    l.w=l.c.width
    l.h=l.c.height
    return l}
xp=function l(a,b,c){if(U(b)){return _p(l,a)}
    if(O(b)){pop('X', tX(a),b);return l}
    if(S(b)) return pop('X', tX(a), b,c)}
xm=function(a,b,c){var x=met('x');a=tX(a)
    if(U(b)){return _p(x,a)}
    if(U(c)){return _p(x,a,b)}
    return $a(x,arguments)}




$y=sty=function fz(a,b){

    qs=function f(a,b){var o={},
        s=function(o,a,b){o[oO('S',a)] = oO(a,b,'R');return o}
        if(S(a)){s(o,a,b)} else{_e(a,function(v,k){s(o,k,v)})}
        return o}

    var sy=function(a){return "<style type='text/css'>"+a+"</style>"},
        cl =function(a,b){var c=function(a,b){
            return '.'+a+'{'+b||''+'}'}
            return hd(sy( c(a,b) ))},
        rl=function f(a,b){var s='';
            if(O(a)){_e(qs(a), function(v,k){s+=f(k,v)}); return s}
            return a+':'+b+'; '}
    if(O(a)){_e(a,function(v,k){f(k, v)})}
    cl(a,rl(b))}
Y=css=function css(q,b,c){q=$(q)
    if(U(b)){return _p(css,q)}
    if(O(b)){_e(b, function(v,k){
        css(q,k,v)});return q}
    return U(c)? q.css(oO('S',b)):
        q.css(oO('S',b),oO(b,c,'R'))}

$z=siz=function(a,b,c){
    a=qe(a);
    var e=(a)[0]
    if(C(e)){
        var u=e.toDataURL()
        e.width=b;
        e.height=c;
        Im(u,function(i){fit( gX(e), i)})
        return a}

    if(U(b)){return wh(a.width()/40, a.height()/40)}
    var d=wh(_r(arguments))
    a.width(d.w*40); a.height(d.h*40)
    return a}


Z=function Z(a,b,c){
    return N(a)? a==0
        :
        U(b)?_.size(a)
            :
            N(b)?Z(a)==b
                :
                Z(a)==Z(b)}
_Z=$z=zip=_.zip;
zZ=function(a,b,c){
    if (U(b)){return N(a)? $M.ceil(a):_.max(a,b,c)}
    return _.union(arguments)}
Zz=mF=function(a,b,c){
    if (U(b)){return N(a)?$M.floor(a):_.min(a,b,c)}
    return _.intersection(arguments)}





Bo=function(a){if(F(a)){a=a()} return pT($l(a))}

bO=function(a){if(F(a)){a=a()} return aT($l(a))}

lap=function(a){pT($($l(a)));return a }
oT=function(a){return oO('t')(a||'d')}

//Y    = function(a){return _.isNumber(a) && a<0}/////////////////
ko=function(a){return( G(a)? _l(a): a)==="-"}





ok  = function f(a){
    if(I(a)){return a.complete}
    return A( $g(a) )? f( _l(a) ) : a!=="-"}
aok = function f(a){return A( $g(a) )? f( _l(a) ) : a==="+"}

//nah= function f(a){  return A( $g(a) )?  f( _l(a) ) : a!=="+"}
//bT=  beTrue     =function(a){return a[1](a[0])}
//bF=   beFalse   =function(a){return !(a[1](a[0]))}
//_s          =some=_.some;// $cat         =function(){return(_.r(arguments, function(a,b){return a + tS(b)},''))}
//$O.prototype.l=function(){return $l(this)}
//$a=function(a,b){b=b||"this";return a+".apply("+b+",arguments)"}
//load=function(a,b){a.addEventListener('load',b); return a}
//$lc         =function(a,b){if(!a){$lg('nada, bitch'); return false} return $lg(eval($a('$cat')))}
    //all         = _.every
    //ags=function(){return arguments}
//$a('concat', [1], 3,4,4)
//notAll=function(a){return !every(a)}
//$n=none    =function(a){ return !some(a) }

gC=function(a){return a.constructor}
gP=function(a){var p=function(a){return a.prototype}
    return p(a)?p(a):p( gC(a) )}




A=function(a,b){if(U(b)){return G(a)?G(a):_.isArray(a)?tA(a):false}}
__a=function(a,b,c){return a.apply(b,c)},
    _a=function(m,g,o){return pp(m,o||m,g)}
a1=function(a,b){var g=G(arguments)// for dynamic method calling!!// you can pass it a string and the obj//met-key@, met-ob, pam,pam...  (applied to met-ob)
    return  _a( b[a], _r(g, 2), b )}
a0=function a0(a,b,o){var g=G(arguments)
    if(F(a)&&  A(b)&&  !(U(o)||O(o))){return _a(m, b, o)}                                    //met-fn, [pam,pam..], [ctx||met-fn]
    if(!U(b)){return a0(m,_r(g))}}               //what if ags are not IN an arr..?
$a=function rc(m,gA,o){var g=G(arguments)
    return S(m)? a1(m,gA,o):a0(m,gA,o)||G(m)||m}
tA=function(a){return L(a)?_.toArray(a):[a]}

aT=function(a,b,c){b=b||"body";if(ok(c)){a=$(a);b=$(b)} return $(a).appendTo(b)}

ap=aP=function(a,b){  return a.append(b)  }


B=b$=b=_b=function(a,b,c){
    return U(a)?false
        :U(b)?_.isBoolean(a)
        :$a(b,F(a)?_.bind:_.bindAll)
}

oB=function(a){return $(a?a:$b())}


C=function(a){
    var tD=function (a){a=Ee(a)                 ///////
        if(a.toDataURL){
            return a.toDataURL()};
        if(F(a.du)){return a.du()};
        return a}
    return h$(a,"Canvas")?  $u(a) :false}
_C = _.compact;
ccc  =function(){return _cc(map(arguments,tA ))}
cc=  function(a,b,c){return __a( _$A.concat, tA(a), _r(arguments))}
D=function D(a,b,c){//=_D  d is defined so its single can be f that is guaranteed to return something truthy.
    if(B(a)&&F(b)){      if(a){b(a,b,c,D)}  else{if(c){c(a,c,b,D)}}  return a}
    return  U(a)? false
        :   O(a) && F(b) ? function(a,b){return a.dblclick(b)}
        :   S(a) || O(a) ? new Image()
        :   $a( _.defaults, arguments)
}
F=_F=function(a,b,c){
    if (U(b)){if(_.isFunction(a)){return gP(a)}}
    return  _.filter(a,b,c)}   //function(a){if( _.isFunction(a)) {return a.prototype||true } }
_F = _.flatten
ko  = function f(a){ return A( $g(a) )? f( _l(a) )  : a==="-"}
ok  = function f(a){
    if(I(a)){return a.complete}
    return A( $g(a) )? f( _l(a) ) : a!=="-"}
aok = function f(a){return A( $g(a) )? f( _l(a) ) : a==="+"}
G=function(a,b,c){  // is it arguments obj?  if so pass it back suped up!.. better yet.. just sup it up!!  no need use its return val within functions?
    if(U(b)){
        if(_.isArguments(a)){a=tA(a)
            a.z=a.length
            a.f=_f(a)
            a.l=_l(a)
            a.r=_r(a)
            a.i=_i}
        return a}if(b=='j'){return gJ(a,b,c)}
}
$g=function g(a){ if(!G(a)){return a} return _.map( tA(a), g)}
H=function(a,b){
    h$= _h=c$=_c=has=function(a,b){
        var c=function(a,b){return a.contains(b)}
        return !S(a)? c(a,b):
            O(b)?_.has(b,a):
                c(s$(a),b)}




    if(U(b)){return _.isEmpty(a)}
    return h$(a,b)
}
_i=function(a){return sW(a,'data:')}
I=function(a,b,c){

    //can something be an image and if so return its data-url or a string
    return U(b)? H(a,"Image")
        :a=='u'? s$(b).isUpper()
        :F(b)? _.indexBy(a,b,c)
        : _.indexOf(a,b,c)}



E=function(a,b,c){
    _e = _.each
    eW  =function f(a,b){return l$(a, _z(b))==b}
    return S(a)?eW(a,b)
        :F(b)?_.each(a,b,c)
        :_.isElement(a)}
eR =function(a,b){return s$(a).ensureRight(b).s}
ext=function(a,b){return(h$(a,'.'))?a: eR(a, b||'.png')}


_f  =  function(a,b,c){
    if(F(b)){return _.find(a,b,c)}
    return _.first(a,b)}
_i=_I=inv=function(a,b,c){
    return O(a)? _.invert(a):
        _.initial(a,b)}
jS  =function(a){return JSON.stringify(a)}
gJ =function(a,b,c){return $.getJSON(a,b,c)}
J=function(a,b){if(U(b)){return H(a,"Sprite")}
    return gJ}
K=_K=_k=keep=function(a,b,c){
    return U(b)?_.isNull(a)
        :F(b)? a.click(b)
        :N(a)? setInterval(a,b*1000)
        :false};keys=function(a, b){if(O(a)){return _.keys(a)} }
L=function l(a,b,c){return (O(a)||A(a))?_.pairs(a):false}
_l=_li=iL=function(a,b,c){
    if(a=='?'){return  s$(b).isLower()}
    if(S(a) && S(b)){if(c < 0){c+= _z(a)}
        return a.lastIndexOf(b,c)}
    return _.last(a,b)}
$l=function f(a){
    $lg =function(a){cL(tS(a));return a}
    cL=function(a){console.log(a);return a}
    if(U(a)){return f($b())}
    var ag=arguments
    _e(ag,function(a){
        if(E(a)||Q(a)){f($(a)[0].outerHTML ); return a}
        if(O(a)||A(a)){console.log(JSON.stringify(a))}
        else{console.log( (a).toString() )}})
    return _l(ag)}



M=$m=_m=map=function(a,b,c){
    F(b)? _.map(a,b,c): !_.isNan(a)}



N=_.isNumber
iO =_.isObject;
O=function(a,b){if(U(b)){if(_.isObject(a)){return gC(a)} // if its an ob, pass back its constructor. all and only obs have them, and they are always truthy
    return O(b)? $a(_.extend,arguments):false}}



P=_p=function(a,b){
    if (U(b)){
        return O(a)&&!Q(a)&&!E(a)? gP(a): false}
    return  F(a)? _.partial(a):  false}
$$p=function(p){
    if(U(p)){p=''}
    return function(a){
        if(U(a)){return []};
        if(A(a)){return a.join(p)}
        return _C($S(a).split(p))}}
pre=function(a,b){return sW(a,b)?a:b+a}
pT=pp=function(a,b,c){
    b=b||"body";
    if(!ne(c)){
        a=$(a);b=$(b)};return $(a).prependTo(b)}; pI=parseInt;




Q=function(a){return !!E(a[0])}
qe=function(a){return(E(a)||Q(a))?$(a):a}




R=function(a,b,c){
    return U(b)? _.isRegExp(a)
        :N(a)? _.range(a,b,c)
        :S(b)? a.replace(b,c||'')
        :U(c)? function(c){return R(c,a,b)}
        :F(b)?_.reduce(a,b,c)
        :_.reduceRight(a,c,b)}
_r=function(a,b,c,d){
    if(N(a)){return _.random(a,b,c)}
    return _.rest(a,b)}
S=sW = function(a,b){
    return U(a)? false
        :U(b)? _.isString(a)
        :function(a,b){return s$(a).startsWith(b) }}//sW2  =function f(a,b){return f$(a,_z(b))==b}// *** s$ <- stringy.js  ***
tS=function(a,b){return a.toString(b)}
_sl   =inverseSlice=function(a,b,c){
    return a.slice(0,b).concat(a.slice(c,_z(a)))}
_sh =sh             =function(a){return a.shift()}




_t=function(a,b){return setTimeout(a,b)}
T=function T(a,b){//=tL
    if(a=='l'){return a.toLowerCase()}
    if(a=='u'){return a.toUpperCase()}

    if(U(b)){return _.isDate(a)  }
    return   N(a)? _t(b, a*1000)
        :F(a)&&U(b)?   T(2, a)
        :F(a)&&N(b)?
        _t(a,b):false}


U=function(a){
    if(U(b)){return a===undefined}
    return $a( _.union, arguments) }}
V=_v=_V=function(a){if(U(b)){
    if (!M( Number(a) )){return pI(a)}   //can be parsed/cast as num // same as pI?
    if(F(b)){return _.every(a,b||N,c) }
    if(O(a)&& U(b)){return _.values(a) }}}
W=$w=$W=window;_w=_.where;




Z=function Z(a,b,c){
    return N(a)? a==0
        :
        U(b)?_.size(a)
            :
            N(b)?Z(a)==b
                :
                Z(a)==Z(b)}
_Z=$z=zip=_.zip;
zZ=function(a,b,c){
    if (U(b)){return N(a)? $M.ceil(a):_.max(a,b,c)}
    return _.union(arguments)}
Zz=mF=function(a,b,c){
    if (U(b)){return N(a)?$M.floor(a):_.min(a,b,c)}
    return _.intersection(arguments)}






//nah= function f(a){  return A( $g(a) )?  f( _l(a) ) : a!=="+"}
//bT=  beTrue     =function(a){return a[1](a[0])}
//bF=   beFalse   =function(a){return !(a[1](a[0]))}
//_s          =some=_.some;// $cat         =function(){return(_.r(arguments, function(a,b){return a + tS(b)},''))}
//$O.prototype.l=function(){return $l(this)}
//$a=function(a,b){b=b||"this";return a+".apply("+b+",arguments)"}
//load=function(a,b){a.addEventListener('load',b); return a}
//$lc         =function(a,b){if(!a){$lg('nada, bitch'); return false} return $lg(eval($a('$cat')))}
//all         = _.every
//ags=function(){return arguments}
//$a('concat', [1], 3,4,4)
//notAll=function(a){return !every(a)}
//$n=none    =function(a){ return !some(a) }



$g=nm=function(a){if(G(a)){a=tA(a)}
    return a}


$a=function l(a,b,c){var g=$g(arguments),
    p=function(a,b,c){a.apply(b,c)}

    return S(a)? p(b[a],b,_r(g,2)):
        A( b=$g(b))? p(a,c||a,b):
            l(a,_r(g))}

ko  =ne=function f(a){return A( $g(a) )? f( _l(a) )  : a==="-"}
ok=  lD=rD=function f(a){
    function(a){ if(!U(a)){ return  }}
    if(I(a)){return a.complete}
    return A( $g(a) )? f( _l(a) ) : a!=="-"}
ao=aok =pu=function f(a){return A( $g(a) )? f( _l(a) ) : a==="+"}
_n =_o=_rj=not=function(a,b){ var g=arguments
    if(F(a)){return function(b){return !(a(b) ) }}
    if(F(b)){return $a(_.reject,g)   }
    if(A(a)){return $a(_.without,g) }
    if(O(a)){return $a(_.omit,g)}}





//koa =nah = function f(a){return A( $g(a) )? f( _l(a) ) : a!=="+"}





$8    =Infinity


aft          =after    =function f(a,b){return a.slice(a.indexOf(b)+1,_z(a))}//$l(i,A,B)
aI                   =afterInclusive          =function f(a,b){return a.slice(a.indexOf(b),_z(a))}
aL          =afterLast                =function  f(a,b){return a.slice(a.lastIndexOf(b)+1,_z(a))}
aLI             =afterLastInclusive       =function f(a,b){return a.slice(a.lastIndexOf(b),_z(a))}
b4               =before     =function f(a,b){return  a.slice(0,  a.indexOf(b)  )}//$l(i,A,B)
b4i               =beforeInclusive=function f(a,b){return a.slice(0, a.indexOf(b)+_z(b))}
b4l              =beforeLast=function f(a,b){return a.slice(0, a.lastIndexOf(b))}
b4li            =beforeLastInclusive=function f(a,b){return a.slice(0, a.lastIndexOf(b)+_z(b))}
i$                  =function fn(a,b,c){
    var o=arg(arguments);
    if(o("s")){return a.slice(0,_z(a)-1)};
    if(o("sn")){return a.slice(0,_z(a)-b)}
    if(o("sns")){return fn(a,b)==c}
    if(o("ss")){return fn(a,1,b)}}
r$  =function fn(a,b,c){
    var o=arg(arguments);
    if(o("s")){return a.slice(1,_z(a))};
    if(o("s,n")){return a.slice(b,_z(a))}
    if(o("sns")){return fn(a,b)==c};
    if(o("ss")){return fn(a,1,b)}}

//  $sl   sl$



ll(   )




boo   =bl               =bool=function(fac){
    var f =function r(a){if(U(a)){
        return r.a}
        return r}
    f.a=$B(fac);
    f.and=function(fac){  this.a = $B(fac && this.a); return this}
    f.or=function(fac){  this.a = $B(fac || this.a); return this}
    f.nor = function(fac){  this.a = $B(!fac && !this.a); return this}
    f.nand = function(fac){  this.a = $B(!fac || !this.a); return this}
    return f}

bT              =beTrue     =function(a){return a[1](a[0])}
bF               =beFalse   =function(a){return !(a[1](a[0]))}



A              =_.isArray
$A              =Array


aT          =function(a,b,c){
    b=b||"body";
    if(ok(c)){a=$(a);b=$(b)}
    return $(a).appendTo(b)}
ap           =aP=function(a,b){return a.append(b)}


//all         = _.every
ags             =function(){return arguments}



$B              =Boolean
B               =_.isBoolean;


b$ = _b   =_.bind
bA       =_.bindAll



oB=function(a){return $(a?a:$b())}
iO =_.isObject;

f$              =function fn(a, b, c){var o=arg(arguments);
    if(o("s")){return a.slice(0, 1)}
    if(o("sn")){return a.slice(0, b)}
    if(o("sns")){return fn(a,b) == c}
    if(o("ss")){return fn(a, 1, b)}}
l$              =function fn(a,b,c){
    var o=arg(arguments);
    if(o("s")){return a.slice(_z(a)-1,_z(a))};
    if(o("s,n")){return a.slice(b*-1,_z(a))}
    if(o("sns")){return fn(a,b)==c};
    if(o("ss")){return fn(a,1,b)}}







$cat         =function(){return(_.r(arguments,function(a,b){return a+tS(b)},''))}
cc              =function(a){a=$g(a);
    if(!A(a)){a=[a]};
    return a.concat.apply(a, _r(arguments))}



C =function(a){return h$(a,"Canvas")}

_C   =compact=_.compact;


$k= clk  =function(a,b){return a.click(b)}


D=function(a){return sW(a,'data:')}

dbl  =kk           =function(a,b){return a.dblclick(b)}

$D=Date



_D    =defaults=_.defaults;

$E              =Error;

E    =_.isElement

eR=function(a,b){return s$(a).ensureRight(b).s}

_e        =each=_.each;


ext       =function(a,b){return  (h$(a,'.'))?a: eR(a, b||'.png')}
eW        =function f(a,b){return l$(a,_z(b))==b}




$F                =Function;
F                     = _.isFunction;


_f  =fi=  function(a,b,c){
    if(F(b)){return _.find(a,b,c)}
    return _.first(a,b)}


_F  =fl=_.filter=function(a,b,c){
    if(F(b)){return _.filter(a,b,c)}
    return _.flatten(a)}

G=_.isArguments
H=_.isEmpty;


h$= _h=c$=_c=has=function(a,b){
    var c=function(a,b){return a.contains(b)}
    return !S(a)?c(a,b):O(b)?_.has(b,a):c(s$(a),b)}




$I              =Infinity;
I               = function(a){return h$(a,"Image")}
_i              = initial= _.initial;
_I  = _ib= _io    =inv=function(a,b,c){
    if(F(b)){return _.indexBy(a,b,c)}
    if(O(a)){return _.invert(a)}
    if(A(a)){return _.indexOf(a,b,c)}}
io$     =iO$=indexOf=function f(a,b,c){
    if(c < 0){c+=_z(a)}
    return a.indexOf(b,c)};




iU    =function(a,b){if(U(a)){ a=b } return a}



$J    =JSON;
J = function(a){return s$(a).contains(  "Sprite"   )}
jS=function(a){return JSON.stringify(a)}


$j=gJ=tJ=function(a,b,c){
    return $.getJSON(a,b,c)}


K               =  _.isNull
_K= _k = keys= keep  =function(a,b){
    if(N(a)){return setInterval(a,b*1000)}
    if(O(a)){return _.keys(a)} }





L  =function(a){return   O(a)  ||  A(a)  }
_l=_li=iL=function(a,b,c){
    if(a=='?'){return  s$(b).isLower()}
    if(S(a) && S(b)){if(c < 0){c+= _z(a)}
        return a.lastIndexOf(b,c)}
    return _.last(a, b)}
$l =function f(a){
    $lg =function(a){cL(tS(a));return a}
    cL=function(a){console.log(a);return a}
    if(U(a)){return f($b())}
    var ag=arguments
    _e(ag,function(a){
        if(E(a)||Q(a)){f($(a)[0].outerHTML ); return a}
        if(O(a)||A(a)){console.log(JSON.stringify(a))}
        else{console.log( (a).toString() )}})
    return _l(ag)}


$M              =Math;
M               =_.isNaN;
$m= _m =map=     _.map;
mF              =$M.floor;
max             =highest=most=_.max

$N=Number;
N=_.isNumber
$O=Object;
O=function(a){return typeof a ==="object"&&!F(a)&&!A(a)};

P=function(a){
    return O(a)&&!Q(a)&&!E(a)}  //plain?//oButNotQ=nQ=

_p=function(a){var g=tA(arguments),
    pP,pp=_.pairs,_p=_.partial
    return $a(F(a)?_p:pp,g)}


$p =function(p){
    if(U(p)){p=''}
    return function(a){
        if(U(a)){return []};
        if(A(a)){return a.join(p)}
        return _C($S(a).split(p))}}

pre=function(a,b){return sW(a,b)?a:b+a}


pI=parseInt;
Q                   = function(a){return Boolean( E(a[0]))}
$R           = RegExp;
R               =_.isRegExp;
_R =rP=function(a,b,c){
    if(N(a)){return  _.random(a,b,c)}
    return a.replace(b||'#',  c||'')

}
_r =_rd=rag=function(a,b,c,d){
    if(F(b)){return _.reduce(a,b,c,d)}
    if(N(a)){return _.range(a,b,c)}
    return _.rest(a,b)}
S               =_.isString // *** s$ <- stringy.js  ***
slf             =function(a){return a}
$S=                 String
sW                   =function(a,b){return s$(a).startsWith(b) }//sW2  =function f(a,b){return f$(a,_z(b))==b}

qe =function(a){  return (E(a)||Q(a))? $(a): a}

_sl             =inverseSlice=function(a,b,c){return a.slice(0,b).concat(a.slice(c,_z(a)))}
_s          =some=_.some;
sh              =function(a){return a.shift()}

pT=pp=function(a,b,c){
    b=b||"body";
    if(!ne(c)){
        a=$(a);b=$(b)};return $(a).prependTo(b)}



T=_.isDate;


sT   =function sT(a,b){
    if(U(b)){ return sT(2, a)}
    if(N(b)){ return setTimeout(a,b)}
    return setTimeout(b, a*1000)}




tL=function(a){return a.toLowerCase()}

_u=tUp  =_U=iUp=function(a,b){
    if(a=='?'){return s$(b).isUpper()
        if(S(a)){return a.toUpperCase()}
        return $a( _.union, arguments)}

    $u= u$ = tD  = function (a){a=Ee(a)                 ///////
        if(a.toDataURL){return a.toDataURL()};
        if(F(a.du)){return a.du()};
        return a}


    tA                  = _.toArray;
    tS              =function(a,b){return a.toString(b)}

    U                   =function(a){ return a===undefined }




    V =function(a){return !M(Number(a))}//can be parsed/cast as num
    _v=_V=every=all=function(a,b,c){
        if( F(b) ){return _.every(a,b,c) }
        if( O(a) && U(b) ){ return _.values(a) } }
    ev=vN =function(a,b){return _v(a,b||N)}


    $w                  =$W=window
    W                   = _.isObject////////////////////
    _w =  wH                =_.where;



    X  = function(a){return $h(a,"Context2D")}



    tX = gX =xX =_x = $X = clr  = _t =function(a,b,c){
        if(U(a)){return $b().empty()}
        if(N(a)){return _.times(a,b,c)}
        if(O(b)){return $a(_.extend, arguments)}

        if(X(a)){return a}
        if(E(a)||Q(a)){return $(a)[0].getContext('2d') }
        if(ok(arguments)){
            return a}}







    Y    = function(a){return _.isNumber(a) && a<0}/////////////////


    // if(Z(4,b)){  }}


    Z               =function(a){return a===0}
    _z              = size = _.size
    z1              =function(a){return _z(a)===1}
    Zz              =function(a){return _z(a)-1}
    zZ              =function(a){return _z(a)+1}
    _Z              = zip =  _.zip
    $Z= _.max
    $z= _.min


    pS                      =$p(' ');
    pj                      =$p('/');
    p$                      =$p('|');
    p0                      =$p();
    p_                      =$p('_')








    $O.prototype.l=function(){return $l(this)}
//$a=function(a,b){b=b||"this";return a+".apply("+b+",arguments)"}
//load=function(a,b){a.addEventListener('load',b); return a}

    $lc         =function(a,b){
        if(!a){$lg('nada, bitch');
            return false} return $lg(eval($a('$cat')))}


//notAll=function(a){return !every(a)}
//$n=none    =function(a){ return !some(a) }
