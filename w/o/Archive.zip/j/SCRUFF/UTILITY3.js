X=function c(a){
    if(a.canvas){return a}
    var e=$(a)[0]
    if (e['getContext'])
        return e.getContext('2d')}
cv=function(a){var c= $('<'+ oO('t','c') +'>')
    $s(c,{C:'b'})
     tT(c)
     c.x=X(c)
     return c}
cm=function(x,b,c){var x=X(x)
     x[oO('X',b)] = oO(b,'X','R')
     cL(x[oO('X', b)])}
sVO=function(s,t,S){
    _e(S, function(v,k){
        s(t,k,v)});return t}
sVOi=function(s, I,t,S){
    _e(S,
        function(v,k){
        s(I,t,k,v)})
      return t}
set=function s(a,b,c,d){

    var svo=function(a,b,c,d){//s=setter,I=index,t=thing,S=settings
        return d?
            sVOi(a,b,c,d):
            sVO(a,b,c)}

    if(U(c)){
        return function(m,v){
            return s(m,v,a(b,v))}}

    if(O(b)){
        return svo(a,b,c,d)}

    a[b]=c;

    return a}
$kv=function(i,e,p,v){
    var _kv=function(i,p,v){
        return {k: oO(i,p),
            v:oO(p,v,'R')}}
    var o=_kv(i,p,v)
    return set(e, o.k, o.v)}
$s=function s(a,b,c){
   var css=function(a,b,c){
        var _css=function(a,b,c){
            return c? a.css(b,c): a.css(b)}
        return c? _css(a, oS(b), $o(b, c, 'R') ):
            _css(a, oS(b) )}
   var q=$(a)
   return  U(b)?  _p(s,q)

          :A(b)?  _r(b, set(s,a), {})

       :O(b)?  set(s,q,b)
          :       css(q,b,c)}
bC=function bc(a, b){return b? $s(a,'C',b):bc('body',a)}
$t=tag=function(a){return $('<'+( oO('t',a||'d') )+'>')}
can =function(a,b,c){var g=G(arguments)
    var can = bC($t('c'), a)
    return g.N? tT(can): can}
gE=function(a){
    return $(oO('t',
        a||'d'))}
get=function(a,b){
    return $($(a).get(b))}
cans=function(a){var g=G(arguments)
    if(g.N){_e(['b','y','g'],function(c){can(c)})}
    return !g.z?  gE('c')
    :get(gE('c'), a)}
///////////
$r=ran=function(a,b){

    var r=function(a){
        return _r(_z( V(oO(a||'c'))))}

    a=a||'c';

    return Oo(a,b)|| V(oO(a))[r(a)]}
$m=met=function f(i, x,m,ag){
    if (D(i)) {
        return (U(x)? _p(f,i)
            :U(m)? _p(f,i,x)
            :A(ag)? $a( x[oO(i,m)], ag,  x)
            :$a(f,[i, x, m, _r(arguments,3)]))||x}}
//$m('x', x, 'fr',[0,0,100,100])
$p=pop=function f(i,e,p,v) {
    return    !p? _p(f,i,e)        //partial
        :O(p)?    set(f,i,e,p)     //set via obj of many pops
        :v=="*"?  f(i,e,p, $r(p))  // set it randomly?!
        :U(v)?    e[oO(i,p)]       // just get value
        :         $kv(i,e,p,v)}

xp=function l(a,b,c){
    if(U(b)){return _p(l,a)}

    if(O(b)){
        pop('X', a, b);
        return l}

    if(S(b)) {return pop('X', X(a), b,c)}}

//$p(X, x,{fs:'y'})

xm2=function(a,b,c){
    var x=met('x', X(a))
    if(U(b)){return _p(x, a)}
    if(U(c)){return _p(x, a,b)}
    return $a(x, arguments)}
xm=function(a,b,c){
    var x=met('x', X(a))
    return x
    //return $a(x,arguments)
}
xSet=function s(a, b, c){
    if(!b){return _p(s,a)}
    if(O(b)){ _e(b,function(v,k){ s(a,k,v) })}
    a[ oO('X',b) ]= oO(b,c ,'R')
    return a}
ox=function(c){
    //if(F(c)){return c}

    var l=function l(a,b){
        var g=G(arguments)
        if(A(a)){return l.p(a[0]) }
        if(O(a)){l.p(a);
            if(!b){return l.x}
            return $a(l.m,_r(g))}
        if(O(a)){l.p(a); return l}
        return $a(l.m,g)||l}

    l.x=X(c);
    l.c=x.canvas;
    l.q=$(l.c)
    l.m=xm(l.x)
    l.p=xp(l.x)
    l.w=l.c.width
    l.h=l.c.height

    return l}
xx=function(c){var x

    //if(F(c)){return c}
    if (!(x = X(c))  ) {return}

    var l=function l(a,b){var g=G(arguments)

        if(A(a)){return l.p( a[0] )}

        if(O(a)){
            l.p(a);
            if(!b){return l.x}
            return _a(l.m, _r(g))}

        if(O(a)){l.p(a);return l}

        return $a(l.m, g)|| l}

     l.x=x
     l.c=l.x.canvas
     l.q=$(l.c)
     l.m=xm(l.x)
     l.p=xpop(l.x)
     l.w=l.c.width
     l.h=l.c.height
    return l}
xpop=function xp(x,a,b){
        x=X(x)

        if(!a){
            return _p(xp, x)}

        if(O(a)) {
            _e(a,
                function(v,k){
                    xp(x,v,k)})
        return x}

        x[oO('X',a)]= oO('fs',b,'R')

        return x}





 $(function(){c=cans(1)
     x=X(c)
     o=xx(c)

 })


