





me=function(a){a=gX(a)
    var i
    $(i=_i()).load(
        function(e){var i= _g(e)
            a.drawImage(i,0,0) })
    i.src='/me.png'}
//id=function(a){return (U(a))?'':"id='"+a+"'" }
rad=function(){
    _e(['r','c','b','i',
        'R','t','p','s','f'] ,
        function(v, k){

            bR(2)

            var i=inp(v)

            val(i,v)
            chk(i,true)
            siz(i,3)
            $w[v]=i})}
//chkd=function(a, b){return U(b)? a.prop('checked') : a.prop('checked', b)}


cans=function(a){var g=G(arguments)
    if(g.N){_e(['b','y','g'],function(c){can(c)})}
    return !g.z?  gE('c')
        :get(gE('c'), a)}

/////
pro=function p(q,b,c){

    if(  q=Ee  ){

        if(U(b)){ return S(q)? pAr(p,q): _p(p,q) }

        _e(b, function(v, k){
            p( q, k, v )})

        return q}

    return q.prop(PRO[b]||b,c)

}
//xem=function(a){return $(tgO(oT(a)))}
t0=function(tag,ct){//tagShortName@, content@||Ob, att@-splat
    var el,
        g=G(arguments),
        head=t1([oO('t')(tag||'d')].concat(_r(g,2)))
    if( S(ct) ){el = $(head+t2(ct)) }
    else{el=$(head+t2()); el.html(ct)}
    return $l(el)}
//return $l(aT(($(t1('t')))))
tagFromObj=function(o){
    tOb=function(a){return O(a)? a:{}}
    Df=function f(a,b){
        if(!U(b)){return f(b)(a)}
        return function(b){
            return _D(tOb(b),tOb(a))}}
    o=Df(o, {t:'d'})
    var tg=o.t, at=o.a, ct=o.c
    return t0( oO('t',o.t),o.a)}
orange=function(){var q= qq(
    {C:'o', w:50, h:50,p:20,m:20} );
    q._( 'o');
    q.$(function(e){ e('r') })
    return q}
blue=function(){
    return qq({C:'b', w:50, h:50} )
        ._( 'b').$(function(e){
            e('r')})}
pink2=function(){
    return qq({C:'p',w:700,h:700})._('p').$(function(e){
        e(orange()) ;e(blue())
    })}
imgBox=function f(a){
    var b= qq({C:'p',w:700,h:700});
    b._('p');
    //b.$$(function(e){ e(qq(  {C:'y', w: e.w()/2, h:e.h()/2}) )})
    return b}
ig=function(a){
    var i = new Image()
    i.src=src(a||'me')
    p(i)}

opt=function(a){return "<option>"+a+"</option>"}

sel=function(a){var b='';_e(_r(arguments),function(v){b+=opt(v)})
    return $("<select name="+a+">"+b+"</select>")}



tQ = function f(a,b,c){
    if(E(a)){a=$(a)}
    if(Q(a.q)){a=a.q};
    if(Q(a)){return ss(a,b,c)};
    return em(a,b)}

    var o={}


// G944738237LQR

