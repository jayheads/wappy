
xs1=function(c,v,k){var x=X(c)
    return s1('X',x,v,k)}
xs0=function(c){return _p(xs1, c)}
xm=function(a,b,c){
    var x=$m('x',X(a))
    return x}
//return $a(x,arguments)




Srt=function f(s, n){
    if(!U(s)){s=[s]}
    return {
        n:n||'',
        c:s||[],
        a:function(a, b){
            this.c.push(a);
            this[a]=f(b,a)}}}


$n=function(a,b){return Object.create(a,b)}






//Shape=function(){   var t=this;   t.name='shape'; t.toString() = function(){return t.name}}



//TwoDShape=function(){this.name='2D shape'}
//Triangle=function(side,height){ var t=this;  t.name='Triangle';  t.side=side;  t.height=height;   t.getArea=function(){      return t.side * t.height/2}}


//TwoDShape.prototype=new Shape()
//Triangle.prototype=new TwoDShape()


//TwoDShape.prototype.constructor=TwoDShape
//Triangle.prototype.constructor=Triangle



yyy=function(c){eL($b,{bc:Oo('c', c||'pink')  })}
y1=function(a){return bod(oS(a))}
Ymulti=  function f(a,c){
    if(a==="*"){
        $l(c=Oc(c)||R('c'));
        return yy({bc:c},
            $b)}
    if(S(a)){return $b.text(a)}
    if(N(a)){return qQ($b)(oS('fs'),a)}
    $ls( a=oO('c',rand()) ); $b.css(oS('bc'),a)
    $ls(a=oO( 'c', rand()  )); $b.css(oS('c'),a)}
yy=y=function(a){
    if(U(a)){return $("body").empty()}
    a=eL(a)
    qQ($b)('pp',a);
    return a}
yy1=function rc(a,b){
    if(a==='!'){$ls(b=Co(b));rc({C:b},$b)}
    if(U(a)){$b.empty()}// OR: {(b||$b).sty()}
    else{a=eL(a);
        qQ($b)('ap',a)//=bod(a)
    }
    return a}
yyy.y=function(a,b){$b.css(Os(b),Co());return b}
zz=function(a,b){
    b=oC(b)||R('c');
    yy({bc:b},
        a)}

Lauren=function(a){
    $("body").css(
        'backgroundColor',
        oO('c',a)
    )}


q=qQ( z=yy() )
e=eLe(z)
bod( sc = sS({bc:'#',c:'%',w:100,h:100})  )
sc().text( ccc );
qc=qQ(sc)
qb=qQ(sb)
qa=qQ(sa= sS({bc:'y',c:'w',w:600,h:600})    )
bod(sb = sS( eL('c') ) );
sb().text(bodb);
zz=function(){ z({c:'g'}) }
z=yy(); q=qQ( z ); e=eLe( z );
q('t', 'sdfa asfd asfd sadf asdf sadf')
$b.css(oo('s','fs'), 150)
d1=yy({m:10,pd:10,d:Ol(),bc:'y',c:'@',w:300,h:300,y:'ib',d:Ol("b 200 r")})
i=y('g'); i()[0].src="/me.png";
f=function(){Xx(c=y('c'))('d', i(eL), 0, 0,50,50)}

pap=function(a){return  U(a) ?  ' ':' '+a+' '}

kap=function(a,b){
    if(N(b)){s=a+"="+b   }
    if(S(b)){s="style='"+a+":"+b+"'"};
    return pap(s)}
_ca=function(r,w,h){
    var C, s='', fn=function(a,b){return $( em(a,b) ) [0]}
    return fn('c',  kap(bg, ran(r))+ kap("width", w) +kap("height", h))}


ca=function f(a,b,c,d){
    var df={c:null, z:400},
        bg=oO('S','C'),
        C,
        z=df.z,
        o=function(a){return a*100},
        l= df.c,
        z=_ca

    C= U(a)? z(l,z,z)
        :N(a)?          z(l,o(a), o(b||a))
        :a === "<" ?            $_(f(b,c,d))
        :a === ">" ?            _$(f(b,c,d))
        :S(a) && U(b)?          z(a,z,z)
        :S(a) && N(b)?  z(a, o(b), o(c||b)):0
    C.h =oH(C) //.outerHTML;
    C.x =X(C) //.getContext('2d')
    return C}


caa=function(a,b){
    var c= tT(em('c'))
    ss(c, {C:ran()})//siz(c, a||3, b||3)
    return $l(c)}

ranCol=function(a){if(a){
    return Oo('c', a)} else  {return ran()}}


$c=function f(a,b,c,d){

    var mC=function(r,w,h){var C, s='' ,
            f=function(a,b){return $(  $l(  tag(a,b) ) )[0]}
            return (f('c',
                kap(bg, ranCol(r))+
                    kap("width",w)+
                    kap("height",h)))},

        df={c:null, z:4},

        bg=oO('S','C')

    if(U(a)){  C=mC(df.c, df.z*100, df.z*100 )  }
    if(S(a)  &&  U(b)){C=mC(a,df.z*100, df.z*100)}
    if(S(a)  &&  N(b)  &&U   (c)){C=mC(a,b*100, b*100)}
    if(S(a)  &&  N(b)  &&N  (c)){C=mC(a,b*100, c*100)}
    if(N(a)  &&  U(b)){ C=mC(df.c,a*100, a*100)}
    if(N(a)  &&  N(b)){ C=mC(df.c,a*100, b*100)}

    if(a==="<"){C=tT(f(b,c,d))}
    if(a===">"){C=tB(f(b,c,d))}
    C.h=oH(C)
    C.x=X(C)
    return C}

//oT=function(a){return oO('t', a||'d')}
//Ee=function(a){return X(a)? a.canvas : $(a)[0]  }
//app=function(a,b){  return a.append(b)  }
//addTop=Bo=function(a){return pT( $l( fF( a ) ))}
//add=bO=function(a){return aT( $l( fF(a)) )}
//lap=function(a){ pT( $( $l(a) ) ); return a }
//qel=function f(a,b){if(O(a)){ b=a; a='d'} return css(tag(a), def(b))}
//el=function(a,b){return qel(a,b)[0]}
//too=function(a){return b$((A(a)? a: tA(arguments)).join(' '))}
//tgC=function(a){return (a||'')+"</>"}

$p2=function f( i,e, p,v) {

    iep=function(f, i, e, p){
        _e(p, function(v,k){
            f( i, e, k, v) })

        return e }

    if(!p){ return _p(f, i,e) }

    if(O(p)){
        _e(p,
            function(v,k){
                f(i,e,k,v)})
        return e }

    if(U(v)){     return e[oO(i,p)]}
    if(v=="*"){   return f(i, e, p, ran(p))}





    var o = kv(i, p, v)
    return set( e, o.k, o.v )

}
prp =function p(q,b,c){

    if(q=Ee){

        if(U(b)){
            return S(q)?
                pAr(p,q):
                _p(p,q)}

        return O(b)?
            sVO(p,q,b):
            q.prop( PRO[b] || b, c )}}



atr  =function t(q,b,c){
    if(q=Q(q)){
        if(U(b)){
            return S(q)?  pAr(t,q)
                : _p(t,q)}             // two ways for partial ap
        else{
            return O(b)?
                sVO(t,q,b)
                :q.attr(b,c) }}}




ip=function(){return qq( ss('i'))}




//o.a=bind("arc");
$(function(){

    mistressV=vik(cV('<','r',2))

    $l("hi,i'm vik, but you will call me mistressV")

    mistressV.f('o').cir()
    // mistressV.fill('blue');
    //  mistressV.circle()
})


xp=function l(a,b,c){if(U(b)){return _p(l,a)}
    if(O(b)){pop('X', tX(a),b);return l}
    if(S(b)) return pop('X', tX(a), b,c)}

xm=function(a,b,c){var x=$m('x');a=tX(a)
    if(U(b)){return _p(x,a)}
    if(U(c)){return _p(x,a,b)}
    return $a(x,arguments)}

Cv=function(a){ if( _h(a,"Canvas") ){return $u(a) }



    tD=function(a){a=E(a)
        if(a.toDataURL){ return tDU(a)}
        if(F(a.du)){return a.du()}
        return a}

    pX=function(x){

        x= X(x)

        return function f(a,b){
            var p=oO('X',a)
            if(D(b)){x[p]=b;return f}
            return D(a)? x[p]: x}      }


    mX=function(x){x=X(x)

        return function f(a,b){
            var g=G(arguments)
            x[oO('x',g.f].apply(x,g.r)
            return f}}


    cS=function(n,c,r,w,h){
        n=$l("<canvas"+((n)?" id='" +n+ "'":'')+
            ((c)?" class='"+c+"'":'')+
            ((r)?" style='background-color:"+r+"' ":'')+
            ((w)?" width="+w+' ':'')+
            ((h)?" height="+h+' ':'')+
            "></canvas>");return $(n)[0]}

    Cc=function(v,r,f,n,c){
        if(S(v)){ return can(v) }
        v=$V(v||500);
        return $do(

            cS(n,c,r||'purple',v.x,v.y),
            f)}
    fullC=function(v,r,f,n,c){function gC(a){
        return $w[a]=sC(xE(a))};

        function cS(n,c,r,w,h){
            n=lg("<canvas"+((n)?" id='" +n+ "'":'')+
                ((c)?" class='"+c+"'":'')+
                ((r)?" style='background-color:"+r+"' ":'')+
                ((w)?" width="+w+' ':'')+((h)?" height="+h+' ':'')+
                "></canvas>");
            return $(n)[0]};

        if(S(v)){return gC(v)};
        v=$V(v||[960,450]);
        var s=sC(cS(n,c,r||'yellow',v.x,v.y));
        sr(s,f);
        return s}


//aaa='a a a a a a a a a a a a a a a a a a a a aa a a a a a a a a a a a a '
//bodb='b b b b b b b b b b b b b b b b b b b b b b b b b b b b b b b b b b '
//ccc='cc c c c c c c c c c c c c  c c c c c c c c  c  c c c c c c  c c c c c'
//_$ridFle$_=function(){bod.prepend(e$$.apply(this,arguments))}
//qQ.a=qQ.applytoRestArgs=function(a,b,c){ return a.apply(b,rr(c))}
// DEPENDS ON OBJECTS, SPECIFICALY FOR OO
//P = nQ ?
//DEFAULT={width:800,  height:300,  color:'red',backgroundColor:'blue',   padding:20,   margin:20, display:'inline-block', font:'50px fantasy'}
DEPqQ2=function(a){a=a||$b;

    if(F(a)){a=a()}

    return function rc(m){ var a=arguments, g=map( rest(a), Obj), m=oQ(m);
        if(U(m)){return a};
        if(F(m)){return m(a)}
        $l('a.'+m+' -> '+a[1]||''+' '+a[2]||''+' '+a[3]||'');
        a[m].apply(a, g);
        return rc}}




cV_Cute=function(d,r,n){var w,h;
    if(A(d)){w=d[0];h=d[1]}
    else{if(U(d)){w=2}else{w=d}h=w}
    r=co(r)
    return $( $l("<canvas"+((n)?" id='" +n+ "'":'')+
        ((r)?" style='background-color:"+r+"' ":'')+
        ((w)?" width="+w*100+' ':'')+
        ((h)?" height="+h*100+' ':'')+
        "></canvas>"))[0]}
o.clR=bX("clearRect")
o.vik=function(){return vik(can)}


vik=function(can){
    var x = X(can),
        cx=Xx(can),
        y=sexy(can),
        o= function rc(a,b,c,d){

            if(U(a)){
                rc.C.ap()};
            if(S(a)){
                var s;
                rc.s();

                if(U(b)){s=a}

                else{
                    s="rgba("+_jn([a,b,c,d],",")+")"
                }

                rc.y('f',s);
                rc.X.f(0,0,rc.w(), rc.h());
                rc.r()}

            return rc}return o}




xmm=function(x){
    x=tX(x)
    var f=function f(){
        met('x',x,arguments)
        //f.x[oO('x',b)].apply(f.x,_r(arguments));
        return f}

    f.c=$c(a)
    f.x=xX(f.c)

    return f}



ran500Can=function(){
    var c=tT( em('c',{C:$r()}) )
    return canWH(c, 500)}





xmOld=function(x){
    return function f(){
        met('x',x,arguments)               //f.x[oO('x',b)].apply(f.x,_r(arguments));
        return f}}




cv=basicBlueCanWithCtx=function(a){
    var c=$c()
    ss(c,{C:'b'})
    tT(c)
    c.x=X(c)
    return c}





//$m('x',x,'fr',[0,0,100,100])
xm2=CtxMetfunction(a,b,c){
    var x=met('x', X(a))
    if(U(b)){return _p(x, a)}
    if(U(c)){return _p(x, a, b)}
    return $a(x, arguments)}



xpop=function xp(x,a,b){
    x=X(x)

    if(!a){
        return _p(xp, x)}

    if(O(a)) {
        _e(a,
            function(v,k){
                xp(x,v,k)})
        return x}

    x[oO('X',a)]= oO('fs',b,'R')

    return x}




//_$=function(a,b){return qq()('ap',a).q}
//$_=function(a,b){return qq()('pp',a).q}

//bb=function(a){$("body").prepend(a||el()); return a}
//Bo=function(a){return tT($l(fF(a)))}
//bO=function(a){return tB($l(fF(a)))}
//lap=function(a){return tT( $( $l(a) ) ) }
//c1=function(){return $('<canvas>') }









sVO=setViaObj=function(setter, thing, settings){
    _e(settings,
        function(v,k){setter(thing,k, v)})
    return thing}
sVOi=function(setter, index, thing, settings){
    _e(settings,  function(v,k){
        setter(index, thing, k, v)})
    return thing}

_kv=function(i,p,v){return {k: oO(i,p),v: oO(p,v,'R')}}

$kv=function(i,e,p,v){var o=_kv(i,p,v)
    return _s(e, o.k, o.v)}


cssOld=function css(q,b,c){
    cL('css')
    q=$(q)

    if(U(b)){return _p(css,q)}

    if(O(b)){
        _e(b, function(v,k){
            css(q,k,v)});
        return q}

    return U(c)? q.css(oO('S', b)):

        q.css(   oO('S',     b),
            oO(b,   c, 'R')   )}


//sVO=function( f, t, S, i ){ _e(S,  function(v,k){  f(t, k, v, i) }); return t}  //works
//s=_sI('c','b',{}, 'S')
//pp= _sI('C','b',{}, 'S')
//  _sI( 'gc', 'o'  , {} , 'X')->
//    { globalCompositeOperation  :  "source-out" }
//testSVO=sVO(function(t,k,v){t[k+k]=v  }, {}, {c:2, a:'asfd',b:'fsafsad'})
//testSVOi=sVO(function(t, k, v,i){t[ oO(i,k) + oO(i,k)  ]=v  }, {},{d:2, fr:'asfd', f:'fsafsad'}, 'x')
// sOb({}, {c:'b'} ,'S')
// sOb({}, {gc:'o'} ,'X')
// pp('S',{},'c','r')
//   s1('S',{},{C:'b',p:3})


oS=$o('S');oC=$o('c')

sVO =function(t,f,S,i){
    _e(S, function(v,k){  f(t,oO(i,k), oO(k,v,'R') )})
    return t}
svo=function(t,S,i){return sVO(t, __s, S, i)}



set=function s(f,t,S,i){      //s=setter,I=index,t=thing,S=settings

    // if( U(c) ){return function(m,v){return s(m,v,a(b,v))}}

    if( O(b) ){   return svo(a, b,c,d)   }

    a[b]=c;

    return a}


$kv=function(i, e, p,v){
    var _kv=function(i,p,v){
        return {k: oO(i,p),
            v:oO(p,v,'R')}}
    var o=_kv(i,p,v)
    return set(e, o.k, o.v)}


$p=function f(i,e,p,v) {
    return    !p? _p(f,i,e)    //partial
        :O(p)?    sVOi(f,i,e,p)    //set via obj of many pops
        :v=="*"?  f(i,e,p, ran(p))  // set it randomly?!
        :U(v)?    e[oO(i,p)]       // just get value
        :         $kv(i,e,p,v)}




setPropOnCtx=function(x,b,c){var x=X(x)
    x[oO('X',b)] = oO(b, 'X', 'R')
    cL(x[oO('X', b)])}
//$p(X, x,{fs:'y'})


$p=pop=function f(i,e,p,v) {
    return    !p? _p(f,i,e)        //partial
        :O(p)?    set(f,i,e,p)     //set via obj of many pops
        :v=="*"?  f(i,e,p, $r(p))  // set it randomly?!
        :U(v)?    e[oO(i,p)]       // just get value
        :         $kv(i,e,p,v)}



xp=function l(a,b,c){
    if(U(b)){return _p(l,a)}
    if(O(b)){pop('X',a, b); return l}
    if(S(b)){return pop('X', X(a), b,c)}}


xSet=function s(a, b,c){
    a=X(a)
    if(!b){return _p(s,a)}
    if(O(b)){ _e(b,function(v,k){ s(a,k,v) })}
    a[oO('X',b) ]=oO(b,c,'R')
    return a}



//_can=function(){return  $('<'+ oO('t','c') +'>')}

