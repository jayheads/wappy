$D=Date;
$E=Error;
$F=Function;
$I=Infinity;
$A=Array;
$M=Math;
$B=Boolean;
$J=JSON;
$N=Number;
$O=Object;
$S=String;
$R=RegExp


A=function(a,b){ return U(b)? _.isArray(a):0}
B=function(a,b){ return U(b)? _.isBoolean(a):0}
C=function(a){var c=a.canvas||$(a).get(0)
    if(_h('Canvas',c)){return c}}
D=function(a,b,c){return  U(b)? !U(a) :_a(_.defaults,arguments)}
Du=function(a){return _h(a,'data:')}
E=function(a,b,c){
    if(D(b)){return _.every(a,b||N,c)}   
    if(O(a)){var e=$(a)[0];
        if(_.isElement(e)){return e}}}
F=function f(a,b,c){var iF=_.isFunction; 
    return b? _.filter(a,b,c): iF(a)? a.prototype||true:0} 
G=function(a,p,n){
    a= _.toArray(a)
    if( _l(a) === '+' ){p=a.pop()}
    if( _l(a) === '-' ){n=a.pop()}
    return D(a, {
        z: a.length,
        f:_f(a), l:_l(a),
        r:_r(a), i:_i(a),
        p:p, P:!p, n:n, N:!n })}
I=function(a){var i= $(a).get(0); if(_h('Image',i)){return i}}
K=function(a,b,c){ return N(a)? sI(a, b*1000): _.keys(a) }     
Lc=function(a ){ return  s$(a).isLower()}    
N=_.isNumber
Nn=_.isNan
O=function(a,b){return U(b)? _.isObject(a): $a(_.extend, arguments)}
Q=function(a){if(O(a)){a=$(a); if(E(a[0])){return a}}}  
R=function(a,b,c){return U(b)? _.isRegExp(a): N(a)? _.range(a,b,c):0}
S=function(a,b,c){return U(b)? _.isString(a) : _.some(a,b||F,c)}    
U=function u(a,b){
        var iU=_.isUndefined;
        return iU(b)? iU(a)
            :_a(_.extend,arguments)}
V=_.values
W=$w=window
X=function c(a){
    if(a.canvas){return a}
    var e=$(a)[0]
    if (e['getContext'])
        return e.getContext('2d')}

_a=function(a,b,c){return a.apply(c||a, b)}
_b =function(a,b,c){return  F(a)? _.bind(a,b,c):  _.bindAll(a,b,c)}
_c=function(a,b){return  }
_e=_.each
_f=function(a,b,c){return F(b)? _.find(a,b,c): _.first(a,b)}

_h=function h(a, b){
    if(U(b)){return a.height }  //|| a.h
    if(N(b)){return _s(a,'height',b)}
    if(A(a)){return _.contains(a,b) }
    if(O(b)){return h(_S(b),a)}
    if(S(a)){return s$(a).contains(b)}
    if(O(a)){return a.has(b)}}

_i=_.initial

_l= function(a,b){return F(b)? $(a).load(b): _.last(a,b)}


_m=function(a,b,c){return U(b)? _.min(a): _.map(a,b,c) }
_p=_.partial

_r=function r(a,b,c,d){
    return  (F(b) && D(c))? _.reduce(a, b, c)
        :(F(a) && D(c))? _.reduceRight(a, c, b)
        :(F(a) || F(b))? r(c,a,b)
        :N(a)?_.random(a,b,c)
        :_.rest(a,b)}

_s=function(a,b,c){a[b]=c;return a}

_w=function(a,b){
    if(U(b)){return a.width}  //|| a.w
    if(N(b)){return _s(a,'width',b)}}

_z=function z(a,b,c){
    return  U(b)? _.size(a)
        : N(b)? _z(a) == b
        : _z(a)== _z(b)}

_C = _.compact
_F=_.flatten
_I=function(a,b){return U(b)? _.invert(a):_a(_.intersection,arguments)}
_M=_.max
_U=_.union
_W=_.where
_S=tS = function(a){return a.toString()}
_Z=_.zip




eE =function(a){return $(a)[0]||a}
Ee =function(a){return $(a)[0]}
cC=function(a){return X(a)? a.canvas: $(a)[0]  }
iD =function(a){return sW(a,'data:')}
I=function(a,b,c){return U(b)? H(a,"Image"):0}//can something be an image and if so return its data-url or a string
ext=function(a,b){return(_h(a,'.'))?a: eR(a, b||'.png')}

Q=function(a){ return !!E(a[0]) }
qQ =function(a){return iEl(a)? $(a): a}
Qq =function(a){return iEl(a)}
Cv=function(a){var tD=function (a){a=Ee(a);
    if(a.toDataURL){ return a.toDataURL()};if(F(a.du)){return a.du()};return a}
    return h$(a,"Canvas")?  $u(a) :false}
tX=function(x){return E(x)? xX(x):x}
J=function(a,b){return U(b)? H(a,"Sprite":gJ}





_p2=pAr=function(f,B){return function(a,c){return f(a,B,c)}}


$a2=function(a,b,c){var g=G(arguments)
    if(F(a)){return a.apply(c||a, b)}
    return  _a(b[a],   _r(g,2),  b)}

//$a('fillRect', x, 0,0,100,100)


$a=function(a,b,c){var g=G(arguments)
    if(!b){return _p($a, a)}

    if(F(a)){return a.apply(c||a, b)}

    return _a(a[b],_r(g,2), a)}




