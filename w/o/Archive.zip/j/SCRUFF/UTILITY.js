Zz=function(a){return _z(a) - 1}
$lh=function(q){$l(q[0].outerHTML);return q}
t$=tt=function(a){return $('<'+a+'>')}
$b=function(){return $("body")}
q0=function(a){if(a){return $(a)[0]}}
eB=function(a){return(a)?a:$b()}  // 'else body'
jg = jT = function(a,b){return(b)?b[a]||a:a}
jr = jTr=trun=justTryToRun =function(a){return F(a)? a(): a}


jrM=Jr=trMp=function(a){return _m(a,jr)}


abc=function(a,b,c){ return a[b].apply(a, jrM(_r(c)))  }

GG = nest = function(a,b,c){if(a&&a[b]){return a[b][c]}}
qq=function(a){
    a=jr(eB(a))
    return function f(b){
        if(U(b)){return a}
        if(F(b)){return b(a)}
        a=abc(a,b,arguments)
        return f}}




_$=ap=function(a,b){eB(b).append(a);return a}
$_=pp=function(a,b){eB(b).prepend(a);return a}
$lh=function(a){$l(a[0].outerHTML);return a}
WEB = {
    tag: {c:"canvas", d:"div", i:"input", s:"span",f:"form",g:"img", b:"button", "1":"h1"},
    color: {
        "*":"Snow",
        "0":"Black",
        "!":"DeepPink" ,
        "'":"GhostWhite",
        "$":"Gold",
        "(":"BlanchedAlmond",
        "+":"CadetBlue",
        ":":"Chartreuse",
        ")":"Chocolate",
        "<":"Coral",
        "//":"DarkSlateBlue",
        "^": "DeepSkyBlue",
        "[":"FireBrick",
        "3":"FloralWhite",
        "?":"DarkOliveGreen",
        "%":"DarkOrchid",
        "~":"DarkSeaGreen",
        ".":"AntiqueWhite",
        ",":"CornflowerBlue",
        "`": "Cornsilk",
        "&":"DarkSlateGray",
        "#":"Thistle",
        "{":"RoyalBlue",
        "}":"Tomato ",
        "-":"SaddleBrown",
        ";":"RosyBrown",
        "=":"DarkGray",
        "@":"WhiteSmoke",
        '"':"MediumSpringGreen ",
        _:"LightSteelBlue",
        "~a":"Aquamarine",
        "`b":"AliceBlue",
        "!v":"BlueViolet",
        "!B":"SlateBlue",
        "!g":"LimeGreen",
        "!b":"MidnightBlue ",
        "!G":"SeaGreen",
        "/":"LavenderBlush",
        "/g":"LightGray",
        _g:"LightGreen",
        _p:"LightPink",
        _s:"LightSalmon",
        _G:"LightSeaGreen",
        "|":"LightSkyBlue",
        _sg:"LightSlateGray",
        _y:"LightYellow",
        _b:"LightBlue",
        _co:"LightCoral",
        _c:"LightCyan",
        "-b":"MediumBlue",
        "-g":"MediumSeaGreen",
        "-s":"MediumSlateBlue ",
        "-o":"MediumOrchid",
        "-p":"MediumPurple ",
        "-t":"MediumTurquoise ",
        "-v":"MediumVioletRed ",
        "~G":"Gainsboro",
        "!t":"DarkTurquoise",
        "`!":"PaleGoldenRod",
        "^b":"SkyBlue",
        "`g":"SpringGreen",
        "`l":"Linen",
        "`c":"MintCream ",
        "`r":"MistyRose ",
        "`s":"SeaShell",
        "/b":"SandyBrown",
        "`G":"PaleGreen ",
        "`t":"PaleTurquoise ",
        "`q":"PaleVioletRed ",
        "db":"DodgerBlue",
        "bw":"BurlyWood",
        "!o":"OliveDrab ",
        "*!" :"NavajoWhite ",
        "!!":"MediumAquaMarine",
        "*b":"PowderBlue",
        "@b":"SteelBlue",
        li:"Lime",
        mg:"Magenta",
        or:"OrangeRed ",
        ir:"IndianRed",
        a:"Aqua",
        "b":"Blue",
        "bg":"Beige",
        "br":"Brown",
        "c": "Cyan",
        "cr": "Crimson",
        "d":"DimGray",
        e:"LemonChiffon",
        f:"ForestGreen",
        g:"Green",
        go:"GoldenRod",
        gr:"gray",
        gy:"GreenYellow",
        h:"HoneyDew",
        i:"Indigo",
        j:"PeachPuff",
        k:"Khaki",
        l:"Lavender",
        m:"Maroon",
        n:"Sienna",
        ol:"OldLace",
        ov:"Olive ",
        o:"Orange ",
        oc:"Orchid ",
        p:"Pink ",
        q:"Bisque",
        r:"Red",
        s:"Silver",
        t:"Turquoise",
        u:"Peru",
        v:"Violet" ,
        w:"Wheat",
        x:"SlateGray",
        y:"Yellow",
        z:"Teal",
        A:"Azure",
        B:"DarkBlue",
        C:"DarkCyan",
        D:"DarkGoldenRod",
        F:"Fuchsia",
        G:"DarkGreen",
        H:"HotPink",
        I:"Ivory",
        J:"Salmon",
        "K":"DarkKhaki",
        L:"LawnGreen",
        "M":"DarkMagenta",
        N:"Navy",
        "O":"DarkOrange",
        P:"Plum ",
        Q:"PapayaWhip ",
        "R":"DarkRed",
        "S":"DarkSalmon",
        T:"Tan",
        U:"Purple",
        V:"DarkViolet",
        W:"White",
        X:"LightGoldenRodYellow",
        Y:"YellowGreen",
        Z:"Moccasin"
    },
    cursor: {
        d:"default",
        p:"pointer",
        m:"move",
        e:"e-resize",
        ne:"ne-resize",
        nw:"nw-resize",
        n:"n-resize",
        se:"se-resize",
        sw:"sw-resize",
        s:"s-resize",
        w:"w-resize",
        t:"text",
        W:"wait",
        h:"help"},
    font: {
        face:{c:"cursive", f:"fantasy", m:"monospace",ss:"sans-serif",s:"serif"},
        style:{"#":"inherit",n:"normal",i:"italic",o:"oblique"},
        width:{n:"normal", "+":"bold", "++":"bolder", "-":"lighter", "*1":100,
            "*2":200, "*3":300,"*4":400, "*5":500, "*6":600, "*7":700,
            "*8":800, "*9":900}},
    css: {
        index:{
            kf:"@keyframes",
            a:"animation",
            an:"animation-name",
            ad:"animation-duration",
            at:"animation-timing-function",
            al:"animation-delay",
            ac:"animation-iteration-count",
            ar:"animation-direction",
            ap:"animation-play-state",
            bg:"background",
            ba:"background-attachment",
            C: "background-color",
            bi:"background-image",
            bp:"background-position",
            br:"background-repeat",
            bl:"background-clip",
            bo:"background-origin",
            bs:"background-size",
            d:"border",
            dc:"border-color",
            ds:"border-style",
            dw:"border-width",
            dt:"border-top",
            dtc:"border-top-color"	,
            dts:"border-top-style",
            dtw:"border-top-width",
            dr:"border-right",
            drc:"border-right-color",
            drs:"border-right-style",
            drw:"border-right-width",
            db:"border-bottom",
            dbc:"border-bottom-color",
            dbs:"border-bottom-style",
            dbw:"border-bottom-width",
            dl:"border-left",
            dlc:"border-left-color",
            dls:"border-left-style",
            dlw:"border-left-width",

            o:"outline",
            oc:"outline-color",
            os:"outline-style",
            ow:"outline-width",
            di:"border-image",
            dio:"border-image-outset",
            dir:"border-image-repeat",
            disl:"border-image-slice",
            dis:"border-image-source",
            diw:"border-image-width",

            xs:"box-shadow",
            vs:"overflow-style",
            vx:"overflow-x",
            vy:"overflow-y",
            rt:"rotation",
            rp:"rotation-point",
            cp:"color-profile",
            op:"opacity",
            ri:"rendering-intent",
            h:"height",
            mh:"max-height",
            nh:"min-height",
            w:"width",
            mw:"max-width",
            nw:"min-width",

            xa:"box-align",
            xd:"box-direction",
            xf:"box-flex",
            xfg:"box-flex-group",
            bxl:"box-lines",
            xog:"box-ordinal-group",
            xo:"box-orient",
            xp:"box-pack",

            f:"font",
            ff:"font-family",
            fz:"font-size",
            fs:"font-style",
            fv:"font-variant",
            fw:"font-weight",
            fc:"@font-face",
            fj:"font-size-adjust",
            fh:"font-stretch",



            ct:"content",
            ci:"counter-increment",
            cr:"counter-reset",
            q:"quotes",
            crp:"crop",
            to:"move-to",
            pp:"page-policy",





            gc:"grid-columns",
            gr:"grid-rows",


            //linebox

            aj:"alignment-adjust",
            ab:"alignment-baseline",
            bh:"baseline-shift",

            dm:"dominant-baseline",
            daj:"drop-initial-after-adjust",
            dal:"drop-initial-after-align",
            dbj:"drop-initial-before-adjust",
            dbl:"drop-initial-before-align",
            dz:"drop-initial-size",
            dv:"drop-initial-value",

            ix:"inline-box-align",
            sk:"line-stacking",
            ss:"line-stacking-shift",
            st:"line-stacking-strategy",
            th:"text-height",
            ls:"list-style",
            li:"list-style-image",
            lp:"list-style-position",
            lt:"list-style-type",
            m:"margin",
            mt:"margin-top",
            mr:"margin-right",
            mb:"margin-bottom",
            ml:"margin-left",

            qd:"marquee-direction",
            qp:"marquee-play-count",
            qs:"marquee-speed",
            mq:"marquee-style",

            pd:"padding",
            pt:"padding-top",
            pr:"padding-right",
            pb:"padding-bottom",
            pl:"padding-left",




//page media
            ft:"fit",
            fp:"ftp",
            e:"image-orientation",
            g:"page",
            s:"size",

//positioning

            b:"bottom",
            cl:"clear",
            clp:"clip",
            cu:"cursor",
            dp:"display",
            fl:"float",
            l:"left",
            of:"overflow",
            r:"right" ,
            t:'top',
            p:'position',
            v:'visibility',
            z:"z-index",


//table
            co:"border-collapse",
            sp:"border-spacing",
            cs:"caption-side",
            ec:"empty-cells",
            ly:"table-layout",

//text
            c:"color",
            n:"direction",



            //hyperlink
            tg:"target",
            tn:"target-name",
            tw:"target-new",
            tp:"target-position",


            lts:"letter-spacing",
            lh:"line-height",
            ta:"text-align",
            td:"text-decoration",
            ti:"text-indent",
            ttf:"text-transform",
            ub:"unicode-bidi",
            va:"vertical-align",
            wh:"white-space",
            wo:"word-spacing",

            hp:"hanging-punctuation",
            pu:"punctuation-trim",
            tal:"text-align-last",
            j:"text-justify",
            tl:"text-outline",
            tv:"text-overflow",
            tsh:"text-shadow",
            twr:"text-wrap",
            wbr:"word-break",
            wwr:"word-wrap",

            //2d/3d
            tf:"transform",
            tfo:"transform-origin",
            ts:"transform-style",
            ps:"perspective",
            po:"perspective-origin",
            bv:"backface-visibility",


//transition
            tr:"transition",
            ty:"transition-property",
            tu:"transition-duration",
            tt:"transition-timing-function",
            te:"transition-delay",

            //user interface
            pe:"appearance",
            xz:"box-sizing",
            ic:"icon",
            ni:"nav-index",
            nl:"nav-left",
            dd:"nav-down",
            nr:"nav-right",
            nu:"nav-up",
            oo:"outline-offset",
            rs:"resize"
        },
        textTransformation:{c:"capitalize",u:"uppercase",l:"lowercase"},
        textStretch:{n:"normal",sc:"semi-condensed",c:"condensed",ec:"extra-condensed",uc:"ultra-condensed",se:"semi-expanded",e:"expanded",  ee:"extra-expanded",ue:"ultra-expanded"},
        textDecoration:{u:"underline", o:"overline", l:"line-through", b:"blink"},
        textAlignment:{l:"left",r:"right",c:"center",j:"justify"},
        textBaseline:{s:'sub',S:'super',t:'top',tt:'text-top',m:'middle',b:'bottom',tb:'text-bottom'},
        display:{
            i:"inline",
            b:"block",
            ib:"inline-block",
            t:"table",
            n:"none",
            '#':"inherit",
            it:"inline-table",
            l:"list-item",
            c:"table-column",
            r:"table-row",
            cg:"table-column-group",
            rg:"table-row-group",
            p:"table-caption",
            h:"table-header-group",
            f:"table-footer-group",
            e:"table-cell"},
        position:{s:"static",  a: "absolute",r:"relative",f:"fixed","#":"inherit"},
        overflow:{v:"visible",h:"hidden",s:"scroll",a:"auto","#":"inherit"},
        outlineStyle:{n:'none',h:'hidden','.':'dotted','-':'dashed',s:'solid',
            d:'double',g:'groove',r:'ridge','>':'inset','<':'outset',
            "#":'inherit'},
        outlineWidth:{'|':'thin','||':'medium','|||':'thick'}
    },
    event: {

        "$": "click", "$$":"dblclick",
        "`":"mouseup", "_":"mousedown",

        "~":"mousemove",
        ">":"mouseenter","<":"mouseleave",
        "^":"mouseover", "!":"mouseout",

        "-":"keydown","+":"keyup","=":"keypress",

        "&":"blur","*":"change",
        "@":"load",".":"ready", "1":"one",
        "{}":"resize","[]":"scroll",
        "?":"select","#":"submit",
        "|":"focus","|-":"focusin","-|":"focusout",
        "%":"hover"
    },
    jquery: {
        a:"after",
        at:"appendTo",
        ap:"append",
        ac:"addClass",
        ar:"removeAttr",
        b:"before",
        cr:"removeClass",
        c:"clone",
        d:"detach",
        e:"empty",
        hc:"hasClass",
        h:"height",
        ia:"insertAfter",
        ib:"insertBefore",
        ih:"innerHeight",
        iw:"innerWidth",
        l:"html",
        n:"position",
        o:"offset",
        op:"offsetParent",
        oh:"outerHeight",
        ow:"outerWidth",
        pp:"prepend",
        p:"prop",
        pt:"prependTo",
        pr:"removeProperty",
        r:"remove",
        ra:"replaceAll",
        rw:"replaceWith",
        s:"css",
        sl:"scrollLeft",
        st:"scrollTop",
        tt:"attr",
        tc:"toggleClass",
        t:"text",
        u:"unwrap",
        v:"val",w:"width",
        wr:"wrap",
        wa:"wrapAll",
        wi:"wrapInner"},
    context: {
        method:{a:"arc",at:"arcTo",z:"bezierCurveTo",
            b:"beginPath",c:"closePath",cr:"clearRect",
            j:"clip",d:"drawImage",f:"fill",fr:"fillRect",ft:"fillText",
            g:"createLinearGradient",gi:"getImageData",i:"createImageData",
            ip:"isPointInPath",is:"isPointInStroke",v:"save",
            l:"lineTo",m:"moveTo",mt:"measureText",pi:"putImageData",
            p:"createPattern",q:"quadraticCurveTo",rg:"createRadialGradient",
            rc:"rect",r:"restore",S:"scale", T:"translate" , R:"rotate",
            s:"stroke",sr:"strokeRect",st:"strokeText",
            t:"transform",tf:"setTransform"},
        index: {// also part of S: tfMk, clPth
            ga:'globalAlpha',   //num
            wb:'shadowBlur',    //num
            wx:'shadowOffsetX',   //num
            wy:'shadowOffsetY' ,  //num
            lw:'lineWidth' ,     //num
            ml:'miterLimit',      //num
            fs:'fillStyle',                //str:col
            ss:'strokeStyle',              //str:col
            wc:'shadowColor',              //str:col
            lc:'lineCap',                  //str    XLineCap
            lj:'lineJoin',                  //str      XLineJoin
            fo:'font',                     //str
            ta:'textAlign',                    //str
            tb:'textBaseline',   //?
            gc:'globalCompositeOperation'  //str (XGlobComp)
        },
        pattern:{x:"repeat-x",y:"repeat-y",z:"no-repeat"},
        globalCompositeOperation:{d:'destination-over',
            da:'destination-atop',
            do:'destination-out',
            di:'destination-in',
            s:'source-over',a:'source-atop',
            o:'source-out', i:'source-in',
            l:'lighter', x:'xor',c:'copy'},
        lineJoin:{r:'round',b:'bevel',m:'miter'},
        lineCap:{r:'round',b:'butt',s:'square'}
    },
    createjs: {

        event:{d:"mousedown",m:"pressmove",u:"pressup",r:"rotation"}}} ; (function(){
    var W = WEB, f=W.font, s=W.css, x=W.context;
    Web = {
        c:W.color,
        e:W.event,
        q:W.jquery,
        f:{
            ff:f.face,
            fs:f.style,
            fw:f.width,
            fh: s.fontStretch},
        s:{
            i:  s.index,
            tt: s.textTransformation,
            td: s.textDecoration,
            ta: s.textAlignment,
            tb: s.textBaseline,
            dp: s.display,
            ps: s.position,
            of: s.overflow,
            os: s.outlineStyle,
            ow: s.outlineWidth
        },
        x:{
            x: x.method,
            i:x.index,
            pt: x.pattern,
            gc: x.globalCompositeOperation,
            lj: x.lineJoin,
            lc: x.lineCap
        },
        t:W.tag,
        cu:W.cursor,
        j:{e:W.createjs.event}}

}()); oo=function(){var w = Web; oo={  t:w.t,  c:w.c,  S:w.s.i, X:w.x.i,  q:w.q,  x:w.x.x,
    f:function(){}, o:function(){},
    ff:w.s.ff,  fs:w.s.fs,  fw:w.s.fw,  fh:w.s.fh, os:w.s.os,  ow:w.s.ow,
    pt:w.x.pt,  gc:w.x.gc,   lj:w.x.lj,  lc:w.x.lc, e:w.e, je:w.j.je,
    tt:w.s.tt,    td:w.s.td,   ta:w.s.ta,  tb:w.s.tb,
    dp:w.s.dp,     ps:w.s.ps,     of:w.s.of,   cu:w.cu,
    R:{ C:'c',   f:'c',   s:'c',   wc:'c'}  }}; oo(); dfOb= {
    width:800, height:300,
    color:'red', backgroundColor:'blue',
    padding:20, margin:20,
    display:'inline-block',
    font:'50px fantasy'};
meta={
    S:{
        c:'color',
        bc:'backgroundColor',
        wc:'shadowColor',
        f:'fillStyle',
        s:'strokeStyle',
        gc:'globalCompositeOperation',
        lj:'lineJoin',
        lc:'lineCap',
        wx: 'shadowOffsetX',
        wy: 'shadowOffsetY',
        wb: 'shadowBlur'

    },

    m:{o:{a:1,b:'test',c:['a','b','c']}},
    d:{
        df:{w:300, h:300, c:'/', C:'!', p:20, m:20,  y:'ib', f:'50px fantasy'},
        df1:{ w:300,h:300,    c:'/', C:'!',   p:20,    m:20, y:'ib',  f:'50px fantasy'},
        df2:{w:300,h:300,c:'/',bc:'!',p:20,m:20}}} // get ready for the magic forrest..
// an oo is a fn-ob that provides dependencies in a simple and awesome way!
// oOo is an abstract class for making oo's, which lets CLIENT determine  the function of the function object made from object oo !!!
oOo=function(o){return _D(o,oo)} // two kinds of oo's : polite, rude
Oo = rude = oOo( function f(a,b){  if(a&&b){ a=fR(a,f); return nest(f,a,b)}})  //oo(a): ' Oo '- returns a match or undefined. it is preferred in most cases (strict, rude)
oO = polite = oOo(function f(a,b){
    if(a){
        a=jT(fR(a,f),f);return(b)?jT(b,a):a}
    return _K(f)})//oo(b):'oO' - gives back input on no-match,  and gives index on U(a) //oO <--- matched-val||ORIG(passed)val
iO  = function(a){return isIn(oO(),a)}
Xx = function(c){var x=xX(c),rG=_r(arguments);
    return function(m){
        return x[Oo('x')[m]].apply(x,rG) }
} // a brilliant function that you pass a canvas  to; it returns a fn that lets u make calls on the ctx by using the abbreviated obj keys
ri =rI=function(a){return _R(Zz(oO(a)))}//=num = ranIndNum
rv =rV=function(a){return tA(oO(a))[ri(a)]}//= retValFromOb
gr =gR=function(a,b){return $l(oO(a)[b]||rv(a))}
co = function(a){return gr('c', a)}// = col
ix = iX = function(a,b,c){ return{ k:oO(a,b), v:oO(b,c) } }//iX2 = function(I,k,v){return{k:oO(I,k),v:oO(k,v)}}
// k:k-safeTried-against-I,  v:v-safeTried-against-k || examples:
// ix(oO('S'))('dp','f')  -> k:'display',  v:'table-footer-group'
// ix(oO('S'))('dp')  --> k:'display',v:{(i:'inline')..}
// ix(oO('S'))('dp','zzz')   -->  'display':'zzz'
// ix('zzz','zzz')  --> 'zzz':'zzz'
// ix(oO('S'))('abc')--> 'abc':'abc'
// ix('zzz','zzz')  --> cool !//gen -> iX
oik=function(a,b,c){return a[oO(oO(b),c )]}
seg=function(o,i,k,v){var d;
    if(U(v)){return oik(o,i,k)}
    d=ix(i,k,v);
    o[d.k]=d.v;
    return o} //ex:  xi(  {hello:4},   {},    'hello'  ) --> 4
// xi(  {a:4},  {h:'hello'},  'h'   )  --> 4
//xi(  {display:3},'S', 'dp' ) -->3
//xi(  {display:3},'S', 'dp',5 )    --> {display:5}
//? xi(ctx,'X',gc, val )
//set/adds properties from a passed-in-ob(pi-Ob), to a pi-jQob
pop=function(a,b,c){
    if(S(b)){return ix(a,b,c)}
    _e(b,function(v,k){seg(c||{},a,k,v)})
    return c}//_oo=function(a,b){if(b){return oO(a,b)||b} return oO(a)||a}
ooO=function(o){return function(a){ return (U(a))? oO(o): oO(o,a)} }
Ooo=function(o){return function(a){ return (U(a))? Oo(o) : Oo(o,a)} }
oC=ooO('c');Co=Ooo('c');oQ=ooO('Q');Qo=Ooo('q');
oX=ooO('X');Xo=Ooo('x');oS=ooO('k');Os=Ooo('k')
eD=function(o){return _D( o||{}, dfOb )}  //=elemDefaults, pass in an ob, and it will add element style defaults
_css=function(a,b,c){var d=ix(c,b); a.css(d.k, d.v)}
dF =function(a,b){_e( _D( b||{}, Oo('D0') ), _css( a, b )  ); return a}
css=function(a,b){
    _e(dF(b), function(v,k){  $(a).css(k,v) });
    return a}
tag = function(a,b){return "<"+oO('t',a||'d')+" "+(b||'')+">"}
qel = function(a){return dF( qq( tag(a) ) )}       //=getFromElseMakeNewEl
tE=function(a,b){a=a||'div'//=toElement
    if(E(a)){return a}
    return (Q(a))? a[0]: css( tt(a),eD(b) )[ 0 ] }
fart =  function(a){return function(v,k){a.css( oS(k)||k , Oo(k,v)||v) }}
fT=function(a){return fart(tag(a))}
eL1=function(a,b){return function f(o){
    if(U(a)){return a}
    _e(dF(a), fT(b)); return f }}
eL2=function f(a,b){var D=oO('D');
    if(Q(b)){
        _e(_D(a||{},D), ix)
        if(O(a= _D(b, D))){_e(a, ix)}
        return b}
    if(U(a)){return f('d',b)}
    b=$(tag(b))}
CSS=function(a,b){
    if(U(b)){return eL(a)[0]}
    if(O(b)){
        a=eL(a)
        _e(b,function(v,k){a.css(Os(k), v)})}
    return $lh(a)}
ssMachine=function(a){
    a=iU(a,eL())
    if(S(a)){a=eL(a)}
    if(P(a)){a=dF(eL(),a)}
    return function f(p,b){
        if(U(p)){return a}
        if(F(p)){return p(a)}
        if(b){var a={p:b}; p=a} else if( S(p) ){return a.css( Os(p) )}
        CsS(p, a)
        return f}}
f$ = fo = font = makeFont = function rc(a){

    var F, W, S, Z, f='fantasy', n='normal',

        p=function(a){return a+'px'},

        z=function(a){a=chop(a);
            return p(a[0])+((a[1])?'/'+p(a[1]):'')};

    _e(pS(a),
        function(p){
            if(V(p[0])){Z=z(p)};
            F=F||Oo('ff',p);
            W=W||Oo('fw',p);
            S=S||Oo('fs',p)})

    return $l([W||n,S||n,Z||p(100),F||f].join(' '))}
can=function(pops, z){


    var nF = notFalse = function(a){return(a!=="false")}

    var p=pops,C='canvas',c;
    if( S(p) ){ p = { backgroundColor:p } }
    c=tE(C,p);
    if(nF(z)){body(c)}
    return c}
cC=function rc(a,b,c,d){

    var mC=function(r,w,h){var C, s='',
            p=function(a){return(U(a))?' ':' '+a+' '},
            cl=function(a){ if(a){return Oo('c',a)} else  {return col()}},
            k=function(a,b){
                if(N(b)){s=a+"="+b};
                if(S(b)){s="style='"+a+":"+b+"'"};
                return p(s)};
            return(function(a,b){

                return $( $l( tAg( a, b ) ) )[0]}(
                    'c',
                    k(bg, cl(r)) + k("width",w) +k ("height",h)

                ))},
        df={c:null,z:4},
        bg=oO('Q','C')

    if(U(a)){
        C=mC(df.c,df.z*100,df.z*100 )}
    if(S(a)&&U(b)){
        C=mC(a,df.z*100,df.z*100)}
    if(S(a)&&N(b)&&U(c)){
        C=mC(a,b*100,b*100)}
    if(S(a)&&N(b)&&N(c)){
        C=mC(a,b*100,c*100)}
    if(N(a)&&U(b)){
        C=mC(df.c,a*100,a*100)}
    if(N(a)&&N(b)){
        C=mC(df.c,a*100,b*100)}
    if(a==="<"){
        C=$_(rc(b,c,d))}
    if(a===">"){
        C=_$(rc(b,c,d))}

    C.h=C.outerHTML;
    C.x=C.getContext('2d')

    return C}
Obj=function(a){

    if(a.obj){return a.obj()};

    return a

}
$(function(){//////////


    g=function(gc){


        $b().empty();
        a = cC('<','w',7)
        x= a.x;
        pop({f:'G', wc:'b', wx:30, wy:30, wb:(gc||0)*5}, x)

        x.fillRect(0,0,400,300)
        pop({wc:'o',f:'p'},x)
        pop({gc:'s'},x);  x.fillRect(50,50,500,200)

    }

    gc={"d":"destination-over","da":"destination-atop","do":"destination-out",
        "di":"destination-in","s":"source-over","a":"source-atop",
        "o":"source-out","i":"source-in","l":"lighter","x":"xor","c":"copy"}

    // s = stateSetter;

    // oo = oO('M','o')

    // o=iX()



    // g= iX('X');//    z=s({},o); $l(z)

    boD=function(a){return qQ($b)('ap',a)}



})






//OO=function(a,b){return Oo(a, b) ||b} //oO?
//sO=function(a,b){return oO('S',a,b)}





arg=function(ag){
    return function(spec, op){

        var pairUp = function(a,b){return filter(map(zip(a,b),compact),function(a){if(_z(a)>1){return true}})},
            hydrate=function(a){return map( p0(a),function(a){if(iUp(a)){return not($w[tUp(a)])}return $w[tUp(a)]})},
            makeTest=function(a,s){return pairUp(a, hydrate(s))},
            ARGS = _z(ag), SPECS = _z(spec),more = ARGS > SPECS,less = ARGS < SPECS,theSame = ARGS == SPECS,
            notLess = ARGS >= SPECS,notMore = ARGS <= SPECS,different=!theSame,nada=ARGS== 0,
            o=function(fl, it){return bool(fl(makeTest(ag, spec), it))},
            OPS={
                pass:        o(all, beTrue).and(theSame)(),
                orLess:       o(all,beTrue).and(notMore)(),
                orMore:        o(all, beTrue).and(notLess)(),
                noFail:       o(all, beTrue)(),
                somePass:       o(some, beTrue)(),
                nonePass:       o(all, beFalse)(),
                someFail:     o(some, beFalse)(),
                fail:          o(some, beFalse).or(different)(),
                antiPass:    o(all, beFalse).and(theSame)(),
                mix:          o(some, beTrue).and( o(some,beFalse)())()}
        if(OPS[op||'pass']){return true}}}
args2=function(ag){return function(spec, op, tD){
    if(!tD){ tD=op; op='pass'}
    var pairUp = function(a,b){return filter(map(zip(a,b),compact),function(a){if(_z(a)>1){return true}})},
        hydrate=function(a){return map(p0(a),function(a){if(iUp(a)){return not($w[tUp(a)])}return $w[tUp(a)]})},
        makeTest=function(a,s){return pairUp(a, hydrate(s))},
        ARGS = _z(ag), SPECS = _z(spec),more = ARGS > SPECS,less = ARGS < SPECS,theSame = ARGS == SPECS,
        notLess = ARGS >= SPECS,notMore = ARGS <= SPECS,different=!theSame,nada=ARGS== 0,
        o=function(fl, it){return bool(fl(makeTest(ag, spec), it))},
        OPS={
            pass:        o(all, beTrue).and(theSame)(),
            orLess:       o(all,beTrue).and(notMore)(),
            orMore:        o(all, beTrue).and(notLess)(),
            noFail:       o(all, beTrue)(),
            somePass:       o(some, beTrue)(),
            nonePass:       o(all, beFalse)(),
            someFail:     o(some, beFalse)(),
            fail:          o(some, beFalse).or(different)(),
            antiPass:    o(all, beFalse).and(theSame)(),
            mix:          o(some, beTrue).and( o(some,beFalse)())()}
    if(OPS[op]){tD()}}}



$f=function f(a){return new $F(
    "a","b","c","d","e","var g=aA(arguments),"+
        "t=this,o={},s='',l=[],z=0;"+ a+";return t")};_U=function(a,b){if(U(a)){$f(b)(a,b)}}



g$="var t=this,"+
    "g= _.toArray(arguments),"+
    "str='', arr=[], obj={}, "+
    "zG=_.size(g), "+
    "fG=_.first(g),"+
    "rG=_.rest(g), "+
    "lG=_.last(g), "+
    "iG=_.initial(g);"
    + "if($w['arg']){var o = arg(g)};";


ii=function fn(f){return function(a,b,c){
    if(!b){return f(a)};
    if(c==='!'){c=b;b=null}
    if(f(a)){if(b){b (a,b,f,fn)}}
    else if(c){c(a,b,f,fn)}}};



oo=function f(h,k {
    if(!h){return _.keys(oo)}
    if(f.M[h]){h=f.M[h]}
    if(!f[h]){return}
    else {h=f[h]};
    if(U(k)){return h};
    if( h[k] ){return h[k]}}



app=function(a,b,c){a.apply(c||this,b)}




apply=function(a){
    return function(){eval(g$);
        return app(fG[a], rG, fG)}}

not = function(a){return function(b){return !(a(b))}};

none=not(some);
notAll=not(every)

doIn =setTimeout;
doEvery =setInterval;
arrayUC =function(){return map(a, _.uc)}

upper =function(a){return a.toUpperCase()}
chop=function(a){return a.join('')}
hop=function(a){return a.split('')}
dif=function(a,b){return a!==b};

cc=apply('concat');


//nO=$f("(a[0])?j(a,''):'='")


// [ [1,2], [0], [3] ] ->  [ [1, 2] ]

squish=function(a){

    return filter( map(a, compact),

        function(a){ return $B(a[1])   } ) ;
}

makePair=function(a,b){return squish(zip(a,b))}



yes=function(a){return a[1](a[0])};

no=not(yes);


//  Qual=function(a,b,c){return  }


yesNo=function(P){
    return function(Q){
        return function(Y){return Q(P, Y) }}}




REL=function(g,q){
    sG=size(g);  sQ=size(q);
    return {
        G:sG, Q:sQ,
        more: sG > sQ,
        less:  sG < sQ,
        same: sG == sQ,
        notLess :sG >= sQ,
        notMore : sG <= sQ}}

someNot=not(every);
none= not(some);




// var numPass,isNum,haveFun,squish,yes,no,qual,pQYn, pass,   ALL, SOME, SOMENOT, NONE, ops,   more,less,same,notLess,  moreOrSame, notMore, lessOrSame,   yn,pair,lil,big,fun,sG,sQ;


numPass=function(Q,args){
    return eval(len(args)+op(butLast(Q))+last(Q));
    function op(a){return(a[0])?chop(a):'='}}

isNum=function(a){return V(last(a))}

haveFun=function(arr){return map(arr, funny);
    function funny(lil){
        big=upper(lil);    fun=$w[big];return(
            (dif ( lil, big ))?  fun  :  not(fun)   )}}


arg=function(G){









    return function(Q, doThis){

        $l(Q)

        Q = Q.split('/');
        $l(Q)

        if(Q[1]){ mop = Q.shift()||'ex' }  //;return op;


        $l(mop);  $l(Q)



        if(isNum(Q)){

            pass = numPass(Q, G)}

        else {

            Q=hop(Q[0]);  Q=haveFun(Q)

            rel=REL(G,Q); pair = makePair(G,Q)

            var o = yesNo (pair);



            ops={

                x: o(every)(yes) && rel.same,

                xf: o(every)(no) && rel.same,

                z: o(some)(no),


                //  one:a,

                //  oneWrong:,

                //  oneMissing:,


                s: o(every)(yes) && rel.notLess,
                m:      o(every)(yes) && rel.more,
                nm: o(every)(yes) && rel.notMore  }


            //return ops



            mop = mop|| 'x';

            pass = ops [mop]
        }



        if( pass ){ $l('p'); doThis() }

        else{ $l( 'f' )}

    }}

z= function(){ eval(g$);

    return o('<3',  function(){alert(3)}  )


}

zz= function(){ eval(g$);

    return o('nnn',  function(){alert(3)}  )


}

$(function(){
    try{
        throw(Error('hi'))
    }

    catch(e){

        z=e;
    }


    oo=function(a){

        var o=this;

        o.a=function(){this.b()}
        o.b=function(){return this.a}

        o.c  =  [1,2,3];

        o.d=function(){return o.c.push(a)} }


})



//// bricks ////



tryToInvoke=function(a){if(F(a)){return a()}return a}

// pass in an ob, and it will add element style defaults
eD=elemDefaults=function(ob){
    var defaultOb= {width:800,height:300,color:'red',
        backgroundColor:'blue',padding:20,margin:20,
        display:'inline-block',font:'50px fantasy'}
    return _D(ob||{},defaultOb)}


//set/adds properties from a passed-in-ob(pi-Ob), to a pi-jQob
css=setCssPops=function(dstOb, srcOb){
    forEachItemIn(srcOb,function(v,k){
        $(dstOb).css(k,v)});
    return dstOb}


body=function(a){$("body").append(a);return a}

//see outerHTML

$lh=logOuterHTML=function(el){$l(tE(el).outerHTML);return el}


// make elements

tE=toElement=function(q, dfOb){q=q||'div';
    if(E(q)){return q}; if(Q(q)){return q[0]}
    return css($('<'+q+'>'), eD(dfOb) )[0]}

can=function(pops, dontDisplay){var p=pops;
    if(S(p)){p={backgroundColor:p}}
    var c =tE('canvas',p); if(dontDisplay!=="false"){body(c)};
    return c}


qq=function(jQ){
    jQ=jQ||$("body"); if(F(jQ)){jQ = jQ()}
    return function fn(met){
        if(U(met)){return jQ};
        if(F(met)){ return met(jQ) }
        var args = map(arguments, tryToInvoke);
        // $l('jQ.'+ met +' -> '+a[1]||''+' '+a[2]||''+' '+a[3]||'');
        jQ[met].apply(jQ, rest(args));
        return fn}}

keep=setInterval;
    wait=setTimeout;
     $pI=parseInt

    _s=function(a,b){return a.split(b||'')}
    _sl=function(a,b,c){return a.slice(b,c)}
    _sp=function(a,b,c){return a.splice(b,c)}
    _ts=function(a){return a.toString()}
    _p=function(a,b,c){if(!b){return a.pop()};return a.push.apply(a,_.rest(arguments))}
    _js=function(a){return $J.stringify(a)}
    _jn=function(a,b){return a.join(b)}
    _ps=function(a){return $J.parse(a)}
    _rp=function(a,b,c){return a.replace(b,c)}
    _tr=function(a){return _r(/\s\s*$/,'',_r(/^\s\s*/,'',a))}
    _mh=function(a,b){return a.match(b)}
    _rv=function(a){return a.reverse()}
    _sh=function(a,b){if(!b){return a.shift()};return a.unshift.apply(a,_.rest(arguments))}
    _cc=function(a){return a.concat.apply(a,_.rs(arguments))}
    _io=function(a,b,c){return a.indexOf(b,c)}
    _lo=function(a,b,c){return a.lastIndexOf(b,c)}
    _ca=function(a,b){return a.charAt(b)}

        is=function(a,b,c){return IS[a](b,c)}
        not=function(a,b,c){return !is(a,b,c)}
        and=function(a,b,c){return _.v(_s(a,','),function(a){return is(a,b,c)})};
        or=function(a,b){return _.s(_s(a,','),function(a){return is(a,b)})};
        nand=function(a,b){return !and(a,b)}
        nor=function(a,b){return !or(a,b)}
        any=function(a,b){return _.s(_s(a,','),function(a){return b==a})}

    $g=ag=function(b){
            return function(a,c){c=c||'e';var s=a.split(','),S=_.z(s),B=_.z(b);
                if(c=='e'){return aE(b)};if(c=='m'){return aM(b)};if(c=='l'){return aL(b)};
                if(c=='n'){return aN(a,b)};if(c=='s'){return aS(a,b)};if(c=='a'){return aA(a,b)};
                function ck(a){return is(a[0],a[1])};

        $a=function(a,b){b=b||"this";return a+".apply("+b+",arguments)"}
        $cat=function(){return(_.r(arguments,function(a,b){return a+tS(b)},''))}
        $lg=function(a){console.log(tS(a));return a}
        $l=function(a,b){
            if(!a){$lg('nada, bitch');return false}
            return $lg(eval($a('$cat')))}
        strings=function(){
            sx$=function(a,b,c){
                return _cc(_sl(a,0,b),
                    _sl(a,c,_.z(a)))}//inverse slice
            f$=function f($,q,r){var A=ag(arguments);if(A("s")){return _sl($,0,1)};if(A("s,n")){return _sl($,0,q)}
                if(A("s,n,s")){return f($,q)==r};if(A("s,s")){return f($,1,q)}}//ex: _f("jason",2,"ja") / true
            l$=function f($,q,r){var A=ag(arguments),z=_.z($);if(A("s")){return _sl($,z-1,z)};if(A("s,n")){return _sl($,q*-1,z)}
                if(A("s,n,s")){return f($,q)==r};if(A("s,s")){return f($,1,q)}}
            r$=function f($,q,r){var A=ag(arguments),z=_.z($);if(A("s")){return _sl($,1,z)};if(A("s,n")){return _sl($,q,z)}
                if(A("s,n,s")){return f($,q)==r};if(A("s,s")){return f($,1,q)}}
            i$=function f($,q,r){var A=ag(arguments),z=_.z($);if(A("s")){return _sl($,0,z-1)};if(A("s,n")){return _sl($,0,z-q)}
                if(A("s,n,s")){return f($,q)==r}if(A("s,s")){return f($,1,q)}}
            sW$=function f($,q){var A=ag(arguments),z=_.z(q);return f$($,z)==q}
            eW$=function f($,q){var A=ag(arguments),z=_.z(q);return l$($,z)==q}
            iO$=io$=function f(a,b,c){if(c<0){c+=_.z(a)}return _io(a,b,c)};
            lO$=lo$=function f(a,b,c){if(c<0){c+=_.z(a)}return _lo(a,b,c)};
            b$=function f(a,b){var i=io$(a,b),A=_.z(a),B=_.z(b);return _sl(a,0,i)}//$l(i,A,B)
            bI$=function f(a,b){
                var i=io$(a,b),
                    A=_.z(a),B=_.z(b);
                return _sl(a,0,i+B)}
            bL$=function f(a,b){var i=lo$(a,b),A=_.z(a),B=_.z(b);return _sl(a,0,i)}
            bLI$=function f(a,b){var i=lo$(a,b),A=_.z(a),B=_.z(b);return _sl(a,0,i+B)}
            a$=function f(a,b){var i=io$(a,b),A=_.z(a),B=_.z(b);return _sl(a,i+1,A)}//$l(i,A,B)
            aI$=function f(a,b){var i=io$(a,b),A=_.z(a),B=_.z(b);return _sl(a,i,A)}
            aL$=function  f(a,b){var i=lo$(a,b),A=_.z(a),B=_.z(b);return _sl(a,i+1,A)}

            aLI$=function f(a,b){
                var i=lo$(a,b),A=_.z(a),B=_.z(b);
                return _sl(a,i,A)}


            c$=function(a,b){return io$(a,b)!==-1}


            p$=function(a,b){return(f$(a,b))?a:b+a}//2

            e$=function(a,b){if(!b){
                return c$(a,'.')?ali$(a,'.'):false};
                if(!e$(a)){a += p$(b,'.')}; return a}



            eR$=function(a){return _rp(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g,"\\$&",a)}
            rg$=function(a,b){return $R(eR$(a),b)}
            rG$=function(a,b){return rg$(a,'g')}}



        $V=function(a,b,c,d){a=a||0;
            if(d){return $V((a-c)/2,(b-d)/2)};
            if(iA(a)){return $V(a[0],a[1])};
            if(iN(a)){return $V({x:a,y:b})}
            return {x:a.x||0, y:not('ud',a.y)?a.y:a.x||0}}

    $do=function(a,b,c,d){
        if(iF(b)){b(a,c,d)};
        if(iS(b)){W[b]=a};
        return a}

    $ev=function(a){
        return function(){eval(a)}}

    $$$=function(a){$(function(){eval(a)})}





saving=function(){

        XH=function(){var x= new XMLHttpRequest()
            x.o=function(a,b){this.open(a,b);return this}
            x.s=function(a,b){this.send(a,b);return this}
            return x}
        FD=function(){ var d= new FormData();
            d.a=function(a,b){this.append(a,b);return this}
            return d}
        ul=function(a,u){XH().o("POST",u).s(a)}
        sv=function(a,u){ul(FD().a("png",a),u||UL)}
        open=function(c){
            $w.open(c.toDataURL(),
                'new_window',
                'width=310,height=30')}
    };saving();



buttons=function(){
ipV=function(a){var p=$('#'+a).parent('div')
    return p.children()[0].value}
buttonClass=function(a){
        var A=ALERTS,Z=SIZES,s='btn';
        if(!a){return s};
        a=a.split('');
        s+=' btn-'+A[a[0]];
        if(a[1]){
            s+=' btn-'+Z[a[1]]};
        return s}
    run=function(n){
        if(iF(W[n])){
            W[n](ipV(n))}}



};buttons();




jq=function(a){return sQ($(a))}
oScr=function(a){$(W).scroll(a)}




                ////
//////
    ////



                $s=function(a){if(O(a)||A(a)){return _.js(a)}; return _.ts(a)}

                //o(['a','o'])(    )




                f$=function fn(a,b,c){eval(g$);var sl=_.sl;
                    o("s    sl(a,0,1)");
                    o("sn   sl(a, 0,b)");
                    o("sns  fn(a,b)==c");
                    o("ss   fn(a, 1,b)")}

                first=$fo({
                    s:"sl(a, 0, 1)", sn:"sl(a, 0, b)",
                    sns:"fn(a,b) == c", ss:"fn(a,1,b)"}) //ex: f$("jason", 2,"ja") / true

                sW$=f1( "first(a, _.z(b))== b")

                l$=function f($,q,r){eval(g$); z=_.z($);var sl= .sl;
                    if(A("s")){  x= sl($, z-1, A, z)}//s(z-1,z);
                    else if(A("s,n")){  x =sl($, q*-1,z)} //s(q*-1,z)
                    else if(A("s,n,s")){ x=f($, q)==r}
                    else if(A("s,s"))  {  x=f($, 1, q)}; return x}
                r$=function f($,q,r){eval(g$); z=_.z($);  var sl= _.sl;
                    if(A("s")){x=sl($, 1,z)}
                    else if(A("s,n")){x=sl($, q,z)}
                    else if(A("s,n,s")){x=f($, q)==r}
                    else if(A("s,s")){x=f($, 1,q)};return x}
                i$=function f($,q,r){eval(g$);  z=Z($);
                    if(A("s")){x= sl($,0,z-1)}
                    else if(A("s,n")){x= sl($,0,z-q)}
                    else if(A("s,n,s")){x= f($,q)==r}
                    else if(A("s,s")){x= f($,1,q)};return x}




                eW$=function f($,q){
                    var A=ag(arguments),
                        z=_.z(q);
                    return l$($,z)==q}


                io$=function f(a,b,c){

                    var j=fx(JS);

                    if(c<0){ c+=_.z(a) };

                    return j('io', arguments)

                };




                sx$=function(a,b,c){var cc= _.cc, s= _.sl;  return cc( s(a,0,b), s(a,c,Z(a) ))}  //inverse slice//->oG("s")("do this")


                lO$=lo$=function f(a,b,c){if(c<0){c+=_.z(a)}return _lo(a,b,c)};


                b$=function f(a,b){
                    var i=io$(a,b), A=_.z(a), B=_.z(b);

                    return _sl(a,0,i)}     //$l(i,A,B)



                bI$=function f(a,b){  var i=io$(a,b), A=_.z(a), B=_.z(b); return _sl(a,0,i+B)}
                bL$=function f(a,b){  var i=lo$(a,b), A=_.z(a),B=_.z(b); return _sl(a,0,i)}
                bLI$=function f(a,b){ var i=lo$(a,b), A=_.z(a),B=_.z(b); return _sl(a,0,i+B)}
                a$=function f(a,b){   var i=io$(a,b), A=_.z(a),B=_.z(b); return _sl(a,i+1,A)}   //$l(i,A,B)
                aI$=function f(a,b){  var i=io$(a,b), A=_.z(a),B=_.z(b); return _sl(a,i,A)}
                aL$=function  f(a,b){ var i=lo$(a,b), A=_.z(a),B=_.z(b); return _sl(a,i+1,A)}
                aLI$=function f(a,b){ var i=lo$(a,b), A=_.z(a),B=_.z(b); return _sl(a,i,A)}

                c$=function(a,b){return io$(a,b)!==-1}

                p$=function(a,b){return(f$(a,b))?a:b+a}//2

                e$=function(a,b){ if(!b){return c$(a,'.')?ali$(a,'.'):false}; if(!e$(a)){a+=p$(b,'.')}; return a}

                eR$=function(a){

                    return _rp(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g,"\\$&",a)

                }

                rg$=function(a,b){return $R(eR$(a),b)}

                rG$=function(a,b){return rg$(a,'g')}





                $V=function(a,b,c,d){a=a||0;
                    if(d){return $V((a-c)/2,(b-d)/2)};
                    if(iA(a)){return $V(a[0],a[1])};
                    if(iN(a)){return $V({x:a,y:b})}
                    return {x:a.x||0, y:not('ud',a.y)?a.y:a.x||0}}

                $do=function(a,b,c,d){ if(iF(b)){b(a,c,d)}; if(iS(b)){W[b]=a}; return a}
                $ev=function(a){return function(){eval(a)}};  $$$=function(a){$(function(){eval(a)})}

                _M=function(m){ return function(t){var g= _.r(arguments); return m.apply(t,g)}}
                _T=function(t){ return function(m){var g= _.r(arguments); return m.apply(t,g)}}
                _O=function(o){ return function(m){var G=(arguments),f=_.f(G), r= _.r(G);return o[m].apply(f, r)}}
                _F=function(M){ return function f(){var g=arguments,  m=_.f(g),args=_.r(g); if(U(fg)){return O}; O=M[m].apply(O, args); return f}}


                tO=_.object;
                tA=_.toArray;
                tS=function(a){  return(iO(a))?_js(a):_ts(a)  }

                eE=function(a){  if(a){return $(a)[0]}  }

                jq=function(a){  return sQ($(a))  }

                oScr=function(a){  $(W).scroll(a)  }

                exc=function(a){return  a==='!' }
                star=function(a){return a==="*"};
                emp=function(a){return a.empty()}
                $ls=function(a){return $l("* "+a+" *")}

                ff=function f(a){if(f[a]){return f(f[a])}; if(iS(a)){return f._f(a)}}
                ff.t="alert(h)"; ff.t2="t=5"
                ff._f=function(a,b,c,d,e){return new $F("a", "b", "c", "d", "e","var g =aA(arguments),h='helloooo', t =this, o ={},s='',l=[],z =0 ;"+a+"; return t")}

                _U=function(a,b,c){if(U(a)){b=ff(b);return b(b)};if(!U(c)){c=ff(c);c( a,c )}}
                _U.t=function(a){return _U(a,"t={j:5}","alert(a)")}
                _a=function(a){return function(){return a.apply(a, arguments)}}
                _a.t0=function( a,b,c ){return a+b+c}
                _a.t=function (){ var t=this; return t(t.t0)(1,1,100)};




                ff=function f(a){
                    if(f[a]){return f( f[a] )}
                    if(iS(a)){return f._f( a )}}

                ff.t="alert(h)";
                ff.t2="t=5"
                ff._f=function(a,b,c,d,e){
                    return new $F("a", "b", "c", "d", "e",
                        "var g =aA(arguments),h='helloooo', t =this,"+
                            "o ={}, s ='', l =[], z =0 ;"+a+"; return t")}




                _U=function(a,b,c){
                    if(U(a)){b=ff(b);return b(b)}
                    if(!U(c)){c=ff(c);c( a,c )}}
                _U.t=function(a){return _U(a,"t={j:5}","alert(a)")}


                _a=function(a){return function(){return a.apply(a, arguments)}}
                _a.t0=function( a,b,c ){return a+b+c}
                _a.t=function (){var t=this; return t(t.t0)(1,1,100)   }












                aft          =after    =function f(a,b){return a.slice(a.indexOf(b)+1,_z(a))}//$l(i,A,B)
                aI                   =afterInclusive          =function f(a,b){return a.slice(a.indexOf(b),_z(a))}
                aL          =afterLast                =function  f(a,b){return a.slice(a.lastIndexOf(b)+1,_z(a))}
                aLI             =afterLastInclusive       =function f(a,b){return a.slice(a.lastIndexOf(b),_z(a))}
                b4               =before     =function f(a,b){return  a.slice(0,  a.indexOf(b)  )}//$l(i,A,B)
                b4i               =beforeInclusive=function f(a,b){return a.slice(0, a.indexOf(b)+_z(b))}
                b4l              =beforeLast=function f(a,b){return a.slice(0, a.lastIndexOf(b))}
                b4li            =beforeLastInclusive=function f(a,b){return a.slice(0, a.lastIndexOf(b)+_z(b))}
                i$                  =function fn(a,b,c){
                    var o=arg(arguments);
                    if(o("s")){return a.slice(0,_z(a)-1)};
                    if(o("sn")){return a.slice(0,_z(a)-b)}
                    if(o("sns")){return fn(a,b)==c}
                    if(o("ss")){return fn(a,1,b)}}
                r$  =function fn(a,b,c){
                    var o=arg(arguments);
                    if(o("s")){return a.slice(1,_z(a))};
                    if(o("s,n")){return a.slice(b,_z(a))}
                    if(o("sns")){return fn(a,b)==c};
                    if(o("ss")){return fn(a,1,b)}}


                f$              =function fn(a, b, c){var o=arg(arguments);
                    if(o("s")){return a.slice(0, 1)}
                    if(o("sn")){return a.slice(0, b)}
                    if(o("sns")){return fn(a,b) == c}
                    if(o("ss")){return fn(a, 1, b)}}
                l$              =function fn(a,b,c){
                    var o=arg(arguments);
                    if(o("s")){return a.slice(_z(a)-1,_z(a))};
                    if(o("s,n")){return a.slice(b*-1,_z(a))}
                    if(o("sns")){return fn(a,b)==c};
                    if(o("ss")){return fn(a,1,b)}}



                boo   =bl   =bool=function(fac){
                    var f =function r(a){if(U(a)){
                        return r.a}
                        return r}
                    f.a=$B(fac);
                    f.and=function(fac){  this.a = $B(fac && this.a); return this}
                    f.or=function(fac){  this.a = $B(fac || this.a); return this}
                    f.nor = function(fac){  this.a = $B(!fac && !this.a); return this}
                    f.nand = function(fac){  this.a = $B(!fac || !this.a); return this}
                    return f}


                io$      =function f(a,b,c){
                    if(c < 0){c+=_z(a)}
                    return a.indexOf(b,c)}



                gc={"d":"destination-over","da":"destination-atop","do":"destination-out",
                    "di":"destination-in","s":"source-over","a":"source-atop",
                    "o":"source-out","i":"source-in","l":"lighter","x":"xor","c":"copy"}

                ggg=function(gc){


                    $b().empty();
                    a = cC('<','w',7)
                    x= a.x;
                    pop({f:'G', wc:'b', wx:30, wy:30, wb:(gc||0)*5}, x)

                    x.fillRect(0,0,400,300)
                    pop({wc:'o',f:'p'},x)
                    pop({gc:'s'},x);  x.fillRect(50,50,500,200)

                }



                <input type="text" name="email" size="40" maxlength="50">
                    <input type="password">
                        <input type="checkbox" checked="checked">
                            <input type="radio" checked="checked">
                                <input type="submit" value="Send">
                                    <input type="reset">
                                        <input type="hidden">



                                        //_$=function(a,b){oB(b).append(a);return a};//$_=function(a,b){oB(b).prepend(a);return a}
                                        //can=function(p,z){if(S(p)){p={'C':p} }; p=$e('c',p);if(!Z(z)){$b(p)}; return p}
                                        //cc= function(){ $b('c') }
                                        //$x reserved in console for xpath
                                        //ooO=function(o){return function(a){return oO(o,a)}}
                                        //Ooo=function(o){return function(a){return Oo(o,a)}}
                                        // a brilliant function that you pass a canvas  to; it returns a fn that lets u make calls on the ctx by using the abbreviated obj keys
                                        // an oo is a fn-ob that provides dependencies in a simple and awesome way!
                                        // oOo is an abstract class for making oo's,
                                        // which lets CLIENT determine  the function of the function object made from object oo !!!
                                        //$i2 = function(I,k,v){return{k:oO(I,k),v:oO(k,v)}}
                                        // k:k-safeTried-against-I,  v:v-safeTried-against-k || examples:
                                        // $i(oO('S'))('dp','f')  -> k:'display',  v:'table-footer-group'
                                        // $i(oO('S'))('dp')  --> k:'display',v:{(i:'inline')..}
                                        // $i(oO('S'))('dp','zzz')   -->  'display':'zzz'
                                        // $i('zzz','zzz')  --> 'zzz':'zzz'
                                        // $i(oO('S'))('abc')--> 'abc':'abc'
                                        // $i('zzz','zzz')  --> cool !//gen -> $i
                                        //ex:  xi(  {hello:4},   {},    'hello'  ) --> 4
                                        // xi(  {a:4},  {h:'hello'},  'h'   )  --> 4
                                        //xi(  {display:3},'S', 'dp' ) -->3
                                        //xi(  {display:3},'S', 'dp',5 )    --> {display:5}
                                        //? xi(ctx,'X',gc, val )
                                        //set/adds properties from a passed-in-ob(pi-Ob), to a pi-jQob
                                        //if(S(b)){return $i(a,b,c)}

                                        Ob=function(a,b,c){
                                            var name,num,dob,
                                            pp=function(a){return function(b,c){return(c?b+a+c:b?b+a:a)}}
                                        if(O(a)){dob=a}if(O(b)){dob=b}if(O(c)){dob=c}
                                        if(N(a)){num=a}if(N(b)){num=b}if(N(c)){num=c}
                                        if(S(a)){name=a}if(S(b)){name=b}if(S(c)){name=c}

                                        name=name||'anon'
                                        num=num||0
                                        dob=dob||{}
                                        var p=pp('o_'+name)
                                        return defaults(dob,{
                                            k:'o',  t:O,  name:p(), originalName:name,
                                            N:null,  n:num,  a: ["item1","item2"],
                                            o: {firstKey:'firstValue', secondKey:'secondValue'},
                                        toString:function(){return p('Mock Object ')},
                                        f:function(){
                                            return 'you involved this.f : '+this.toString()},
                                        tree:{one:{two:{three:{leaf:{}}}}}
                                        })

                                        };
                                        obs=function(){o1=Ob(1,'o1');o2=Ob(2,'o2', {

                                            a:[o1,o1.a,o1.o,o1.f],

                                            f:function(){return [o1,o2]



                                            }})}
                                        Ii=function(a){
                                            return function(b){
                                            return function(c,d){
                                            return $i(b,a,c,d)}}}
                                        //$("body").css('backgroundColor', rO('C','b'))
                                        Ss=function(a){
                                            return function f(b,c){
                                            if(U(b)){return a}
                                        if(F(b)){return b(a)}
                                        if(S(b) && U(c)) {return ss(a, b)}
                                        ss(a,b,c)
                                        return f}}
                                        //ee = function f(a,b){if(O(a)){return f('d',a)}; return ss(tag(a),dF(b))}
                                        // get keys,result,random//safe // u use at global, level1 or level2  // this is a normal getter.   // it returns exactly what u ask for  // that could be undefined
                                        ji=function(a,b){ return (F(a))? a(b) : b || a }
                                        jo = function f(a,b,c){
                                            return (U(b))?     a:
                                            (U(c))?     b[a] || a || b:
                                            f( c, f(a,b) )  }
                                        Ts=function(a,b){
                                            a.toString=function(){return b}
                                        return a
                                        };Ts.toString=function(){return "pass in a func and a str value"}
                                        ty=Ts(function(a){
                                            var o={},arr=[]; if(U(a)) {a={}}
                                        _e(BA,function(b){
                                            if(!$w[b] ){$l(b+' is not a function ')}
                                        else{ if( $w[b]( a ) ){$l(b);
                                            arr.push(tL(b)) }}}); return arr},
                                        "-> value. checks value against all bool-funcs." +
                                        "\nruturns arr of @s (lc let of bool passing bool-funcs")
                                        fa=function(args){var o={}
                                        var _Fo=function(a,b){return _I(_F(_I(a),b))}
                                        _e(BA,function(b){o[tL(b)]=fi(args,$w[b])})
                                        return _Fo(o,_n(U))};
                                        fa.toString=function(){
                                            return "-fa-\n-> arguments\n<- a very interesting object." +
                                            "\nevery letter of the alphabet is a popKey.\nits value is " +
                                            "the FIRST arg that was true\n(for that letter as a bool func)."}
                                        eR$=function(a){return _rp(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g,"\\$&",a)}
                                        rg$=function(a,b){return $R(eR$(a),b)}
                                        rG$=function(a,b){return rg$(a,'g')}
                                        $do=function(a,b,c,d){
                                            if(F(b)){ b(a,c,d) };
                                        if(S(b)){$w[b]=a};
                                        return a}

                                        //_oo=function(a,b){if(b){return oO(a,b)||b} return oO(a)||a}
                                        // css=function(a,b){ _e(dF(b),function(v,k){ $(a).css(k,v) });return a}






                                        //z=function(){var fw='font-weight', rb='redbold', b='bold',c='color',y='yellow',s='sissy';cl(rb,  rl(c,y)+rl(fw,b)); d=ac(rb,dv()); tx(s,d);  at(d)}
                                        //$.getJSON( url, ) dad(dt)
                                        //$(function(){bb(b=but('hifsaasfsfd', function(){ })); bd=$("body")})
                                        //hr=function(r){
// var f=$M.floor,n=256, v=p16(rr(r));
// return new po(f((v/(n*n))%n),f((v/n)%n),f(v%n))}
                                        //Entity, Index, Pop, Value
                                        //rO=function(a,b){return oO(oO('R',a),b)}
                                        // oC=oo(oO,'c');  o_=oo(oO,'S'); oX=oo(oO,'X');  ox=oo(oO,'x');Xo=oo(Oo,'x'); oq=oo(Oo,'q');  oQ=oo(oO,'Q');
                                        //f.q[oO('q',b)].apply(f.q, _m( _r(arguments), tQ));
                                        //o.can=function(){o(0); return $c('<',12) }
                                        //tQ=function(a){  return (P(a))?  el(a): (E(a)||Q(a))?   $(a):  a.q}
                                        // alt key!!! ≈≈∂ƒ˜©˙∆˚¥¨∫˜≤åß∂∑œ˜˜∫√˙˙√√√√√√√√ΩΩΩΩ≈≈ßß∂∂∑∆∂µ∆ß
                                        //XYZ=function(a,b){return a(b.x,b.y,b.z)}
                                        // ??? may be important:  oo used to have this clause: return function(a){ return o(b, a) }
                                        pseudoEls=function(){  }
                                        // to target o/w untargetable doc txt.. some doc structure outside dom


                                        oOold = oo(function f(a,b,c){
                                            return   U(a)   ? _K(f)
                                            :'*'==b ? ran(a)
                                            :U(b)   ? (f[a]||a)
                                            :!U(c)  ? f(f(c,a), b)
                                            :(f[a]&&f[a][b]) ? f[a][b]
                                            : b})







