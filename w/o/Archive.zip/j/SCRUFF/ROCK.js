// proton

$D=Date;
$E=Error;
$F=Function;
$I=Infinity;
$A=Array;
$M=Math;
$B=Boolean;
$J=JSON;
$N=Number;
$O=Object;
$S=String;
$R=RegExp


_a=function(a,b,c){return a.apply(c||a, b)}

A=  _.isArray

B=  _.isBoolean


C   =function(a){
    var c=a.canvas||$(a).get(0)
    if(_h('Canvas',c)){return c}}
cC  =function(a){  return X(a)? a.canvas: $(a)[0]  }


D   =function(a,b,c){return  U(b)? !U(a) :_a( _.defaults,arguments)}


Du  =iD =function(a){return _h(a,'data:')} //return sW(a,'data:')


E=function(a,b,c){
    if(D(b)){return _.every(a,b||N,c)}
    if(O(a)){var e=$(a)[0];
        if(_.isElement(e)){return e}}}
E.eE =function(a){ return $(a)[0]||a }
Ee =function(a){ return $(a)[0] }


F=function f(a,b,c){
    return b? _.filter(a,b,c)
        :_.isFunction(a)?
        a.prototype||true:0}
G=function(a,p,n){
    a= _.toArray(a)
    if( _l(a) === '+' ){p=a.pop()}
    if( _l(a) === '-' ){n=a.pop()}
    return D(a, {
        z: a.length,
        f:_f(a), l:_l(a),
        r:_r(a), i:_i(a),
        p:p, P:!p, n:n, N:!n })}

I=function(a){
    var i=$(a).get(0);
    if(_h('Image',i)){
        return i}}
        //can something be an image and if so
        // return its data-url or a string

//Jj=function(a,b){return U(b)? H(a,"Sprite"):gJ}


K=function(a,b,c){ return N(a)? sI(a, b*1000): _.keys(a) }

Lc=function(a){return s$(a).isLower()}


N=_.isNumber
Nn=_.isNan


O=function(a,b){return U(b)? _.isObject(a): $a(_.extend, arguments)}


Q=function(a){
    if(O(a)){a=$(a);
    if(E(a[0])){
        return a}}}
qQ =function(a){
    return E(a)?$(a):a}
Qq =function(a){
    return E(a)}


R=function(a,b,c){
    return U(b)? _.isRegExp(a): N(a)? _.range(a,b,c):0}


S=function(a,b,c){
    return U(b)? _.isString(a) : _.some(a,b||F,c)}


U=function u(a,b){
    var iU=_.isUndefined;
    return iU(b)? iU(a)
        :_a(_.extend,arguments)}


V=_.values

W=$w=window





X=tX=function c(a){
    if(a.canvas){return a}
    var e=$(a)[0]
    if (e['getContext'])
        return e.getContext('2d')
    return E(x)?xX(x):x}





