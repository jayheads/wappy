
_w  =function(a,b){

    if(F(a.width)){
        if(U(b)){
            return a.width()}  //|| a.w
        if(N(b)){
            a.width(b)}
        return a}
    if(U(b)){
        return D(a.width)?
            a.width: a.w}
    if(N(b)){
        return _s(a,'width',b)}}



_h  =function h(a, b){
    if( O(a) && F(a.height) ){
        if(U(b)){return a.height()}  //|| a.w
        if(N(b)){a.height(b)}
        return a}
    if(U(b)){return D(a.height)? a.height: a.h }  //|| a.h
    if(N(b)){return _s(a,'height',b)}
    if(A(a)){return _.contains(a,b) }
    if(O(b)){return h(_S(b),a)}
    if(S(a)){return s$(a).contains(b)}
    if(O(a)){return a.has(b)}

}



$A      =Array;
A       =_.isArray
_a      =function(a,b,c){return a.apply(c||a,b)}

$a2=function(a,b,c){var g=G(arguments)
    if(F(a)){return a.apply(c||a, b)}
    return  _a(b[a],   _r(g,2),  b)}

//$a('fillRect', x, 0,0,100,100)
$a=function(a,b,c){var g=G(arguments)

    if(!b){return _p($a, a)}

    if(F(a)){return a.apply(c||a, b)}
    return _a(a[b], _r(g,2), a)}





B       =_.isBoolean
$B      =Boolean;
_b      =function(a,b,c){
    if (U(a)) {return $('body')}
    return  F(a)? _.bind(a,b,c)
        :_.bindAll(a,b,c)}



C       =function c(a){
    if(O(a)){
        if(a.canvas){return a.canvas}
        if(_h('Canvas',_g(a))){return _g(a)}}
    if(F(a)){if(a.x){return c(a.x)}}}


_c  =function(a,b){if(U(b)){return a.clone()}

    if(!A(a)){a=[a]}
    return a.concat(b)

}


cL      =function(a){console.log(a);return a}
clk     =function(a,b,c){return a.click(b,c)}
clr     =function(c){var x=xx(c);x.X()}
_ch     =function(a){return a.children()}





_C      =function(a,b){
    if (U(b)){return   _.compact(a)}

    a.connect(b)
}


    $D      =Date;

D       =function(a,b,c){
    return  U(b)? !U(a)
        :_a( _.defaults,arguments)}

Du      =iD =function(a){
    return _h(a,'data:')}
def     =function(d,b){return _D(d=d||{}, oO(b||''+'D'))}//dst,srcPre
dim     =function(a,w,h){a=E(a)
    _w(a,w); _h(a,h||w)
    return a}

_d=function(a){
    return D(a)? a.data: $(document)}



dbl     =function(a,b,c){return  a.dblclick(b)}
$E      =Error;



E       =function e(a,b,c){
    if(A(a)){
        return _.every(a, b||N, c)}

    if(O(a)){if(a.q){a=a.q}
        if(C(a)){return C(a)}
        if(_.isElement(_g(a))){return _g(a)}}}



_e=function e(aa,bb,cc){
    if(F(aa)){aa=O(aa)}
    if(S(bb)){return e(aa,
            function(a, b){
                eval(bb)},cc)}
    if(bb){
        return _.each(aa,bb,cc)}



    return a.empty()}
eL      =function(a,b){return s$(a).ensureLeft(b).s}
eR      =function(a,b){return s$(a).ensureRight(b).s}
eW      =function f(a,b){return l$(a, _z(b))==b}
ext     =function(a,b){return(_h(a,'.'))?a: eR(a, b||'.png')}
_F      = _.flatten
fF      =function(a){return f(a)? a(): a}      //?
$F      =Function;
F       =function f(a,b,c){
    return b? _.filter(a,b,c)
        :_.isFunction(a)?
        a.prototype||true:0}
_f      =function(a,b,c){return F(b)? _.find(a,b,c): _.first(a,b)}
gJ      =function(a,b,c){return $.getJSON(a,b,c)}



_g      =function(a){

    if(O(a) && !F(a)){
        return a.target  || $(a)[0] }
}





G=function(a){var p,n
    if(_.isArguments(a)){
        a=_.toArray(a)
        if(_l(a)==='+'){p= a.pop()}
        if(_l(a)==='-'){n= a.pop()}
        return D(a, {
            z: a.length,
            f:_f(a),
            l:_l(a),
            r:_r(a),
            i:_i(a),
            p:p,
            P:!p,
            e:E(_f(a)),
            _g:_g(_f(a)),
            n:n,
            N:!n
        })}}

testG=function(){return G(arguments)}



_I      =function(a,b){return U(b)? _.invert(a)  :_a(_.intersection,arguments)}
$I      =Infinity;
I       =function(a){if(_h('Image',_g(a))){return _g(a)}}//can something be an image and if so// return its data-url or a string
_i      =function(a,b){ return U(a)? new Image(): _.initial(a,b)}
inn     =function(a){return {w:iW(W),h:iH(W)}}
iW      =function(a){return $(a).get(0).innerWidth}
iH      =function(a){return $(a).get(0).innerHeight}


jS      =function(a){return JSON.stringify(a)}
$J      =JSON
J       =function(a,b){return U(b)? H(a,"Sprite"):gJ}
_j=function(a,b){return (a||[]).join(b||' ')}



K       =function(a,b,c){
    return N(a)? sI(b, a*1000)
        : N(b)? sI(a, b)
        : _.keys(a)}



_k      =function(a){return a.complete}



_l      =function(a,b){
    if (F(b)){$(a).load(b);return a}
    return  _.last(a,b)}
Lc      =function(a){return s$(a).isLower()}
lC      =function(a){return a.toLowerCase()}
lIO     =function(a,b,c){return a.lastIndexOf(b,c < 0?c+_z(a): c)}
mC      =Math.ceil
mF      =Math.floor
_M      =_.max
_m      =function(a,b,c){return U(b)? _.min(a): _.map(a,b,c) }

$M      =Math;

$N      =Number;
N       = _.isNumber
Nn      =_.isNan
nN      =function(w){return $B($N(w))}


O       =function(a,b){

    if(U(b)){
        if(  _.isObject(a)   )

        { return _.defaults({}, a)  }
        return
    }

      return $a(_.extend, arguments)}


$O      =Object
oH      =function(a){return E(a) && E(a).outerHTML}
pI      =parseInt
pop     =function(a){return a.pop()}
psh     =function(a){return a.push()}
pre     =function(a,b){return sW(a,b)?a:b+a}

_p
    =function(a,b,c){var g=G(arguments)
    if(F(a.parent)){
        return a.parent(b)}
    if(F(a)){
        return _a(_.partial,g)}

    return nN(a)? a+'px': a}






_p2     =pAr=function(f,B){return function(a,c){return f(a,B,c)}}
Q       =function q(a){if(O(a)){
    if(a.q){return a.q}
    if(E(a)){return $(E(a))}}}
R       =function(a,b,c){return U(b)? _.isRegExp(a): N(a)? _.range(a,b,c):0}
$R      =RegExp
rpl     =function(a,b,c){return a.replace(b||'#', c||'')}


_r      =function r(a,b,c,d){
    return  U(a)? _r(1)
        :(F(b) && D(c))? _.reduce(a, b, c)
        :(F(a) && D(c))? _.reduceRight(a, c, b)
        :(F(a) || F(b))? r(c,a,b)
        :N(a)? _.random(a,b,c)
        :_.rest(a,b)}





s$      =S
$S      =String
_s      =function(a,b,c){
    if(D(b)){a[b]=c;return a}
    var q=$('<br>')

    if(N(a)){_t(a-1,function(){q=q.add(_s())})}
    return q}
S       =function(a,b,c){
    return U(b)? _.isString(a) : _.some(a,b||F,c)}
_S      =tS=function(a){return a.toString()}
shf     =function(a){return a.shift()}
spl     =function(a,b){
    return $S(a||'').split(b||' ')   }



sI      =setInterval
sW      = function(a,b){return s$(a).startsWith(b)}
sT      =function(a,b){return setTimeout(a,b)}
_t      = function t(a,b,c){
    if(F(a)){return t(1,a)}
    if(N(a)){return _.times(a,b,c)}

    if(U(a)){return t(_b())}

    if(U(b)){
        if(S(a)){return t(_b(), a)}
        return $(a).text()
    }

    //  if(!O(a)){return t($("body"), a)}

    return $(a).text(b)
}
tDU     =function(a){return a.toDataURL()}
tA      =function(a){return O(a)? _.toArray(a): [a]}
tT      =function(a){$('body').prepend(a);return a}
tB      =function(a){$('body').append(a);return a}
U       =function u(a,b){
    var iU=_.isUndefined;
    return iU(b)? iU(a)
        :_a(_.extend,arguments)}
_U      =_.union
uC      =function(a){return a.toUpperCase()}
ush     =function(a){return a.unshift()}

V       =_.values

_v=function(a){
    return F(a.value)? a.value(): a.value}


$w      =window



def=function(a,b){ return D(a)?a:b}






_cx=function(c){return c.getContext('2d')}

_x=function(s){

    var q=qq($('<div>'))

     if(O(s)){q.s(s)}

  //  if(S(s)){q.ht(s)}
  //  if(N(s)){q.wh(s,h)}
    return q}



X=function x(c){

    if(O(c)){
        if(c.canvas){return c}
        if(C(c)){return _cx(C(c))}
        if(c.x){return x(c.x)}
        if(c.q){return x(c.q)}}}




_z      =function z(a,b,c){
    return  U(b)? _.size(a)
        : N(b)? _z(a) == b
        : _z(a)== _z(b)}
_Z      =_.zip




clX=function(e){return e.clientX}
clY=function(e){return e.clientY}
aCl=function f(a,b){
    if(U(b)){
        return f(_b(),a)}
    $(a).addClass(b)
    return a}
osL=function(a){return a.offset().left}
osT=function(a){return a.offset().top}


rc=function r(f,a){  //****

    if(U(a)){return _p(r,f)}

    return _m(a,function(a){
        if(A(a)){return r(f,a)}
        return f(a)})

    //rcMini=function r(f,a){return U(a)?_p(r,f):_m(a,function(a){return A(a)?r(f,a):f(a)})}
    //test later.. its sugar
}



rc100=rc(function(a){return a*100})



