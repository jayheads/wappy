em=function em(t,b, d,e){

    var g=G(arguments)   //b:styleOb,//d,e: w/h
    z=g

    if(N(b)){return em(t, {C:'p', c:0}, b, d)}
    if(S(b)){return em(t, {C:b}, d, e)}

    t=$t(t)
    if(b){ss(t, b)}
    if(d){siz(t, d, e)}

    if(g.N){tT(t)}
    return t}
txt=function t(a,b){
    if(U(a)){
        return t('sissy')}
    if(S(a)){return t(_b(), a)}
    a.text(b)}
cols=function(a,b){
    a.attr('cols',b);
    return a}
rows=function(a,b){ a.attr('rows',b);
    return a}
fZ=function z(a,b){
    if(U(a)){return z(50)}
    if(N(a)){return z(_b(),a)}
    ss(a,{fz:b||50})}
fC=function r(a,b){
    if(U(a)){return r($r('c'))}
    if(S(a)){return r(_b(),oO('c',a))}
    ss(a,{c:b})}
bC=function r(a,b){
    if(U(a)){return r($r('c'))}
    if(S(a)){return r(_b(),oO('c',a))}
    ss(a,{C:b})}
bor=function(q){
    q=qq(q)
    q.s({b:20})}


tOl =function(a){a=spl(a)
    return _j([$r('c', a[0]),
        _p(oO('ow', a[1]||5)),
        oO('os', a[2]||'-')])}




pad=function p(el,a,b,c,d){var s=ss(el)
    if(U(a)){return {
        t:s('pt'),
        b:s('pb'),
        l:s('pl'),
        r:s('pr')}}
    if(U(b)){return s('p', a)}
    if(U(c)){
        s('pl', a)
        s('pr', b)
        return s}
    if(U(d)){
        s('pl', a)
        s('pr', b)
        s('pt', c);
        s('pb',c);
        return s}
    s('pl',a)
    s('pt',b)
    s('pb',c)
    s('pr',d)
    return s}

ob=function(o){return o||{}}

DV='<div>'
BTN='<button>'



// jquery 'prop'
pp=function pp(q,b,c){q=Q(q)
    var rop=function(q,b,c){
        q=Q(q)
        if(U(c)){return q.prop( oO('p', b) )}
        return q.prop(oO('p',b), $o(b,c,'R'))}
    return U(b)? _p(pp,q)
        :A(b)? _r(b,function(m,k){
        return _s(m,k,pp(q,k))},{})
        :O(b)? $p('p',q,b,rop)
        :rop(q,b,c)}
typ=function(t,k){return pp(t,'t',k)}//'t',  OO('h', b) )}
val=function(t,k){return pp(t,'v',k)}
id=function(t,k){return pp(t,'i',k)}
nam=function(t,k){return pp(t,'n',k)}
isA=function(a,b){return a.insertAfter(b)}
fadeOut=function(a,b){return b? $(a).fadeOut(b):$(a).fadeOut()}
//jquery 'attr'
aa  =function aa(q,b,c){q=Q(q)
    var  att=function(q,b,c){q=Q(q)
        if(U(c)){return q.attr( oO('a', b) )}
        return q.attr(oO('a',b),$o(b,c,'R'))}
    return  U(b)? _p(aa,q)
        :A(b)? _r(b,function(m,k){
        return _s(m,k,aa(q,k))},{})
        :O(b)? $p('a',q,b,att)
        :att(q,b,c)}
aaH=function(c,h){
    if(U(h)){return aa(c,'h')}
    aa(c,'h',h)
    return c}
aaWH=function(c,w,h){
    if(U(w)){return {w:aaW(c), h:aaH(c)}}
    if(U(h)){h=w};
    aaW(c,w);
    aaH(c,h);
    return c}
aaW=function(c,w){
    if(U(w)){return aa(c,'w')}
    aa(c,'w',w)
    return c}
ssC=function(a,b,c){var s=ss(a)  // ob->{c,C}   OR   set C[,c]
    if(!b){return {c:s('c'), C:s('C')}}
    s('C', b)
    if(c){ s('c', c)}
    return a}
//font/text  css
$f=function r(a,b){

    if(U(a)){return tFo()}
    tFo=function rc(a){var F,W,S, Z,
        z=function(a){
            a=spl(a,'/');var s=_p(a[0])
            if(a[1]){s+='/'+_p(a[1])}// add optional lineheight value
            return s}
        _e(spl(a),function(p){
            if(nN(p[0])){Z=z(p)}
            if(Oo('ff',p)){F=Oo('ff',p)}
            if(Oo('fw',p)){W=Oo('fw',p)}
            if(Oo('fs',p)){S=Oo('fs',p)}})
        return  _j([
            S||'oblique',
            W||'800',
            Z||_p(50),
            F||'fantasy'])}//fF="100px sans-serif"
    if(!O(a)){return r(_b(),tFo(a))}
    ss(a,{f:b})}
//outline  css




custDataAtr=function(a,b,c){a=$(a)
    if(U(c)){return a.attr('data-'+b)}
    a.attr('data-'+b,c)
    return  a}


rules=function fz(a,b){



    var sy=function(a){
            return "<style type='text/css'>"+a+"</style>"},
        cl =function(a,b){var c=function(a,b){
            return '.' +  a  +  '{' + b|| '' + '}'  }
            return hd(sy( c(a,b) ))},
        rl=function f(a,b){
            var s=''
            if(O(a)){
                _e(qs(a), function(v,k){
                    s += f(k,v)})
                return s}
            return  a + ':' +  b  + '; ' }

    if(O(a)){ _e( a, function(v,k){ f(k, v)})}

    cl(a, rl(b))}
qM=function(a){return $m('q', $(a))}

qq=function(e,s,c,f){
    if(e.name==='q'){return e}
    if(!E(e=$(e))){return qs(e)}

    var q=function q(a,b){
        if(O(a)) {q.s(a)}
        else {q.res=_a(q.m, arguments) }
        return q}

    q.q=Q(e)
    q.e=q.q[0]
    q.s=ss(q.q)
    q.m=qM(q.q)
    q.bd=function(s,c,y){if(U(S)){s=10};
        var ws=function(a){return ' '+a+' '};
        q.l('border',$l(ws(s+"px")+ws(y||"solid")+ws(c||"blue")));
        return o}
    q.b=function(a,b,c,d){
        if(N(a)){
            if(U(b)){q.s('b', a);return q}
            q.bl(a);
            q.br(b)}
        if(N(c)){q.bt(c)}
        if(N(d)){q.bb(d)}
        return q}
    q.bl=function(a){q.s('bl',a);return q}
    q.br=function(a){q.s('br',a);return q}
    q.bt=function(a){q.s('bt',a);return q}
    q.bb=function(a){q.s('bb',a);return q}
    q.mq=function(){var g=G(arguments);return _a(q.m(g.f),(g.r))}
    q.qq=function o(a){
        if(a.q){a=a.q}
        if(F(a)){return a(q.q)}
        if(a===0){return q.emp()}
        if(U(a)){return q.ch()}
        if(S(a)){q.met(a);return o}
        if(O(a)){ss(q.q,a);return o}
        //if(b==='c'){q(0); return $c('<',12)}
        //if(b==='z'){ return q.q.children().size()}
        //if(S(b)){q.q = q.q[oq(b)].apply(q.q,_m( _r(arguments), tQ));
        return o('ap', a)}
    q.bf=q.m('b')//q.a=q.m('a')
    q.X=function(){q.q.empty();return q}
    q.x=function(x){if(!x){return q.q.offset().left} return pI( x - q.x() )}
    q.y=function(y){if(!y){return q.q.offset().top} return pI( y - q.y() )}





    q.o=function(a,b){

        q.q.on(a, b);

        return q}



     //q.o2=function(a,b,c){q.q.bind(oO('e',a), b, c);return o}


    q.$=function(a){

        q.o('click',

            function(e){

                var x=clX(e),
                    y=clY(e),
                    g= _g(e),
                    t=this,
                    j=$(this)
                    q=qq(j)

                q.ev=g

                a(g,

                    x-q.x(),
                    y-q.y(),
                    x, y)
            })


        return q}








    q.$$=function(a){
        q.o('dblclick',
            function(e){
                var x=e.clientX,y=e.clientY;   var t= e.target;t.e=e;
                a(qq(t),x - q.x(),  y - q.y(), x, y )});
        return q}





    q.w=function(w,b){


        if(U(w)){return q.q.width()}
        if(w==='+'){return q.w( q.w()+b ) }
        if(w==='*'){return q.w( q.w()*b) }
        if(w==='%'){return q.w( q.w()*b *.01 ) }
         q.q.width((w<10)? w*100 :w  )
    return q}


    q.W=function(t){

        if(U(t)){return q.q.text()}
        q.q.text(t)
        return q}




    q.h=function(h,b){
        if(U(h)){return q.q.height()}
        if(h==='+'){return q.h( q.h()+b ) }
        if(h==='*'){return q.h( q.h()*b) }
        if(h==='%'){return q.h( q.h()*b *.01 ) }
        q.q.height(  (h<10)?h*100:h)

    return q}


    q.z=function(z,b){
        if(U(z)){//return {    w:q.q.width(), h:q.q.height()  }
            return q.ch().size()}
        if(z==='+'){ q.w( q.w()+b );q.h( q.h()+b )      }
        if(z==='*'){ q.w( q.w()*b );q.h( q.h()*b )   }
        if(z==='%'){ q.w( q.w()*b * .01 );
            q.h( q.h()*b *.01 )  }
        q.h(z); q.w(z)
        return o}
    q.t=function(a){_t(q.q,a);return q}
    q.T=function(a){
        if(U(a)){return pI(q.s('T'))}
        q.s('T', a)
         return q}
    q.L=function(a){
        if(U(a)){return pI(q.s('L'))}
        q.s('L', a)
        return q}

    q.__=function(a){return q.q.hasClass(a)}
    q._=function(a){q.q.addClass(a);return q}
    q.ch=function(){return q.q.children()}
    q.col=function q(a,b,c,d){
        if(U(a)){c.append()};
        if(S(a)){var s;
            q.s();
            if(U(b)){s=a}
            else{s="rgba("+ [a,b,c,d].join(",") +")"}
            q.pop('f', s);
            q.q(0,0,q.w(),q.h());
            q.r()}
        return q}
    q.c=function(a,b){if(D(b)){q.C(a);q.c(b);return q}
            q.s('c',a);return q}
    q.C=function(a,b){q.s('C',a); if(b){q.c(b)}; return q}
    q.dv//make div and append it and return it
    q.p=function(a,b,c,d){
            if(N(a)){
                if(U(b)){q.s('p', a);return q}
                q.pl(a);
                q.pr(b)}
            if(N(c)){q.pt(c)}
            if(N(d)){q.pb(d)}
            return q}
    q.pl=function(a){q.s('pl',a);return q}
    q.pr=function(a){q.s('pr',a);return q}
    //q.pt=function(a){q.s('pt',a);return q}
    q.pb=function(a){q.s('pb',a);return q}
    q.m=function(a){q.s('m',a);return q}
    q.z=function(a,b){q.w(a);q.h(b||a);return q }
    q.z.z=function(t){if(!t){return siz(q);q.q.text(t)} return q}
    q.X=function(){q.q.empty()}
    q.t=function(t){if(!t){return txt(q);q.q.text(t)} return q}


    q.H=function(t){
        if(t==='o'){return q.outerHTML}
        if(U(t)){return q.q.html()}
            q.q.html(t)
        return q}



    q.pt=function(a){return q.q.prependTo($(a||'body'))}
    q.pp=q.m('pp')
    q.aB
    q.tB
    q.bB
    q.pB


    q.a2=function(a){
        q.q.appendTo($(a||'body'))

    return q}


    q.a=function(a,b){
        if(U(a)){return q.a2()}

        if(U(b)){
            return q.a2(a)}

        if(A(a)){
            _e(a, q.a)
            return q}

        _e(arguments, function(a){
            q.q.append(a)})


        return q


    }





    q.j=function(b,c){return N(c)? q.q.animate(qs(b), c*1000)
                : q.q.animate(qs(b))}
        //for fun
        q.O=function(n){q.q.fadeOut(n)}
        q.I=function(n){q.q.fadeIn(n)}
        q.OI=function(n1,n2){q.q.fadeOut(n1).fadeIn(n2||n1)}
        q.v=function(a,b){val(q,a,b)}
        q.t=function(a,b){typ(q,a,b)}
        q.fz
        q.T
        q.B
        q.L
        q.R
        q.P
        q.Z=function(){var w=_w(e), h=_h(e);
            anim(e, {w:ten(w),h:ten(h)},1)
            anim(e, {w:w, h:h},1)}
     //not sure
    q.anims=[q.slU,   q.slD,   q.slT,   q.fI,  q.fO,  q.fT]
    q.h100=function(a){q.animate({height:'100%'})}
    q.overflowAuto=function(){}

    q.crazy=function(a){
        o=tT(bx().z(200).c('b','o').p(10,10).m(50).a(
            i=bx('jas').z(50).c('o','b').p(10,10).m(20).q,
            j=bx('fred').z(50).c('r','y').p(10,10).m(20).q).q)
        _e([j,i,o,'body'], function(v){var k=a||'m',  j=anim,
            ob={k: G(arguments).N?  200: -200}
            j(v, ob, 10)
            ob[k]=0
            j(v, ob, 10)})}

    q.anim=function(b,c){
        return N(c)? q.q.animate(qs(b),c*1000)
            : q.q.animate(qs(b)) }


    q.shw=function s(){
        var w=_w(q.q), h=_h(q.q)
        anim(q.q, {w:(w+10)*10, h:(h+10)*10},1)
        q.q.fadeOut(1000).fadeIn(1000)
        anim(q.q, {w:w,h:h},1)
        return q}


    q.h100=function(a){q.q.animate({height:'100%'})}

    q.bind=function(a){return _.bind(q.c[a],q.c)}
    q._c=function(){return _c(q.q)}

    if(O(s)){q.s(s)}
    if(S(c)){q.ht(c)}
    if(F(f)){q.$(f)}
    return q}
//addClass and css are SHORTCUTS for changing those 'atts'
// use attr to change an img src
//'jq each': 'this' refers to each item in loop
//can convert it: '$(this)' :)
//select 2nd li el: 'li:eq(1)'
//then.. li:eq(1).next() | prev | nextAll | prevAll | parent | parent().children()
sibs=function(a){return $(a).parent().children()}
// to return to PREVIOUS wrapper set, use 'end'
// using 'andSelf' is handy!
// 'destrutive methods' change the wrapped set
qSet=function(q){q=$(q)}
//add, andSelf, children, closes, filter, find, map
    // next, nextAll, not, parent, parents, prev, prevAll,
    //siblings, slice, clone, appendTo, prependTo, insertBefore,
    //  insertAfter, replaceAll
setter=function(index, curVal){
    //this: element


}
rmAt=function(a){return $(a).removeAttr}
atts=function(a){
    var t=function(b){return a.attr(b)}
    return {action:t('action'),
        src:t('src'),
        w:t('width'),
        h:t('height'),
        target:t(target)}}



elExist=function(a){return _l($(a))}
osDemo=function(){
    _t(20, function(){
        em('d',{w:50, h:50, C:$r()})})
    var d=$('div').eq(3)
    d.fadeOut();d.fadeIn()
    bw.o(d, {t:100, l:300})
    return bw.o(d)}


allTdWithNumVal=function(){
    return $('td').filter(function(){
        return this.innerHTML.match(/^\d+$/)})}


togClass=function(a,b){
    $(a).toggleClass(b)
    return a}



//$('img[alt],img[title]') ~ $('img[alt]').add('img[title]').. but better
//b/c it creates NEW wrapped set.. can be useful with use of 'end'
//add vs not/filter
//slice, has, map
//atts again:  cellspacing, class, colspan, cssFloat, float, for, frameborder,
//maxlength, readonly, rowspan, styleFloat, tabindex, usemap
//'$(elem)', takes *ATTS*ob as 2nd pam.. so:
// $('<img>',{
// src, alt, title,... even 'click'
// }).css({}).appentTo('body)
//atts that can be set: val,css,html,text,data,w,h,offset




h3=function h(a,b){
    if(U(b)){
        if(S(a)){return $('<h3>'+a +'</h3>')}
        if(O(a)){return _p(h,a )}}
    if(S(b)){return a.H(h(b))}}


border=function(a,b){b=ob(b)
    return ss(qq(a||'body').q, {
        ds: b.s||'s',
        dc: $r('c',b.c),
        dw: D(b.w)?b.w:10})}

