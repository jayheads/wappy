$$$('shooter(c)');

function shooter(c){
    game=true;
    c.X();c.T();c.z();c.k('red');
    Cs=[],As=[];Bs=[];g=Guy();
    for(var i=0;i<10;i++){Cs.push(new Coin)};
    for(var i=0;i<5;i++){As.push(new Alien)}

    c.$(function(e){if(game){
            g.dx+=win(-5,5)((e.x()-g.x)/300);
            g.dy+=win(-5,5)((e.y()-g.y)/300);
            new Bullet(g.x,g.y,g.dx,g.dy)};    if(!game){alert('game over!');if((e.x>450)&&(e.y>290)&&(e.x<450+textWidth)&&(e.y<290+textHeight)){location.reload(true)}}})}

    tk(function(c){
        $l('t');
        c.X();
         _.e($d(cat(Bs,Cs,As)),function(a){a.d();
             a.u()});
        g.d();g.u()})

//////////////////////////////////////////////////////////////////

Guy=function(C){C=C||c;
    var g={r:20,x:200,y:200,dx:1,dy:1,c:0,h:1000}
    g.d=function(){var t=this; c.O(t.x, t.y, t.r,'blue','yellow')}
    g.u=function(){var t=this;
        t.x=wrp(0,1200,20)(t.x+t.dx);
        t.y=wrp(0,600,20)(t.y+t.dy)}
    g.d();
    return g}

function Bullet(x,y,dx,dy){var t=this;
    t.dx*=-5;t.dy*=-5;t.r=8;
    t.d=function(){c.O(t.x,t.y,t.r,'pink','white')}
    t.u=function(){t.x-=t.dx;t.y-=t.dy}
    Bs.push(t)}
function Coin(c){var t=this;t.x=_.r(0,1200);t.y=_.r(0,600);t.dx = _.r(0,10)-5;t.dy = _.r(0,10)-5;t.r=10;
    t.d=function(){c.O(t.x,t.y,t.r,'black','yellow')}
    t.u=function(){t.x=warp(0,1200,20)(t.x+t.dx);t.y=warp(0,600,20)(t.y+t.dy)}}
function Alien(c){var t=this;t.x=_.r(0,1200);t.y=_.r(0,600);t.dx = _.r(0,10)-5;t.dy = _.r(0,10)-5;t.r = 25;
    t.draw=function(){c.O(t.x,t.y,r,'rgba(124,252,0,0.5)','black');c.O(t.x,t.y,10,'orange','black')}
    t.u=function(){t.r*=1.001;t.x=warp(0,1200,20)(t.x+t.dx);t.y=warp(0,600,20)(t.y+t.dy)}}

function hits(){
    _.e(Cs,function(c,C){
        if(xyc(c.x,c.y,g)){
            delete Cs[C];
            g.c+=1}});
    _.e(As,function(a,A){
        if (xyc(g.x,g.y,a)){g.h-=1};
        _.e(Bs,function(b,B){
            if (xyc(b.x,b.y,a)){
                delete Bs[B];
                delete As[A];
                As.push(new Alien)}})})}