 performanceTools=['profiler','timeline','jsperf']

 //scaling does not move img on any axis.

 scaleSingleShape=function(x,px,py,s){
     var x=xx(x)
     x('S')
     x('tr' ,px, py)
     x('sc',s)
     x('fr',0,0,100,100)
     x('R')
     return x
}



 transAndRot=function(x,px,py,s){
     var x=xx(x)
     x('S')

     x('tr' ,px, py)
     x('rt',s)

     x('fr',0,0,100,100)
     x('R')
     return x
 }



 //maxWidth, measureText ( text)



 m1=[[10,0],[19,19],[10,9],[9,9],[0,19],[9,0]]
 m2= [[19,19],[10,119],[19,10]]
 m3=[[[10,0],[19,19],[10,9],[9,9],[0,19],[9,0]] ,
     [[19,19],[10,119],[19,10]] ]



 $(function(){

     h=cBox();
     r=rang();
     brk();

     //o('sc', o.w/ 1000, o.h/1000)


     gr(o,[[200,200],100,200], {
         r:0,
         b:1,
         o:2,
         p:4,
         p:7,
         g:10},300,600)

     cur(x,10,300, 900, 0)
     cur(x,10,300, 0, 500)
     cur(x,10,3000, 400, -1000)



     gr(bx, [0,100,500,100],{'0':0,W:5,r:10})

     sun(bx,200,250,2)//bx is q[c]

     sun(cx,160,270)



// drawimage can take actual canvas elements, but it cant take a dataURL.  if you only have the dataURL, you need to filter it through an image element...
// image elements are also taken by canvas elements

// canvas invoked to its dataURL .. sources an image .. which is drawn  onto canvas  (but needs to load first..)


     $(function(){


         //  o=orange()

         // r.c._('r')



         // p.c._('p')

         // b=blue()
         // g.c._('g')

         // $b=qq()

         // $b(o )
         //$b(     p=imgBox()    )
         //  $b( b )

         // $b(p.q)
         //  $b(g.q)
         // q=qq('div')

         // j=qj(ss())

         //pq=qj(p.q)

         // pq.q.append(ss())

         //  pq.o('{}',function(){  $l('sroll'); pq.w(pq.w()+100) })

         // pq.o('$',function(){ pq.h(pq.h()+100) })



     })





     $l('tadah!')}})//wait(1, tax )
 rad()
 pT($('<span>').text('jason') )
 $('input').click(function(){  siz(this,10) ;    (typ(this))  })
 $('input').dblclick(function(){  this.remove() })
 zz=function(a){return siz(a,10)}
 i=  at( inp()     )
 _t(250,but)
 sty({ rb:{C:'g',c:'w',fw:'+'}, rg:{C:'o',c:'r',fw:'+'},  cool:{ C:'b',c:'o',fw:'*9'}    })
 at(  tx(  ac(tag(),'rb'),  'sissy')    )
 at(  tx(  ac(tag(),'rg'),  'sassy')    )
 // s = stateSetter;
 // oo = oO('M','o')
 // o=$i()
 // g= $i('X');//    z=s({},o); $l(z)
 //  boD=function(a){return qQ($b)('ap',a)}
 //sT(tax,1)
 //  tax=function(){dI(bx,'guy',0,9)}
 //max=function(){  dI(cx,'me',0,9)}
 // sT(5,tax)
 // sT(max)



     c2={




     }