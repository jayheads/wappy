
a=after()	//Inserts content after selected elements
b=before()	//Inserts content before selected elements
ap=append()	//Inserts content at the end of selected elements
apT=appendTo()	//Inserts HTML elements at the end of selected elements
inA=insertAfter()	//Inserts HTML elements after selected elements
inB=insertBefore()	//Inserts HTML elements before selected elements
pp=prepend()	//Inserts content at the beginning of selected elements
ppT=prependTo()	//Inserts HTML elements at the beginning of selected elements
ps=position()	//Returns the position (relative to the parent element) of an element
tt=text()	      //Sets or returns the text content of selected elements
tgCl=toggleClass() //Toggles between adding/removing one or more classes from selected elements
uWr=unwrap()	  //Removes the parent element of the selected elements
wr=wrap()	      //Wraps HTML element(s) around each selected element
wrA=wrapAll()	  //Wraps HTML element(s) around all selected elements
wrI=wrapInner()	  //Wraps HTML element(s) around the content of each selected element
att=attr()	//Sets or returns attributes/values of selected elements
aCl=addClass()	//Adds one or more class names to selected elements
cl=clone()	//Makes a copy of selected elements
css()	//Sets or returns one or more style properties for selected elements
pop=prop()	//Sets or returns properties/values of selected elements
hCl=hasClass()	//Checks if any of the selected elements have a specified class name
HT=html()	//Sets or returns the content of selected elements

wd=width()	//Sets or returns the width of selected elements
ht=height()	//Sets or returns the height of selected elements
os=offset()	//sets or returns the offset coordinates for selected elements (relative to the document)
osP=offsetParent()	//Returns the first positioned parent element
outH=outerHeight()	//Returns the height of an element (includes padding and border)
outW=outerWidth()	//Returns the width of an element (includes padding and border)
inHinnerHeight()	//Returns the height of an element (includes padding, but not border)
inWinnerWidth()	//Returns the width of an element (includes padding, but not border)

scrL=scrollLeft()	//Sets or returns the horizontal scrollbar position of selected elements
scrT=scrollTop()	//Sets or returns the vertical scrollbar position of selected elements


dt=detach()	    //Removes selected elements (keeps data and events)
emp=empty()	        //Removes all child nodes and content from selected elements
rm=remove()	    //Removes the selected elements (including data and events)
rmAt=removeAttr()	//Removes one or more attributes from selected elements
rmCl=removeClass()	//Removes one or more classes from selected elements
rmP=removeProp()	//Removes a property set by the prop() method

rpA=replaceAll()	//Replaces selected elements with new HTML elements
rpW=replaceWith()   //Replaces selected elements with new content

vl=val() //Sets or returns the value attribute of the selected elements (for form elements)
