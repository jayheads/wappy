
 rst=function(){
ball={x:1, y:0, vx:0, vy:0}}
 rst()


 updateBall=function(){
    //ball.x+=ball.vx
   ball.y+=ball.vy
    ball.vy +=.04
 }

drawBall=function d(px, py){
    px=px||ball
    if(O(px)){return d(px.x, px.y)}
    x('b')
    sir(x,px,py,2)
    x('f')}


loo=function(){

    updateBall()
    x.X()
    x('b')('m',0,500)('l', 300,600)('s')
    drawBall()

}
