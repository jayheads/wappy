G$=function(a){return new C$.Graphics(a)}
sG=function(g){g=G(g);
    g.c=function(x,y,r,f,s){H(function(g,h){o.a(h);
        g.f(f||'white').s(s||'black').dc(x||100,y||100,r||4)})}
    g.s=function(x,y,z,r){var g=G(o);z=z||_.r(300);
        g.f(r||COLOR[_.r(8)]).r(x||_.r(800),y||_.r(300),z,z).D()}
    g.c2=function(x,y,r,f,s){var g=G(o);
        g.s(s||'black').f(f||'red').dc(x||100,y||100,r||100).D()};


    g.rrH=function(){o.o(function(g){  g.f('blue').dc(_.r(800),_.r(300),_.r(100))}) }

    g.rH=function(){c(function(g){g.f('blue').dc(_.r(800),_.r(300),_.r(100))})}
    g.dc3=function(x,y,r,f,s){
        H(function(g,h){
            o.a(h); g.f(f||'white').s(s||'black')
                .dc(x||100,y||100,r||4)})}
    g.Q$=function(x,y,z,r){var g=G(o);
        z=z||_.r(300);
        g.f(r||COLOR[_.r(8)])
            .r(x||_.r(800),y||_.r(300),z,z)
            .D()}

    g.O=function(x,y,r,f,s){
        var g=G(o);
        g.s(s||'black').f(f||'red')
            .dc(x||100,y||100,r||100).D()};
    g.oo=function(a,b){
        var ,h=H();o.a(h);
        if(S(a)){h.g.f(a)};
        if(F(a)){a(h.g,h,t)};
        if(F(b)){b(h.g,h,t)};
        return h}
    g.easelCircle=function(a,z){
        var ,z=(z||0)*100,g=G(t);g.f(a)
            .dc(z,z,20).d();
        return o }
    return g}
G=function(g){var g=G$();
    g.d=function(){g.draw(o.d)};
    return g}


H$=function(a){return C$.Shape(a)}
sH=function(h){
    h.c=function(){
        o.h(function(g){g.f('blue').dc(_.r(800),_.r(300),_.r(100))})}
    h.rc=function(){
        h.c(function(g){g.f('blue').dc(_.r(800),_.r(300),_.r(100))})};
    return h}
H=function (a,b,c){var h;
    if(O(a)){h=H$(a)} else{h=H$()};
    h=sH(sDo(h));
    h.g=h.graphics;
    if(S(a)){h.g.f(a)};
    if(S(b)){h.g.f(b)};
    if(F(a)){a(h.g,h)};
    if(F(b)){b(h.g,h)};
    if(F(c)){c(h.g,h)};
    if(C(b)){b.s.a(h)};
    return h}
o.shape =function(a,b){var h=H();o.a(h);
    if(S(a)){h.g.f(a)};
    if(F(a)){a(h.g,h,t)};
    if(F(b)){b(h.g,h,t)};
    return h}
$.dc=function(x,y,r,f,s){

    H(function(g,h){o.a(h);
        g.f(f||'white').s(s||'black')
            .dc(x||100,y||100,r||4)})

}
o.circ=function(x,y,r,f,s){var g=Gx(c);
    g.s(s||'black').f(f||'red').dc(x||100,y||100,r||100).D()}
o.Q$=randCirc=function(x,y,z,r){     //random
    var g=G(c);z=z||Rand(300);g.f(r||co()).r(
        x||Rand(800),
        y||Rand(300),
        z,z).D()}


o.rrHQuest=function(){
    on(function(g){

        g.f('b').dc(
            _R(800), _R(300), _R(100)
        )

    })}

o.rH=function(){o.shape(function(g){g.f('blue').dc(_.r(800),_.r(300),_.r(100))})}

s.aH=function(a,b,c){var ,h=H();
    o.a(h);
    if(S(a)){h.g.f(a)};
    if(F(a)){a(h.g,h,t)};
    if(F(b)){b(h.g,h,t)};
    return h}

C$.t=C$.Text;
txt=function(a,x,y,z,r){o.t();
    var tt=new cj.t(a||"YANO", z||"50px ariel", r||"blue");
    to.textBaseline="alphabetic";
    to.x=x||100;
    to.y=y||100;
    o.a(tt);return ot}
D$=C$.DOMElement;



G$=function(a){return new C$.Graphics(a)}
H$=function(a){return C$.Shape(a)}
D$=C$.DOMElement;
C$.t=C$.Text;

sG=function(g){g=G(g);
    g.c=function(x,y,r,f,s){var t=this;H(function(g,h){t.a(h);
        g.f(f||'white').s(s||'black').dc(x||100,y||100,r||4)})}

    g.s=function(x,y,z,r){var g=G(this);z=z||_.r(300);
        g.f(r||COLOR[_.r(8)]).r(x||_.r(800),y||_.r(300),z,z).D()}

    g.c2=function(x,y,r,f,s){var g=G(this);
        g.s(s||'black').f(f||'red').dc(x||100,y||100,r||100).D()};


    g.rrH=function(){
        this.o(function(g){
            g.f('blue')
                .dc(_.r(800),_.r(300),_.r(100))})
    }

    g.rH=function(){
        c(function(g){g.f('blue')
            .dc(_.r(800),_.r(300),_.r(100))})}

    g.dc3=function(x,y,r,f,s){var t=this;
        H(function(g,h){
            t.a(h);
            g.f(f||'white').s(s||'black')
                .dc(x||100,y||100,r||4)})}

    g.Q$=function(x,y,z,r){var g=G(this);
        z=z||_.r(300);
        g.f(r||COLOR[_.r(8)])
            .r(x||_.r(800),y||_.r(300),z,z)
            .D()}

    g.O=function(x,y,r,f,s){
        var g=G(this);
        g.s(s||'black').f(f||'red')
            .dc(x||100,y||100,r||100).D()
    };
    g.oo=function(a,b){
        var t=this,h=H();t.a(h);
        if(iS(a)){h.g.f(a)};
        if(iF(a)){a(h.g,h,t)};
        if(iF(b)){b(h.g,h,t)};
        return h
    }
    g.easelCircle=function(a,z){
        var t=this,z=(z||0)*100,g=G(t);g.f(a)
            .dc(z,z,20).d();
        return t }
    return g}

sH=function(h){
    h.c=function(){
        this.h(function(g){g.f('blue').dc(_.r(800),_.r(300),_.r(100))})}
    h.rc=function(){
        h.c(function(g){g.f('blue').dc(_.r(800),_.r(300),_.r(100))})};
    return h}

G=function(g){
    var g=G$();
    g.d=function(){
        g.draw(c.d)};
    return g}

H=function (a,b,c){var h;
    if(O(a)){
        h=H$(a)}
    else{h=H$()};
    h=sH(Do(h));
    h.g=h.graphics;
    if(S(a)){h.g.f(a)};
    if(S(b)){h.g.f(b)};
    if(F(a)){a(h.g,h)};
    if(F(b)){b(h.g,h)};
    if(F(c)){c(h.g,h)};
    if(C(b)){b.s.a(h)};
    return h}

txt=function(a,x,y,z,r){c.t();
    var tt=new cj.t(a||"YANO", z||"50px ariel", r||"blue");
    tt.textBaseline="alphabetic";
    tt.x=x||100;
    tt.y=y||100;
    c.a(tt);return tt}



boxxOfWonder=function (w,h,p){var l=25,cols= 7,b=H();
    c.t();w=w|100;h=h|100;p=p|10;
    b.g.bf("#FF0099").dr(0,0,w,w).ef();
    for(var i=0;i<l;i++){var bC=b.clone();
        bC.x=(w)*(i%cols);
        bC.y=(h+p)*(i/cols|0);
        bC.index=i;
        bC.$(function(e){$l(e.target)})
        c.a(bC)}}

question=function(m){g=G(c);SI(function(){g.q()},ms=m||1000)}

}
