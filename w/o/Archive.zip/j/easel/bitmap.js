

vb=function(im,fn,z){
    Im(im,
        function(i){
            Im(fit(cV(z),i).toDataURL(), fn)
        })}


Bm=function(a,b,z){
    if(I(a)){return B$(a)}

    Im(a, function(i){

        var bm=Do(B$(i));
        if(F(b)){b(bm)}
        else{$w[b]=bm}});

    return a}




s.b=function(a,f,v,p,F){
    //a=a||t;
    if(v!==undefined){v=$V(v);if(v.x<=10){v.x*=100};
        if(v.y<=10){v.y*=100}}
    if(p==='c'){p=[(o.w()-v.x)/2,(o.h()-v.y)/2]};p=$V(p);
    B(a,function(b,t){
        b.x=p.x;b.y=p.y;$do(b,f);o.a(b);
        _.e(F,function(f){b[f]()})},v);
    return o}



o.b=function(a,f,v,p,F){
    var a=a||o;
    v=$V(v);if(v.x<=10){v.x*=100};if(v.y<=10){v.y*=100};
    if(p=='c'){p=[(o.w()-v.x)/2,(o.h()-v.y)/2]};p=$V(p);

    if(!a.indexOf('/')==0)a='/'+a;
    if(a.indexOf('.')<0){a+='.png'}

    B(a,
        function(b){
            o.a(b);b.x=p.x;b.y=p.y;
            o.U();sr(b,f);
            _.e(F,function(f){b[f]()})
        },v);return o}






s.bF=function(a,pc,f){
    pc=pc||1//?
    o.b(a,{x:o.w()*pc,y:o.h()*pc},f);
    return o}
o.bf=function(a,pc,f){
    pc=pc||1
    o.b(a,
        {x:o.w()*pc, y:o.h()*pc}, f);
    return o}
o.bmFit=function(a,pc,f){pc=pc||1//?
    o.b(a,{x:o.w()*pc,y:o.h()*pc},f);return o}
o.bm=function(a,f,v,p,F){a=a||o;

    v= $V(v);

    if(v.x<=10){v.x*=100}; if(v.y<=10){v.y*=100};

    if(p=='c'){   p=[(o.w()-v.x)/2,(o.h()-v.y)/2]    }

    p = $V(p);


    B( src(a),

        function(b){
            o.a(b);
            b.x=p.x;  b.y=p.y;

            o.U();

            sr(b,f);

            _.e(F,
                function(f){b[f]()})
        },
        v);

    return o}
tB=function(a){ if(Im(a)){a=B$(a)};
    if(iB(a)){a=Do(a);
        a.i=a.image};return a};


xB=function f(a,b,c,d){

    if(c){
        Im(a,function(i){

            x.fD(i);
            f(c,b,null,d)
        });return}

    if(Im(i)){if(i.src){return $do($do(tB(a),b),d)}}

    Im(a,function(i){f(i,b,null,d)});

    return}



B=function(a,b){
    Im(a,function(i){

        var bm=Do(B$(i));

        if(O(b)){b.addChild(b)};
        if(S(b));$w[b]=bm;
        if(F(b)){b(bm)}

    })}


B2=function(a,s){
    Im(a,function(i){b=sDo(B$(i));
        if(s){s.addChild(b)}})}

BM=function(a,f,v,n){
    function b(a,p){
        if(Im(a)){
            a=new B$(a)};

        if(B(a)){
            a=sB(a)}
        return a}

    function iU(a){
        return !iB(b(a))}

    if(v){Im(a,function(i){  B(C(v).f(i), f, null,n)})}

    else if(iU(a)){

        Im(a,function(i){
            B(i,f,null,n)})}

    else{return sr(  sr( b ( a ), f),  n  )}}//nLoad=function(a){return !iB(tB(a))}




cb=function(a,f,v,p,F){
    var t=this;a=a||this;
    v=$V(v);if(v.x<=10){v.x*=100};if(v.y<=10){v.y*=100};
    if(p=='c'){p=[(t.w()-v.x)/2,(t.h()-v.y)/2]};p=$V(p);

    if(!a.indexOf('/')==0)a='/'+a;
    if(a.indexOf('.')<0){a+='.png'}

    B(a,
        function(b){
            t.a(b);b.x=p.x;b.y=p.y;
            t.U();sr(b,f);
            _.e(F,function(f){b[f]()})
        },v);return this}




s.percent=function(a,b,c){var ,b=b||1;
    o.b(a,{x:o.w()*b,y:o.h()*b},c);
    return o};



zzFuckYouImGonnaSolveYouBuddy=function(){
    B(p('me'),
        function(b){
            c.a(b);
            c.t();
            rtc(b)},
        400,'b');
    c.T();
    c.emo(10);

}