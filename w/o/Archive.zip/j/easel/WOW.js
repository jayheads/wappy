
anim=function(){
    sAN=function(a,b){a=sDo(a)
        gS="gotoAndStop",gP="gotoAndPlay",sPa="setPaused",sPo="setPosition";
        a.p=function(a,b){var t=this;
            if(t[sPa]) {t[sPa](false)} else {t.play()}
            if(b!==undefined){
                if(t[gP]) {t[gP](a)}
                if(t[sPo]) {t[sPo](a,b)}
                return t}}
        a.s=function(a,b){var t=this;
            if(t[sPa]) {t[sPa](true)} else {t.stop()}
            if(b!==undefined){
                if(t[gS]) {t[gS](a)}
                if(t[sPo]) {t[sPo](a,b)}
                return t}}
        return t}
    sSp=function(s){s=sAN(s);
        s.gt=function(){var t=this;
            return {
                a: t.getAnimation(),
                A: t.getAnimations(),
                f: t.getFrame(),
                fb: t.getFrameBounds(),
                nf: t.getNumFrames(),
                fr: framerate}}
        s.$$$=function(a){t.on('complete',a)}
        return s}
    sTW=function(W){W=sAn(W)
        W.pos=function(a,b){var t=this;
            if(a===undefined){return t.position}
            setPosition(a,b);return t}
        W.iGP=function(a){var t=this,iGP="ignoreGlobalPause";
            if(a===undefined){return t[iGP]}
            t[iGP]=a;return t}
        W.dur=function(a){var t=this,d="duration";
            if(a===undefined){return t[d]}
            t[d]=a;return t}
        W.lp=function(a){var t=this;
            if(a===undefined){return t.loop}
            t.loop=a;return t}
        return W}
    sTw=function(w){w=sTW(w)
        w.cl=w.call; w.gt=w.get; w.wt=w.wait;w.st=w.set;
        w.tw=function(a){var t=this;
            if(a===undefined){return t.hasActiveTweens }
            return t}
        w.rm=function(a){
            var t=this;
            if(a===undefined){t.removeAllTweens }
            t.removeTweens(a);
            return t}
        w.tg=function(){return this.target}
        w.tk=function(a,b){this.tick(a,b);return this}
        return w}
    sTl=function(l){l=sTW(l);
        l.ad=function(a,b){var t=this;
            if(iS(a)){t.addLabel(a,b)}
            if(iO(a)){t.addTween(a,b)}
            return t}
        l.cL=function(){return t.getCurrentLabel()}
        l.lb=function(a){var t=this;
            if(a===undefined){return t.getLabels()}
            if(iO(a)){t.setLabels(a);return t}
            if(iN(a)||iS(a)){return resolve(a)}
            return t}
        l.rm=function(a){this.removeTween(a);return this}
        l.uD=function(a){var t=this;
            if(a===undefined){t.updateDuration()}
            if(iN(a)){t.tick(a)}
            return t}
        return l}
    sMc=function(m){var t=this,m=sAN(sCt(m));
        m.tl=sTl(m.timeline);
        m.lb=m.getLabels;m.cL=m.getCurrentLabel;

        m.sP=function(a){var t=this,sp="startPosition";
            if(a===undefined){return t[sp]}; t[sp]=a;return t}

        m.mo=function(a){var t=this;
            if(a===undefined){return t.mode};t.mode=a;return t}

        m.lp=function(a){var t=this;
            if(a===undefined){return t.loop};t.loop=a;return t}

        m.aR=function(a){var t=this,r="autoReset";
            if(a===undefined){return t[r]};t[r]=a;return t}

        m.aE=function(a){var t=this,e="actionsEnabled";
            if(a===undefined){return t[e]};t[e]=a;return t}

        return m}}

bop=function(a){bod.prepend(a);return a}
fit =function rc(can,img,x,y){x=x||0;y=y||0;
    if(I(img)){Xx(can).drawImage(img,x,y,can.width,can.height)}
    else{Im(img,function(i){rc(can,i,x,y)})}
    return can}
drit=function(a,b){return fit(cV(b),a||'me')}

hilarious=function(){keep(function(){ bop(drit('me',.5))},.03)  }





movie=function(){
$l('movie')
var c, stg, expRt;
function init() {

    images = images||{};



    var q = lQ();
    q.fl(handleFileLoad);
    q.oc(handleComplete);
    q.lm([{src:"images/background.png", id:"background"},
        {src:"images/flashlogo.png", id:"flashlogo"}])
}
handleFileLoad=function(e) {
    if (e.item.type == "image") {images[e.item.id]=e.result}
}
handleComplete() =function{

    expRt = new lib.bubbles4();

    stg=St(c);
    stg.a(expRt);
    stg.u();
    T$.setFPS(30);
    T$.ael("tick", stg);
}

  }





//game
    pntInCir=function(x,y,c){
        var X=c.x, Y=c.y, R=c.r;
        return x<X+R&&x>X-R&&y<Y+R&&y>Y-R}
    wrp=function(a,b,c){c=c||0;
        return function(d){
            if(d<a){d=b-c}
            if(d>b){d=a+c};
            return d}}
    cap=function(a,b,c){c=c||0;
        return function(d){
            if(d<a){d=a-c};
            if(d>b){d=b+c};
            return d}}







$(function(){
    c=C(500,'blue').pp()

    c.T();
    T.p();
    B('guy',
        function(a){
            c.a(g=a);g.x=200;g.y=200;
            O(function(){
                g.scaleX-=.001
                g.scaleY-=.001
                g.x+=.5
                g.y+=.5
            })
        })


})

