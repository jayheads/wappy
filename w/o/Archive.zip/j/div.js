dv=function(s,h,l,t){var g=G(arguments),
    d=ss(_dv(),this.s)
    if(N(l)){ s={ w:s,  h:h, T:t||l, L:l}}
    else if(N(s)){s={w:s, h:h||s}}
    if(O(s)){ss(d, s)}
    if(g.N){tB(d)}
    oK.C(d)
    return qq(d)}

dv.s={P:'a',   m:10,   p:10,
    C:$r('c'),c:$r('c'),
    w:600,  h:600}



ldv=function(T){
    return dv({C:'z',c:'w', ta:'c',
        w:200,h:120,
        L:650,T:T||10})}


el.ab=abd=function (l,w,c){

    var q=qq(_dv())
    q.s({P:'a',T:100, L:l, w:w||100,
        h:100, C:c||'L'})
    q.a(); return q}




el.B=bns=function bn(o){$('button').remove()
    $(function(){_t(26,
        function(i){o=ob(o)
            var w=mF(wO()/26),
                b=qq(BTN,
                    {w: o.z||w, h: o.z||w,
                        c: o.c||$r('c'),
                        C: o.C||$r('c')})
            b.ht(i)
            b.$(o.f||function(e){ss(e,{C:$r('c')})})
            b.pt()})})}

el.P=ico=function(){
    var z=mF(wO()/26)
    $('img').remove()
    im('me',function(i){
        _t(50, function(){
            picBox.ae( clo(i,{h:z,w:z,m:4}) )})})}


el.d=_dv=function(){return $t('d')}
div=function dv(r,hW,t,pM){var g=G(arguments)
    if(!S(r)){return dv($r(),r,hW,pM)}
    var c=em('d'),w,h
    if(A(hW)){
        h=hW[0];
        w=hW[1]||h}
    if(N(hW)){h=hW}
    h=h||50
    ss(c, {C:r, h:h,m:80,p:80})
    if(N(w)){ss(c,'w',w)}
    if(S(t)){c.text(t)}
    if(g.N){tT(c)}
    //if(a==="<"){c=tT(f(b,c,d))}
    //if(a===">"){c=tB(f(b,c,d))}
    //c.h=oH(c)
    //c.x=X(c)
    return qq(c)}

el.simp=function s(q,c,w,h,t){
    if(!A(q)){return ss(q,{C:c, w:w, h:h}).appendTo(t)}
    _e(arguments,function(a){
        _a(s,a)})}

el.al=function al(){var b=_dv()
    ss(b, {C:'gr', w:500, p:50, h:550})
    simp([_dv(),'C',400,400, b],
        [_ip('t'),'y',350, 50, b],
        [$('<button>'), 'b',50,50, b])
    return tT(b)}






$(function(){   if(0){
    bns()
    // oZ(bns)
    picBox=qq(DV, {
        w:wO()/(5/2), nh:200,
        mh:1000, C:'!',m:0, p:0})
    picBox.at()}})

