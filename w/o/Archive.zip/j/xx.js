xP=function(a){return $p('X',X(a))}
xM=function(a){return $m('x',X(a))}
xx=function xx(c){//if(F(c)){return c}

    var x,g=G(arguments)
    if(!O(c)){c=_a($c, g)}

    x = function x(a,b){var g=G(arguments)
        if(F(a)){return a}
        if(A(a)){return x.p(a[0])}
        if(O(a)){x.p(g.f);
            if(!b){return x.x}
            x.res=_a(x.m,g.r,x);
            return x}
        x.res=_a(x.m,g);
        return x}

    x.x  =X(c)
    x.c  =x.x.canvas //x.e=x.q[0]
    x.q  =$(x.c)
    x.qq =qq(x.c)
    x.p  =xP(x.x)
    x.m  =xM(x.x)

    x.d  =function(i){var g=G(arguments);
        im(i,function(i){g[0]=i;_a(x.dI,g)})}
    x.u  =function(){return tDU(x.c)}   //x.img=x.u();
    x.w  =function(w){var g=G(arguments)
        if(U(w)){return _w(x.c)}
        if(g.N){var u=x.u()}
        _w(x.c, w)
        if(g.N){x.fit(u)}
        return x}
    x.h  =function(h,z){
        if(!h){return _h(x.c)};
        if(!z){var u=x.u()};
        _h(x.c, h)
        if(!z){x.fit(u)};
        return x}
    x.l  =function(n){if(!n){return osL(x.q)}
        return pI(n-x.l())}
    x.t  =function(y){if(!y){return osT(y.q)}
        return pI(y-x.t())}

    //x.s  =function(){return xS(x.x)}
    //x.r  =function(){return xR(x.x)}

    x.X  =function(){x.x.clearRect(0,0,x.w(),x.h());return x}




    x.dI=function(i){
        var g=G(arguments)
        g[1]=g[1]||0;
        g[2]=g[2]||0
        _a(x.m, _c('d',g))}
    x.img=_i()

    x.fit=function f(a,X,Y){
        x.d(a, X||0,Y||0, x.w(), x.h())
        return x}
    x.wh=function(w,h){if(!w){
        return $V(x.w(),x.h())};
        var u=x.u();
        x.w(w);x.h(h||w);
        x.fit(u); return x}
    x.copy=function(){x.img.src=x.u();return x} //o.copy();
    x.pasteOver=function(){x.X();x.dI(x.img)}
    x.replace=function(){x.X();x.d(x.img)}
    x.pasteFit=function(){x.fit(x.img,0,0)}
    x.fr=_p(x.m,'fr')
    x.rt=_p(x.m,'rt')
    x.sc=_p(x.m,'sc')
    x.tr=_p(x.m,'tr')
    x.gD=function(x,y,w,h){return x('gi',x||0,y||0,w||o.w(),h||o.h())}
    x.pD=function(d,x,y){return x('pi',d,x||0,y||0)}
    x.gP=function(c,d){return x.pD(x.gD(c),d)};
    return x}
