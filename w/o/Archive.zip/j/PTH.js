

tictactoe=[[[200,0],[200,600]],[[400,0],[400,600]],[[0,200],[600,200]],[[0,400],[600,400]]]
tttX=[
    [200,0],[200,600],[400,0],[400,600],[400],[],[],[]

]


randomLines=[[[1,1],[2,2]],
    [[0,3],[3,3],[0,2]],[],[]]




p1=function(a,b){  //same as pth but *100
  bG=function b(c,p1,p2){var g=G(arguments),x=xx(c)
        if(U(p1)){return _p(b, c)}
        if(A(p1)){return b(c, p1[0], p1[1])}
        if(g.N){x('b')}
        x('m', p1||0, p2||0)
        return _p(lT,c)}
    lT=function l(c,p1,p2){
        var x=xx(c),g=G(arguments)
        if(U(p1)){return _p(l, c)}
        if(N(p1)){return l(c,[p1,p2])}
        if(A(p1[0])){return _a(l(c),p1)}
        _e(g.r, function(v){
            x('l', v[0], v[1])})

        if(g.N){x('s')}
        return _p(bG, c)}
    sub=function s(c,p1){
        if(U(p1)){return _p(s, c)}
        var g=G(arguments), x=xx(g.f),  pts=g.r
        if(g.n){lT(x,pts)}
        else{bG(x, _f(pts));lT(x, _r(pts))}
        return _p(s, g.f)}


    pth=function(a,b){
        var pat=function p(c,d){
                var g=G(arguments),s=sub(c)
                _e(_r(g),function(sp){_a(s,sp)})},
            Pth=function(x,P){

                _e(P,function(p){ pat(x,p)})}
        var g=G(arguments),f
        if(b&&b[0]){
            f=N(b[0][0])? pat: Pth
            return _a(f,g)}}






    var pat=function p(c, d){
            var g=G(arguments), s=sub(c)
            _e(_r(g),function(sp){
                _a(s, rc100(sp))})},


        Pth=function(x,P){
            _e(P,function(p){pat(x,p)})}

    var g=G(arguments),f
    if(b&&b[0]){
        f=N(b[0][0])? pat: Pth
        return _a(f,g)}}





ppppp=function p(c,a,b,d){//if(F(c)){return c}
    //if(c.x){c=c.x}
    var p=xx(c, a,b,d)
    p.pX=0
    p.pY=0
    p.sX=function(n){p.pX=n;return p}
    p.sY=function(n){p.pY=n;return p}

    p.ss=function(r){p({ss:$r('c',r)});return p}
    p.b=function(){p('b'); return b}
    p.bC=function(r){bC(p.x, r||'V')}
    p.tt=function(r){
        p.lin([0,0],[p.w(),p.h()])
        p.lin([0,p.w()],[p.h(),0])
        p.str(r||'o')}
    p.str=function(r){
        if(r){p.ss(r)}
        p('s')}

    p.com=function(){
        _e(arguments,function(b){
            if(!A(b)){b=[b]}
            _a(p,b)})
        return p}
    p.lin=function(a,b,c,d){
        var p1=a,
            p2=b
        return p.com(
             'b',
           ['m', p1[0],p1[1]],
           ['l', p2[0],p2[1]],
             's')}



    p.ball=function(b){
        b=b||{}
        var dir = b.d||false,
            px  = b.x||100,
            py  = b.y||100,
            rad = b.r||100,
            per = b.p||Math.PI* 2,
            ss = $r('c', b.s) ,
            fs = $r('c', b.f),
            lw = D(b.l)? b.l: 4

       return p.com(
           'b',['a',px,py,rad,0,per,dir],
           {fs:fs,ss:ss,lw:lw},'f','s'
       )}
    p.cir=function(X,y,r, s,f, l){
        if(U(l)){l=_r(20)}

        x('b')

        x('a',
            X||100, y||100, r||100, 0,
            Math.PI*2, false)

        f=$r('c', f)
        s=$r('c', s)
        //cL(f)
        // cL(s)
        x({fs:f,  ss:s,  lw:3})
        x('f')
        x('s')
        return x}

    return p}



clrRect=function(cv,a,b,c,d){
    var g=G(arguments),x=xx(cv)
    if(U(a)){x.X(0,0,x.w(),x.h());
        return x}
    if(N(a)){x.X(a, b||a, c||200, d||c)}}
tCl=function(n1,n2,n3,n4){var s
    if(!n2){s=$r('c',n1)}
    else {s="rgba("+n1+","+n2+","+""+n3+","+n4+")"}
    return s}
cleanFillRect=  function(c){var g=G(arguments),x=xx(c)
    if(U(a)){return o.X()
    x('s')
    x({fs: _a(tCl,g.r)},'fr',0,0,x.w(),x.h())
    x('r')
    return x}  }

pIP=function(c,a,b){
    var x=xx(c), g=arguments;
    return x('ip',a,b)}
curve=function f(c){
    var g=G(arguments),  x=xx(c)
    var fn=_z(g)>4? 'q':'z'
    xM(x)(_c(fn, _r(g,2)))
    return _p(f,x)}
cif=function(x,y,r){ o.a(x,y,r,0,PI2,false);   o.f().k();return o}

line=function l(c,L,nArr){
     var g=G(arguments)
     if(nArr){L=g.r}

     var x=xp(c)

     _e(L,function(v){x('l',v[0],v[1])})
        x('s')

     return x}
mT=function(x){  var g = G(arguments), m,p0,c

    c  = xx(x)

    m  = xM(shf(g))
    p0 = shf(g)
    var g= _r(arguments), p

    if(O(g[0])){
        p=shf(g)}


    p = p || {ss:'y', lw:5}


    if(p ){
        x('m',
            p[0], p[1])}   //if p, move to

    m('m',
        p0[0],p0[1])


    _e(g,
        function(v){   x('l', v[0],   v[1])})

    x(p, 's')
    return x}
to=function(a,b,c){if(N(b)){o.m('l',a,b)}
    if(N(c)){o.m('a2',arguments)}}
pth=function(o,a,b,c,d){
    var x=xM(o), g=arguments
        if(N(b)){x('l', a,b)}
        if(N(c)){x('a2', a,b)}
        if(U(a)){x('b'); return o}
        if(a==='0'){return o('c')}
        if(a==='!'){return o('j'||'clip')}
        if(d){return o('r', g)}//x.rect(a,b,c,d)}
        return o('m',a,b)}

stroke=function(x){
    x.x=xx(x)
    x.s=function(a,b,c,d){
    if(U(a)){x('s');return x}
    if(S(a)){if(b){
        return o.y('c',
            LN[0][a]).y('j',LN[1][b])};
        return o.y('s',a)}
    else{if(N(d)){x('sr',a,b,c,d)}
    else if(N(c)){x('st',a,b,c)}
    else if(N(b)){x.t(a,b)}
    else{x.y('w',a)}  }
    return x}


setSty=function(a,b){
    fS=function(c){return _p(xP(c),'ss')}
    sS=function(c){return _p(xP(c),'ss')}


    var o={}
    if(U(a)){a='!'}

    o.fs=a

    if(!U(b)){o.ss=b}
    return o}
    o={
        'D(d)' :  'fillrect',
        'D(c)' :  'filltext',
        'U(a)' :  'fill',
        'U(a)' :  'close',
        'D(b)' :  'stroke'}
    if(!N(w)){fS(x,w); return fR(x,h,c)}
    xM(x)('fr',0,0,w||400,h||200)}





cir=function s(x,X){x=xx(x)
    var g=G(arguments),
        cw= g.n? true : false
    if(U(X)){return _p(s,x)}
    if(A(X)){ return _a(s(x),X)}
    ////
    if(g.p){x('b')}

    x('a',
        g[1]||100,
        g[2]||100,
        g[3]||90,
        g[4]||0,  g[5]||p2,
        cw)('s')


    return s(x)}




a2  =function s(x,X){x=xx(x)
    var g=G(arguments)
    if(U(X)){  return _p(s,x)}
    if(A(X)){  return _a( s(x), X)}
    if(g.p){x('b')}
    x('a2',
        g[1]||50,
        g[2]||40,
        g[3]||100,
        g[4]||100,
        g[5]||30)('s')

    return s(x)}
rect=function s(x,X,Y,W,H){
    var g=arguments;x=xx(x);
    if(U(X)){return _p(s,x)}
    if(A(X)){return _a(s(x),X)}
    x('r', X||100, Y||100,
        W||100, H||100
    )('s')
    return s(x)}




drX=function(a,b){return [   [[a,a],[b,b]], [[b,a],[a,b]]      ]}

cutOut=nonZeroWindingRule=function(x,a,b){
    a=a||[200,200,100,20]
    b=b||[200,200,200,40]
    cir(x,a)
    cir(x, b.concat('-'))
    x('f')

}







//x.cP=function(y,d){return x.p(cD(y.g(),d))}



//$(function(){
//  a=can('green');c = sC(a);
//  Im('me', function(i){ o.di( i,0,0, o.w(),o.h() ) ; o.fit(i)  })})
//pr={};
// pr.d = function(i){
// Im(i,function(i){ xx(this)('d',i,0,0)}) }

//  return aCS(gr,a,b)}


//sun(bx,200,250,2)//bx is q[c]

//   _aCS(g,  b?b/10:0,  $r('c', c)); return _p(s, g)}



