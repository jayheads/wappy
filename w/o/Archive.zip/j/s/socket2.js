l('k');k=io.connect('http://localhost');k.e=k.emit; k.o=k.on;





function moveFace(){
    $('#up').click(function(){k.emit('face','up')});
    $('#down').click(function(){k.emit('face','down')});
    $('#left').click(function(){k.emit('face','left')});
    $('#right').click(function(){k.emit('face','right')})     }




Gs={};gone=lopper(Gs);

eG();
//k.on('eG',eG);  //k.e('eG');
function eG(){k.e('eG')};


//m={moe:{x:20,y:100},larry:{x:20,y:130},curly:{x:20,y:10}};//ups=upsert, p=player, gIM=guyInMap    //eg=enterGame //c=coords, l=l  m=GsM
$('#up').cl(function(){k.e('mG','u')}); $('#down').cl(function(){k.e('mG','d')});
$('#left').cl(function(){k.e('mG','l')});$('#right').cl(function(){k.e('mG','r')});

k.on('mU',function(m){uM(m)})// uM(m);
k.on('map',function(m){uM(m)})



function uM(m){$d(m);
    //2step process for client to update map based on server new-map push
    _.e(Gs,function(c,n,l){if(!m[n]){gone(n);l('rm:'+n)}})
    _.e(m,function(c,n){ups({n:n,x:c.x,y:c.y})})}
//ups({n:'woah',x:1,y:1})//ups({n:'weirdo',x:30,y:40});ups({n:'moe',x:0,y:0});



k.e('warp')
//gx.me.y=f.y; gx.me.x=fc.x;  k.e('fc')
//function gIM(g,m){_.e(m,function(p){if(g.n==p.n){$l('+');return g} else{$l(g.n+':-');return false}};_.e(Gs,function(p){if(!(gIM(p,m))){c.s.rmvCh(Gs[p])}})
//function map(sGs){ _.e(mGs,function(g){if(!sGs[g.un]){c.s.rmvCh(g)}}); _.e(sGs,function(g){if(mGs[g.un]){mGs[g.un]}})}//mG=function(){k.e('mG')}
k.on('fc',function(fc){gx.me.x=fc.x;gx.me.y=fc.y})// k.e('fc')
k.on('fc',function(f){})
k.on('map',function(gA){_.e(gA,function(g){
    _.e(sArray,function(g){
        // text <==
    }}); c.a(p.me);
    p.me.x=200;p.me.y=100;p.me.x=f.x;p.me.y=f.y})
//a 'g' is {n:,x:,y:}, and mGys is an array of g's
// 1)  remv all Gs from myarray that are not in sArray
//  2) for _.e g in sArray,  if he is in mArray,
//  (a) update his position. if not, (b) addhim to mArray
//               OR
keep them as display objects, but just undisplay them.
    YES!  on map.. just hide all your display obs,
    and for guy in the guyArrray
update his coordinates and display him..
    but if he doesn't exist, create him'and add him to the stg
-or is it a matter of adding and removing from stg  ?

