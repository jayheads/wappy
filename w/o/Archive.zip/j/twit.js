
///
//tw bs
buttonClass=function(a){
    var A=ALERTS,Z=SIZES,s='btn';
    if(!a){return s}
    a=a.split('')
    s+=' btn-'+A[a[0]]
    if(a[1]){s+=' btn-'+Z[a[1]]}
    return s}

