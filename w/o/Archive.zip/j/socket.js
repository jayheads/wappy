l=function(a){return console.log(a)}
cD=function(a){return console.dir(a)}




socks=function(){l('k')
    var k=io.connect("http://localhost"),
        e=function(a,b){return k.emit(a,b)},
        o=function(a,b){return k.on(a,b)},
        b=function(a,b){return k.broadcast.emit(a,b)}


    o('al', function(a){alert(a+a)})

    o('l', function(a){ l(a) })
    o('d', function(d){ l('SERVER: %j', d) })

}


socks()