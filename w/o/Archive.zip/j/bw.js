


wh=function wh(a,b,c,d){
    if(N(a) && N(b) && N(c) && N(d)){
        return wh((a-c)/2, (b-d)/2)}
    a = G(a) || E(a) || a
    if(A(a)){return _a(wh,a)}

    //if just an el, give back a w/h pop-obj

    if(E(a)){if(U(b)){
        return {w:_w(a), h:_h(a)}}


        _w(a, _w(b,c))
        _h(a, _h(b,c))}


    if(O(a)){return {
        w:_w(a)||0,
        h:_h(a)|| _w(a)||0}  }

    return wh({w:a, h:b})}
siz=function(el, b, c){
    var g=G(arguments),
        q=Q(el),
        e=(q)[0],
        n=40

    if(C(e)){
        var u=tDU(e)
        aaWH(b, c)
        im(u, function(i){
            fit(X(e),i)})
        return q}// canvas resizing :)

    if(U(b)){
        return wh(
            _w(a)/n,
            _h(a)/n)}

    var z=wh(_r(g))
    _w(a, z.w*n)
    _h(a, z.h*n)
    return a} //setting




bw=function(a,b){
    if(a=='n'){return console.dir(navigator)}
    if(a=='c'){return b.close()}
    return $w.open()

}//windows
bw.l=function(o,b){  //window.location
    var g=G(arguments),
        l=location,
        O=function(a){return a===o}
    return  O('h')? l.href
        :O('hn')? l.hostname
        :O('#')? l.hash
        :O('H')? l.host
        :O('p')? l.port
        :O('pn')? l.pathname
        :O('P')? l.protocol
        :O('s')? l.search
        :O('@')? l.reload()
        :O('H')? l.host
        :U(o)? l
        :g.n? l.replace(o)  // doesnt create entry in history list
        :l.assign(o)}//location
bw.H=function(o,b){  // window.history
    var g=G(arguments),
        h=window.history,
        O=function(a){return a===o}
    return  O('l')? h.length

        :N(o)? h[o]
        :O('b')? h.back()
        :O('f')? h.forward()
        :O('g')? h.go(b)
        :h}//history
bw.w=function w(a,b){
    if(b==='a'){return screen.availWidth}
    if(b==='s'){return screen.width}
    if(b==='i'){return $(a||$w).innerWidth()}
    if(N(a)){return function(n){return n* w()/a}}
    return $(a||$w).outerWidth()}//dims
bw.h=function w(a,b){
    if(b==='a'){return screen.availHeight}
    if(b==='s'){return screen.height}
    if(b==='i'){return $(a||$w).innerHeight()}
    if(N(a)){return function(n){return n* w()/a}}
    return $(a||$w).outerHeight()}
bw.os=function(a,b,c){ //get/set offset values (top/left)
    if(U(b)){var o= a.offset()
        return {t:o.top,l:o.left}}
    if(N(c)){return os(a, {t:b,l:c})}
    return a.offset({top: b.t,left: b.l})}//offsets
//give it a w, gives u the L pos to place it at for it//to be centered (rel to CURRENT screen size)
bw.wc=function(w){return(bw.w()/2)-(w/2)}
//give it a w, and it tells u what percentage, that with is,// -- of the screen size
bw.p=function(l){return l/bw.w()*100}
bw.pL=function w(o, p){
    if(U(p)){return bw.w()*(o/100)}
    qq(o).w(w(p))}
bw.c=function(q,p){q=qq(q)
    if(p){bw.pL(q,p)}
    q.L(bw.wc( q.w() ))}
bw.sc=function(a){
    var d=_d()
    d.s=d.scrollTop
    return D(a)? d.s(a): d.s()}
bw.makeAllExtLinksOpenInNewWindows=function(){$("a[href^='http://']").attr('target','_blank')}
bw.bo=function(a,b){if(a==='p'){ss($('body'), {p:def(b,50)})}}
bw.X=clr=function(a){return $(a||'body').empty()  }
bw.pd=function(a){ss($('body'),{p:D(a)?a:50})}
bw.r=oZ=function(a){return $($w).resize(a)}






XX=function(a){$(a||'body').empty();return a}
oQ=function(){}
oQ.e=function(){
    qB=$('body');
    qW=$($w);
    qH=$('html')}
oQ.k=function(){
    qB.click(function(event){
        e=event})}
$(function(){oQ.e()
    oQ.k()})

