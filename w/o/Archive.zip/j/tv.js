

tv=function tv(a){
    if(U(a)){return $('.tv')}

    if(O(a)){ var t=tv()
        _e(t,   function(e){
        ss(e, a)})
    return t}

   // ss(t[1],{C:'r'})

    return qq(_dv(),{w:1500, h:30, m:50,
     C:a, ta:'c'}).H(
            "<h1>"+a+"</h1>"+oO('c',a))
        ._('tv')
        .a()}

$('.tv').width(200)

//cK=function(){return  K( oO('c')  )  }

$(function(){

    _e( K(oO('c')).sort(),

    function(v){
         cL(v)

        tv(v)

       // tv( oO('c')[v] )
    })


})

clr=function(){$('body').empty()}

z=function(c){



   var c

   ss( $('body') , {C:$r('c',c)} )





}

    $(function(){
        ss( $('div') ,    {D:'ib'}  )

        $('div').click(
         function(){

             ss( $(this) ,{c:$r('c')})
         }  )


$('body').click(
    function(){

        ss( $(this) ,{C:$r('c')})


})



    })