module.exports = function (q, p, n) { // {   messages: q.flash('info')   } //q.s.currentPage = q.s.lastPage;


    a.p('/security', function(q,p,n){l('security');  //l('q.body:'); d(q.body);  // q.s.u = null;    // login checking  // l('session: '); d(q.session);  q.s = {};   l('session: '); d(q.session);
            m.user.findOne(
                {username: q.body.username, password: q.body.password},
                function(err,user){
                    z(err);
                    if(!user){l('u?!');
                        q.flash('info', 'incorrect password!');
                        p.r('guest',{msgs: q.f('info')})}
                    else{l("great success!"); d(user);
                        q.s.u = user.username; q.s.l = true; d(q.s);
                        q.flash('info', 'you are awesome, ' + q.s.u + '!');
                        q.s.save(function(){p.d('back')}                     )}})})


    a.g ('/logout', MW.U, function(q,p, n) {l('logout');q.s.u = null; q.s.li= false; q.s.save(function(){p.d('back')})})  // IS MW.U NECESSARY HERE?




    a.p('/upload', MW.U, function(q,p,n){l('upload');

        var IMG=null, kind=null, dPATH;


        ImgOb = function(IMG, kind, PATH, userId){
            var name = path.basename(PATH);


            var relPath = '/pics/' + name;
            return {
                user:q.uid,                                    oldName:IMG.name,
                lMod:IMG.lastModifiedDate,   size:IMG.size,              kind: kind,
                name:name,                   ext:path.extname(PATH),
                fullPath:PATH,               relPath:relPath , url:'http://localhost:4000'+relPath
            }}


        d(q.files);

        if (q.files.pic) {
            IMG=q.files.pic;kind='pic';
            dPATH=path.resolve(IMG.path,
            '../../img/pic',
            path.basename(IMG.path))}


        if (q.files.cut) {IMG=q.files.cut;kind='cut'; dPATH=path.resolve(IMG.path,   '../../img/cut',   path.basename(IMG.path)) + '.PNG'}


        d(IMG);l(kind);l(dPATH);
        fs.readFile(IMG.path, function(z, da){
            fs.writeFile(dPATH, da, function(z){
                var imgOb = ImgOb(IMG, kind, dPATH, q.uid); d(imgOb);
                m.image.create(imgOb, function(err, imgId){
                    if(err){d(err);n(err)}
                    else {q.flash('info', 'file uploaded');l('saved');
                        m.user.findById(q.uid, function(z,user){
                            user.mugPath = ''; user.save(function(){

                                p.d('back')
                            })

                        })

                    }})})})})





    a.g ('/OK', MW, function(q,p, n) {p.r('lib/test/test')}   )

    a.g ('/', function(q,p, n) {p.redirect('/wappy')})



    a.g('/wappyX', MW, function(q,p,n){  if(q.s.u){


        m.user.findOne({username:q.s.u},function(err,user){

            if(err){  d(err)} else if(!user){l('account invalid?');   p.r('wappy-home-guest')}

            else{  p.l.mugPath=user.mugPath;  p.l.U=user; p.l.u=user.username;


                p.r('wappy-home-user', {U:user, msgs: q.f('info')})}})}
    else {p.r('wappy-home-guest', {msgs: q.f('info')}) }})






    a.g('/wap', function(q,p,r){ p.render('wappy-home-guest')}   )



    a.g('/users', function(q,p,n){l('/users'); m.user.find(function(err,docs){if (err){p.s("errs!")} else{p.r('users/index',{docs:docs})}})})
    a.g ('/users/new', function (q, p, n) {  p.r('users/signup') })
    a.p('/users/po',function(q,p,n){l('p.usrs');d(q.body);
        m.user.create(q.body,function(Z){
            if(Z){           if(Z.code==11000){   conflict();l('conflict');}    else{  n(Z);}}
            p.d('/wappy');})})


















}///










/////////

//   a.g('/info',MW.setPage,MW.requireUser,function(q,p,n){ d(q.s); p.r('users/info',{u:q.s.u})})
// a.g('/x/users/:user', function(q,p,n){  l("pathway: admin/users,  route: /users/user");
//   m.user.findOne({username: q.params.user}, function(err, user){  if(err){p.s("errs!")}   else{l('pw ok');d(user); p.r('users/user',{user:user})}})})


//a.g('/signup',function(q,p,n){p.r('users/signup')})

//a.g ('/login', function(q,p,n) {p.r('users/login', {messages: q.flash('info')})  })//q.s.currentPage = q.s.lastPage;





//q.flash('good', 'Thanks for logging in!')
// q.s.u.pets.push({name:"george"})
//doc.pets.push({name:"frank"})
// q.flash('bad', 'Incorrect login information, jerk!')  ;
