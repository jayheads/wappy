_  = require('./us')
cL=function(a){return console.log(a)}
cD=function(a){return console.dir(a)}
$l=function(a,b){if(!b){return cL(a)} cL('{'+a+':'+b+'}');return b}
$d=function(a,b){if(!b){return cD(a)} cL(a);return cD(b)}
_S=function(a){return a.toString()}
cL('~mw~')/////////////////////////////


W = function(q,p,n){     //$l('W')//p.l.q=q;p.l.p=p;
    p.r  = p.render
    p.s  = p.send
    p.d  = p.redirect

     //p.pm=function(a){return this.params[a]}

    p.l  = p.locals

    q.b  = q.body
    q.f  = q.files
    q.n  = q.flash         //p.locals.m =q.fl('info')// p.locals.tx='fdaskjlasfd;j'   // p.locals.s=
    q.s  = q.session
    q.p= function(a){return q.params[a]}
    //p.l.li=q.li=   (q.s.u)? true:false

    n()}

W.u =function(q,p,n){

    if(q.li){
        $m.user.findOne(
            {u: q.s.u},
            function(x,u){
                if(x){n(x)}
                if(u){//cL('li!')
                    p.l.U = q.U = u
                    p.l.u = q.u = u.u
                    p.l.I = q.I = u._id}
                n()})}

    else { //cL('-l')
        q.n('n','n!')
        p.r(
            'guest',
            {n: q.n('n')})}}  //var mP=u.mugPath;$l('mP:');$l(mP);p.l.mP=q.mP=mP;           //$m.image.findOne({relPath:mP},function(z,d){if(!d){$l('-m')}else{$l('+m');p.l.M=q.M=mug;p.l.mp=q.mp=q.M.relPath;p.l.mid=q.mid=q.M._id}n()})//if(!u){q.s.u=null;q.s.save(function(){p.r('guest')})}
W.p =function(q,p,n){$m.pic.findById(q.p['p'],
    function(x,i){if(x){n(x)}
          p.l.i= '/' + i._id
            q.i=i
        n()})}
W.P =function(q,p,n){
    $m.pic.find({u:q.I},function(x,P){
            var A =[];
            _.e(P,
                function(i){  A.push($l(   _S(i._id)+i.e  ))})
            p.l.I=A
            n()})}
W.B =function(q,p,n){
    $m.book.find({u:q.I},
        function(x,B){
            if(x){n(x)};
            if(!B){'-B'}
            p.l.B=B
            n()})}
W.b =function(q,p,n){

    q.p = q.params

     $m.book.findOne({
             u:q.I,
             t:q.p.t
         },

         function(x,b){if(x){n(x)}

             p.l.b=b

             if(q.p.n){var c = p.l.n = b.c[n] }

             if(q.p.h){p.l.h = c[n][h]}  //$l('p.l');$d(p.l)

             n()

         })}

module.exports = W






