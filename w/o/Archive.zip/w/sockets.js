q=require
l=function(a){return console.log(a)}
q('./u')()



module.exports=function(K){

    K.on('connection', function(z,k,s){
        var e=function(a,b){return k.emit(a,b)},
            o=function(a,b){return k.on(a,b)},
            b=function(a,b){return k.broadcast.emit(a,b)}


        l('k!')
        e('l', 'jason')
       // e('al','sockets!!! (sorry)')
        //var n=s.u// e('dir', s)
        e('sm', 'welc.io')

        o('ping',function(){l('p')})

        o('clrSs',function(){s={}})

        o('l',function(m){l(m); e('l','server logged: '+m)})
        o('em',function(a,b){e(a,b)})
        o('chatMsg',function(m){l('m:'+m)
            k.b.e('chatMsg',m)
            k.e('chatMsgAck',m)})
        o('pop',function(d){
            k.e('pop', 'server pops you: pop pop pop')
            k.b.e('pop',d)})
        o('my',function(d){
            k.e('pop',{
                t:['your '+d],
                b:[(k[d])?$str(k[d]):'-def'],
                btn:'ok'})})})

}


