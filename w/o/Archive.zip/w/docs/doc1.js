ok now


i want to improve my knowlege of webstorm and errors/tessting/jade/debugging


-

    looking above, we can see that there are auto-emphasized words: now, i, jade.  hovering, gives us information
(via inspection.js)

    - now, jade: not a statement or assignment
    - i: expecting new line or semicolon