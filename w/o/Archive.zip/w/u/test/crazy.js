
    e = 5; ducks = [];
    plop('scott', 10, 160, 'scott'); ducks.push(scott);
    scott.x = 50; scott.y = 50; plop('duck', 250, 160, 'duck1');   ducks.push(duck1);


    _.each(ducks,function(duck){duck.addEventListener('click',function(event){e = event;  e.target.y = e.target.y + 20; })})

    _.each(ducks, function(duck){duck.addEventListener('mouseout',function(event){f = event; f.target.y = f.target.y - 20;})})

    stage.enableMouseOver(20);

    // plop('duck', 100, 110, 'duck2');ducks.push(duck2); plop('duck', 100, 120, 'duck3'); ducks.push(duck3); plop('duck', 100, 130, 'duck4');ducks.push(duck4);
   // plop('duck', 100, 140, 'duck5');ducks.push(duck5); plop('duck', 100, 150, 'duck6'); ducks.push(duck6); plop('duck', 100, 160, 'duck7');                                                                                        ducks.push(duck7);
     //  _.each(mf, function(image, index, li)  {gx[image.id]= image;}); lii("loading of pic refs into gx - can be created by factory: 'plop' ")
    // makes a bob with position and stages it - and assigns its ref to the global key that you specify
    //  _.each (gx,  function(value, key, li){ stage.addChild(value); value.x=100; value.y=100;el.addEventListener("click", function(e){ createjs.Tween.get(e.target).to({x:300,y:10}, 2000) }) })

      //  edge

    l('edge')

    k.emit('face'); moveFace();

    plop('me', 'me'); stage.addChild(gx.me); l('added child p.me');
    gx.me.x = 200; gx.me.y = 10; l('set position of child')

    k.on('face', function(face){gx.me.x = face.x;gx.me.y = face.y})
    })




    bigger:f(img,"ctx.scale(1.3,1.3);  ctx.drawImage(I, 0, 0, img.width, img.height)")
    can.width = img.width;   can.height = img.height;
    $('#invert').click(   invert   ); $('#grayscale').click(
        function flipY () {ctx.translate(img.width-1, img.height-1);    ctx.rotate(Math.PI);    ctx.drawImage(img, 0, 0, img.width, img.height);}

