module.exports = function () {

a.get('/object', MW.requireUser, function (q, p, n) {    /////////////////////////////////////////////////////////////////

    l('IN /OBJECT'); l('user: '); d(q.u);  p.r('db/object/object', {js:['sites/object'], user: q.u}  ) })



a.get('/object/delSort/*', MW.requireUser, function (q, p, n) {l('IN /DELSORT/:SORT')  ;  /////////////////////////////////////////////////////////////////
       // C = pathArray.pop();
         d(pathArray);
        l('deleting sort: '); d(q.u.object[q.params.sort]);
        l('from: ') ;   d(q.u.object);
        l(delete q.u.object[q.params.sort])  ;
        l('is it gone? lets see: ') ; d(q.u.object); ; d(q.u.object[q.params.sort]);
        // ob[current].content = q.b.content;
         m.user.update( {_id: q.u._id}, {$set: { object: q.u.object }}, {upsert: true}, function ( z ) { if (z){d(z)}
         })  })  //p.d('/object')

a.get('/object/*', MW.requireUser, function (q, p, n) {l('IN /OBJECT/*') ;   l('cur: ');  d(q.s.currentPage);     /////////////////////////////////////////////////////////////////
      l('q.params: '); d(q.params)   ; pathArray = q.params[0].split('/'); l('path array: '); d(pathArray)      ;
        pop = pathArray.pop()
       l('highleted: '); d(pop) ; pathArray.push(pop)
        var content; var ob = q.u.object;  each(pathArray, function(path){content = ob[path].content; ob = ob[path].object; obName = path } ) ; l('ob: '); d(ob);
    p.r('db/object/subobject', {nav:{"home":'/object'}, content:content, user: q.u, object: ob, obName: obName, obPath: q.params[0],  sub:pop
    })    })




a.post('/object/po', MW.requireUser, function (q, p, n) {   /////////////////////////////////////////////////////////////////
   l('IN /OBJECT/PO');  l('user: '); d(q.u); l('session data: '); d(q.s);

    ob = q.u.sorty.object; l('ob: '); d(ob);
    d(q.b);

    SPA = q.u.sorty.SPA

    l('SPA: ');  d(SPA);

    leaf = q.b.leaf

    l('leaf to add: '); l(leaf);

    each(SPA, function(path){ob = ob[path].object;  l(path);    } )
    l('ob: '); d(ob);


    ob[leaf] = {object: {}, content:null}

    obj = q.u.sorty.object

    l('is it there? lets see: ') ; d();  d(ob[leaf]);

    m.user.update( {_id: q.u._id}, {$set: { sorty: obj }}, {upsert: true},
        function ( z ) { if (z){d(z)} l('wow'); p.d('/object/' + q.u.sorty.SPA) } )                    })



    a.post('/object/update/po', MW.requireUser, function (q, p, n) { l('IN /OBJECT/UPDATE/PO');  l('ob path: ') ; d(pathArray); d(q.b.obPath);    /////////////////////////////////////////////////////////////////
        current = pathArray.pop();                                                                          l('new patharay: '); d(pathArray); l('curr:'); d(current)
        var ob = q.u.object;       each(pathArray, function(path){ ob = ob[path].object; } )                ;l('OB: '); d(ob);
        ob[current].content = q.b.content;                                                                  l('OB: '); d(ob);
        m.user.update( {_id: q.u._id}, {$set: { object: q.u.object }}, {upsert: true},
         function ( z ) { if (z){d(z)}p.d('/object/' + q.b.obPath) } )                    })




   a.post('/object', MW.requireUser, function (q, p, n) {l('IN POST /OBJECT') ;   l('q.s.currentPage: ');  d(q.s.currentPage);   /////////////////////////////////////////////////////////////////
       SPA = q.b.SPA.split(",");  l('SPA: ');  d(SPA);
           var content;
            var ob = q.u.object;

                each(SPA, function(path){
                //content = ob[path].content;
                ob = ob[path].object; obName = path
            }) ;
            l('ob: '); d(ob);
            p.r('db/object/sort', {nav:{"home":'/object'},  user: q.u,  obPath: q.params[0],
            SPA:  SPA,    object: ob, obName: obName, js:['sites/object']                      })    })


a.post('/sort/del', MW.requireUser, function (q, p, n) {l('IN POST /SORT/DEL')     ;        /////////////////////////////////////////////////////////////////
        SPA = q.b.SPA.split(",");  l('SPA: ');  d(SPA);
        leaf = q.b.leaf

        l('leaf to del: '); l(leaf);
        var ob = q.u.object;  each(SPA, function(path){ob = ob[path].object;      } )

         l('we will delete from this: '); d(ob);
        l('we will delete this: '); d(ob[leaf]);
       // l('deleting sort: '); d(q.u.object[q.params.sort]);
       // l('from: ') ;   d(q.u.object);

        l(delete ob[leaf])  ;

        l('is it gone? lets see: ') ; d(q.u.object); ; d(ob[leaf]);

        // ob[current].content = q.b.content;

        m.user.update( {_id: q.u._id}, {$set: { object: q.u.object }}, {upsert: true}, function ( z ) { if (z){d(z)}

        })   })   //p.d('/object')


}/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////







