/// fix pet site and user login.. fix navbar and incorporate them   // set up redics connect per great stack overflow page   // how to get session ids  // track by session username
module.exports = function () {

    a.g('/pets', function(q,p,n){ l();l();    l("this is q.s.u in pets/: "); d(q.s.u);

    m.user.find().sort('username').exec(function(err,docs){
        if (err){p.s("errs!")} else { console.dir(docs); //l('messages: '); //d(q.flash('info'));
            p.r('pets/index', {  docs: docs,
                nav: {"new-pet": '/pets/new', "see-pets":'/pets'},
                messages: q.flash('info')  })    }  })  })

    a.g('/pets/:user', function(q,p,n){ l();l();       l("this is q.s.u in pets/: "); d(q.s.u);
        m.user.find({username: q.params.user}).sort('username').exec(function(err,docs){
            if (err){p.s("errs!")} else { console.dir(docs); //l('messages: '); //d(q.flash('info'));
                p.r('pets/index', {docs: docs,
                    nav: {"new-pet": '/pets/new', "see-pets":'/pets'},
                    messages: q.flash('info') })    }  })  })

    a.get('/pets/new', function (q, p, n) { p.r('pets/new')})

    a.post('/pets/po', function (q, p, n) {  m.user.findOneAndUpdate(  {_id: q.s.u._id},
        {$push: {pets: q.b}}, {safe: true, upsert: true}, function(err, model) { console.log(err); } );
        l("this is q.s.u in pets/po: "); d(q.s.u);   p.d('/pets')})// q.s.u.save()  //q.s.u.pets.push({name:"george"})  // q.s.u.pets.push(q.b)

    a.get('pets/index', function(q,p,n){     if (q.s.u) {  p.d("/pets"); }
        else    {a.l("not logged in"); p.r("root", {messages: q.flash('good')});    } })

    a.get('pets/flash', function(req, res){       // Set a flash message by passing the key, followed by the value, to req.flash().
        req.flash('info', 'Flash is back!');    res.redirect('/flash2'); });

    a.get('pets/flash2', function(req, res){   res.render('users/index', { messages: req.flash('info') });});
        // Get an array of flash messages by passing the key to req.flash()






}