module.exports = function () {


    a.g('/testy', function (q, p, n) {p.s('testy schmesty')});
    a.g('/testSessions', function (q, p, n) {l('q.s');d(q.s);l('q.u');d(q.u);p.r('test/test')})
    a.g('/dating',function(q, p, n){p.r('test/dating')})
    a.g('/clearSession', function(q,p,n) {l('q.s');d(q.s); q.s.regenerate(function(err){l('q.s after regen');d(q.s);})})
    a.g('/petty',function(q,p,n){if (q.s.u){ p.d("/pets");} else {a.l("not logged in"); p.r("root", {messages: q.flash('good')})}})
    a.g('/flash', function(req, res){q.flash('info', 'Flash is back!');  p.d('/flash2'); }) // Set a flash message by passing the key, followed by the value, to req.flash().
    a.g('/flash2', function(q,p,n){p.r('users/index', { messages:q.flash('info')})}) //Get an array of flash messages by passing the key to req.flash()
    a.g('/debug/models', function (q, p, n) {l('dbg modls');;d(m.models)})
    a.g('/debug/schemas', function (q, p, n) {l('dbg schms');d(m.modelSchemas)})


   }///



