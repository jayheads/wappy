module.exports = function (){




    a.g('/jitter', MW.setPage, function(q,p,n){  li('jitter');

        R ('docs/jitter', {nav: {"contents": '/ranky/new', "index":'/ranky'} })

    })


    a.g('/brain', MW.setPage, function(q,p,n){  li('jitter');

        R ('docs/brain', {nav: {"contents": '/ranky/new', "index":'/ranky'} })

    })






}