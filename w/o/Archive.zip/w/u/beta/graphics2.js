module.exports=function (){li('cappy.js');



 var cty='snappy/cutty';var cpy='snappy/cappy';

    a.g('/cappy', MW.lU, MW.lI, function(q,p,n){l('cpy');d(q.U); p.r(cpy, {imgs: q.imgs, msgs: q.f('info')})})

    a.g('/cappy/:imgP', MW.lU, MW.lI, MW.li, function(q,p,n){l('cpy.e');   p.r('sites/cappyEdit', {imgs:q.imgs,  imgP:q.imgP, msgs:q.f('info')})       })

    a.g('/cutty/:imgP'   , MW.lU,   MW.li,  function(q,p,n){  l('cty/:iP');   p.r(cty,{imgP: q.imgP})  })




    a.p('/cappy', MW.lU, function(q,p,n){l('p.cpy');d(q.files);d(q.s);l(q.ud);

        var img = q.files.image;

        var pth = path.basename(img.path);l(pth);

        var imgObj={user:q.ud,    path:pth,    fileObject:img,originalFileName:img.name};  d(imgObj.path);

        m.image.create(imgObj,      function(err,doc){
            if(err){d(err);n(err)}
            else{l('about to redirect'); q.flash('info', 'you uploaded a file to ' + imgObj.path);
                p.d('back')} }) })




    a.p('/cutty', MW.lU, function(q,p,n){l('cty.p');d(q.files);




       // fs.rename(path, path + '.png', function (err){ p.d('/cutty')});

        fs.readFile(q.files.cutout.path, function (err, data) {  d(q.files.cutout);

            var newPath = q.files.cutout.path + '.png'; l(newPath);
            fs.writeFile(newPath, data, function (err) { p.redirect("back"); });});                  })



    a.p('/upload/pic', function(q,p,n){
        var mug = q.files.mug;
        m.user.findOne({'username': q.s.u.username}, function(z,user){}
            user.mugPath = __dirname + /../../../brain/mind/emotions/mugs/pathString  + 'q.s.u'+ "-" + mug.name;
            user.save(function();
                fs.rename(mug.path, newPath, function (){
                    p.d("/upload/pic");});})})});



}









      //  p.r('test/postingForms' , {js:['test/postingForms']}) ;  a.get('/postingForms', function(q,p,n) {p.r('test/postingForms' )}) ;  a.post('/postingForms',  function(q,p,n) {d(q.b);  })
     //receives uploaded image file,assigns it to ob: 'image',creates a db image ob,
    // assigning it the express image-ob  and sets 'path' = that-file's-public-URL//d(image, 'image');
   //k.emit('devObjs'   [q.s, q.files]  )
  //dN = __dirname;  pathString = "/../../../brain/mind/img/";  newPathString = dN + pathString; d(newPathString, 'newPathString')
 //oldPath = image.path;   extension = path.extname(image.path);  newPath = __dirname + pathString  + doc._id + extension; l(newPath, 'newPath') //user:U._id (should not be nec.)
