module.exports= function(q,p,n){



    l('wapps!!!');


a.g('/cappy', MW, MW.PICS, function(q,p,n){l('cappy');p.r('/cappy', {msgs: q.f('info')})})



}/// EOF
















  //  m.user.findOne({'username': q.s.u.username}, function(z,user){}
    //        user.mugPath = __dirname + '/../../../brain/mind/emotions/mugs/pathString'  + 'q.s.u'+ "-" + mug.name;
      //      user.save(function();
        //        fs.rename(mug.path, newPath, function (){
          //          p.d("/upload/pic");});})})});

      //  p.r('test/postingForms' , {js:['test/postingForms']}) ;  a.get('/postingForms', function(q,p,n) {p.r('test/postingForms' )}) ;  a.post('/postingForms',  function(q,p,n) {d(q.b);  })
     //receives uploaded image file,assigns it to ob: 'image',creates a db image ob,
    // assigning it the express image-ob  and sets 'path' = that-file's-public-URL//d(image, 'image');
   //k.emit('devObjs'   [q.s, q.files]  )
  //dN = __dirname;  pathString = "/../../../brain/mind/img/";  newPathString = dN + pathString; d(newPathString, 'newPathString')
 //oldPath = image.path;   extension = path.extname(image.path);  newPath = __dirname + pathString  + doc._id + extension; l(newPath, 'newPath') //user:U._id (should not be nec.)
