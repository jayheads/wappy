 li('dendrite'); ///   first skull loads deps, then it puts mf in scope, then it loads this file  // the following CODE runs on everyone's browser after the deps:  db / forms
 // OLD WAY: l('found ' + dendrites.length + ' dendrite(s) - executing:'); _.each(  dendrites , function(dendrite){dendrite();}  )
 // borrowed from the web.. dont know if its implemented   // Set method to post by default if not specified.   // The rest of this code assumes you are not using a library.   // It can be made less wordy if you use one.

 /////////////     E O F      ///////////////////

















