module.exports = {




    petSite:{



        pb:{},

        pv:{"new-pet": '/pets/new', "see-pets":'/pets'}

    }




,


    pets:{



        pb:{},

        pv:{"new-pet": '/pets/new'}

    }

    ,







    users:{



        pb:{"users": '/users',
            "home": '/users'},

        pv:{"items": '/items'}

    }








}