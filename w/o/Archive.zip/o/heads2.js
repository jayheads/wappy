    l('heads');

    guys = {}; gone = lopper(guys);    
    // m =  {   moe: { x: 20, y: 100}    ,  larry:    { x: 20, y: 130}    ,  
    // curly:  { x: 20, y: 10}        };

    updateMap = function(m){
        li('updateMap');
    }
   
    d(m); //2step process for client to update map based on server new-map push
       
        var upsert=function(guy){
            if(guys[guy.name]){guys[guy.name].x = guy.x;
                guys[guy.name].y = guy.y} 
            else {guys[guy.name]=plop('me',guy.x, guy.y)}}
        _.e (guys, function(c,name,l) {if(!m[name]){gone(name);
            l('removed:' + name)}})
        _.e(m, function(c, name){
            upsert({name: name, x: c.x, y: c.y })})}  
            //  upsert({name: 'woah', x:1, y:1})  // updateMap(m);
    k.on('mapUpdate', function(m){updateMap(m)})

    $('#up').click(function(){k.emit('moveGuy','up')}); 
    $('#down').click(function(){k.emit('moveGuy','down')});
    $('#left').click(function(){k.emit('moveGuy','left')});
    $('#right').click(function(){k.emit('moveGuy','right')});      
    moveGuy=function(){k.emit('moveGuy')}      
     // k.on('face', function(face){     })
     //  gx.me.x = face.x;  gx.me.y = face.y // k.emit('face')

    k.emit('enterGame');



//   isGuyInMap = function(guy, map){_.e(map, function(player){
// if (guy.name == player.name){$l('yes in map'); 
// return guy}})$l(guy.name + ': not in map'); return false}
    //  _.e(guys, function(player){ $d(player); 
    // if (!(isGuyInMap(player, map))){stage.removeChild(guys[player])}})}
// k.on('m', function(d){updateMap(d)})
    // upsert({name: 'weirdo', x: 30, y: 40}) ;
    // upsert({name: 'moe', x: 0, y: 0})     ;
    //  function map (sGuys){
    //  _.e(mGuys, function(guy){   if (!sGuys[guy.username]){stage.removeChild(guy)}    })
    //  _.e(sGuys, function(guy){  if (mGuys[guy.username]){mGuys[guy.username]}  }) }
    // myGuys is an array of 'guy objects' ... username: '',  x,  y


//            _.e(sArray, function(guy){
//
//
//                remove all guys from myarray that are not in sArray
//                for _.e guy in sArray,
//                if he is in mArray, update his position
//                if not, addhim to mArray
//
//                or
//
//                keep them as display objects, but just undisplay them.
//                    YES!  on map.. just hide all your display obs, and for _.e guy in guysArray,
//                    update his coordinates and display him.. but if he doesn't exist,
// create him'and add him to the stage
//
//
//                or is it a matter of adding and removing from stage
//                or
//            }
    //  plop('tim1', 'guy', 210, 50); plop('tim2', 'guy', 50, 300); plop('tim3', 
    // 'guy', 100, 100)
    //gx.tim1.x = 200;  gx.tim1.y = 50;  stage.addChild(gx.tim1)  ; 
    //gx.tim2.x = 50;  gx.tim2.y = 200;  stage.addChild(gx.tim2)  ;//gx.tim3.x = 100;
    //  gx.tim3.y = 100;  stage.addChild(gx.tim3)  ;
    //   plop('jason', 'me', 0, 10);
    // tim


    guys = {};  gone = lopper(guys); // m =  {   moe: { x: 20, y: 100}    , 
    // larry:    { x: 20, y: 130}    ,   curly:  { x: 20, y: 10}        };

    
    
    
    upsert = function(guy){   if (guys[guy.name]){ 
        guys[guy.name].x = guy.x; guys[guy.name].y = guy.y }
    else { guys[guy.name] = plop( 'me' , guy.x, guy.y)  } }

    
function updateMap(m){         //c=coords, l=l  m=guysM
        
        
        _.e(guys, function (c, n, l) { 
            if (!m[n]) {$l('removing:' 
            + n); gone(n)  }   }   )
       
        _.e(m, function(c, n){
            upsert({n:n, x:c.x,y:c.y   }); })} 
       
       
        //  upsert({name: 'woah', x:1, y:1})

    
    
    
    
    
    k.on('mapUpdate', function(m){updateMap(m)})// updateMap(m);

    enterGame = function(){ k.emit('enterGame') }  ;  
    enterGame(); //k.on('enterGame', enterGame);
    $('#up').click(   function(){k.emit('moveGuy','up')}); 
    $('#down').click(function(){
        k.emit('moveGuy','down')})//moveGuy = function(){k.emit('moveGuy')}
    $('#left').click(function(){k.emit('moveGuy','left')}); 
    $('#right').click(function(){k.emit('moveGuy','right')})



    //   isGuyInMap = function(guy, map){_.e(map, function(player){
    // if (guy.name == player.name){
    // $l('yes in map'); return guy}})$l(guy.name + ': not in map'); 
    // return false}
    //  _.e(guys, function(player){ $d(player);
    // if (!(isGuyInMap(player, map))){
    // stage.removeChild(guys[player])}})}
    // k.on('m', function(d){updateMap(d)})
    // upsert({name: 'weirdo', x: 30, y: 40}) ;
    // upsert({name: 'moe', x: 0, y: 0})     ;
    //  function map (sGuys){
    //  _.e(mGuys, function(guy){  
    // if (!sGuys[guy.username]){stage.removeChild(guy)}    })
    //  _.e(sGuys, function(guy){ 
    // if (mGuys[guy.username]){mGuys[guy.username]}  }) }

    // myGuys is an array of 'guy objects' ... username: '',  x,  y


    //            _.e(sArray, function(guy){
    //
    //
    //                remove all guys from myarray that are not in sArray
    //                for _.e guy in sArray,
    //                if he is in mArray, update his position
    //                if not, addhim to mArray
    //
    //                or
    //
    //                keep them as display objects, but just undisplay them.
    //                    YES!  on map.. just hide all your display obs,
    // and for _.e guy in guysArray,
    //                    update his coordinates and display him..
    // but if he doesn't exist,
    // create him'and add him to the stage
    //
    //
    //                or is it a matter of adding and removing from stage
    //                or
    //            }
    //  plop('tim1', 'guy', 210, 50); plop('tim2', 'guy', 50, 300); 
    // plop('tim3', 'guy', 100, 100)
    //gx.tim1.x = 200;  gx.tim1.y = 50;  stage.addChild(gx.tim1)  ;
    //gx.tim2.x = 50;  gx.tim2.y = 200;  stage.addChild(gx.tim2)  ;
    //gx.tim3.x = 100;  gx.tim3.y = 100;  stage.addChild(gx.tim3)  ;
    //   plop('jason', 'me', 0, 10);
    //k.on('face', function(face){}) //  gx.me.x = face.x; 
    // gx.me.y = face.y// k.emit('face')

    // guys
    $('#up').click(function(){k.emit('move',{dir: 'up', un: un}));
        $('#down').click(function(){
        k.emit('move',{dir: 'down', un: un})})
        $('#left').click(function(){k.emit('move',{dir: 'left', un: un})});
        $('#right').click(function(){k.emit('move',{dir: 'right', un: un})})
        k.emit('warp')
        k.on('map', function(guysArr){ _.e(guysArray, function(guy){
            remove all guys from myarray that are not in guysArray
            for _.e guy in guysArray,
            if he is in myarray, update his position
            if not, addhim to myarray
            or
            keep them as display objects, but just undisplay them.
                YES!  on map.. just hide all your display obs, 
                and for _.e guy in guysArray,
                update his coordinates and display him.. 
                but if he doesn't exist, create him'and add him to the stage
            or is it a matter of adding and removing from stage
            or
        })
            stage.addChild(p.me); l('added child p.me'); 
            p.me.x = 200; p.me.y = 100; p.me.x = face.x; p.me.y = face.y
        })


